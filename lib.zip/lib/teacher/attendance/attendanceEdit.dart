import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AttendanceEditPage extends StatefulWidget {
  final String selectedClass;
  final String selectedDate;

  const AttendanceEditPage({
    Key? key,
    required this.selectedClass,
    required this.selectedDate,
  }) : super(key: key);

  @override
  _AttendanceEditPageState createState() => _AttendanceEditPageState();
}

class _AttendanceEditPageState extends State<AttendanceEditPage> {
  final Map<String, String?> attendanceStatus = {};
  final Map<String, String?> returnAtStatus = {};
  final List<Map<String, dynamic>> children = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchChildList();
  }

  Future<void> fetchChildList() async {
    try {
      var attendanceSnapshot = await FirebaseFirestore.instance
          .collection('attendance')
          .doc(widget.selectedClass)
          .get();

      if (attendanceSnapshot.exists) {
        List<dynamic> attendanceHistory =
            attendanceSnapshot['attendanceHistory'];

        for (var record in attendanceHistory) {
          String childId = record['childID'];
          var childSnapshot = await FirebaseFirestore.instance
              .collection('child')
              .doc(childId)
              .get();

          if (childSnapshot.exists) {
            String childName = childSnapshot['SectionA']['nameC'] as String;
            String profileImage =
                childSnapshot['profileImage'] as String? ?? '';

            List<dynamic> records = record['records'] ?? [];
            var arrivedAt = records.firstWhere(
              (attendance) => attendance['date'] == widget.selectedDate,
              orElse: () => null,
            )?['arrivedAt'];

            var returnAt = records.firstWhere(
              (attendance) => attendance['date'] == widget.selectedDate,
              orElse: () => null,
            )?['returnAt'];

            children.add({
              'id': childId,
              'name': childName,
              'profileImage': profileImage,
              'arrivedAt': arrivedAt is Timestamp ? arrivedAt : null,
              'returnAt': returnAt is Timestamp ? returnAt : null,
            });

            String status = records.firstWhere(
              (attendance) => attendance['date'] == widget.selectedDate,
              orElse: () => {'status': null},
            )['status'];

            attendanceStatus[childId] = status;

            if (status == 'absent') {
              returnAtStatus[childId] = null;
            } else {
              returnAtStatus[childId] = returnAt == null ? null : 'Yes';
            }
          }
        }
      }
    } catch (e) {
      print('Error fetching child list: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error fetching data')),
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> refreshChildData(String childId) async {
    try {
      var attendanceSnapshot = await FirebaseFirestore.instance
          .collection('attendance')
          .doc(widget.selectedClass)
          .get();

      if (attendanceSnapshot.exists) {
        List<dynamic> attendanceHistory =
            attendanceSnapshot['attendanceHistory'];

        for (var record in attendanceHistory) {
          if (record['childID'] == childId) {
            List<dynamic> records = record['records'] ?? [];

            var arrivedAt = records.firstWhere(
              (attendance) => attendance['date'] == widget.selectedDate,
              orElse: () => null,
            )?['arrivedAt'];

            var returnAt = records.firstWhere(
              (attendance) => attendance['date'] == widget.selectedDate,
              orElse: () => null,
            )?['returnAt'];

            setState(() {
              int index =
                  children.indexWhere((child) => child['id'] == childId);
              if (index != -1) {
                children[index]['arrivedAt'] =
                    arrivedAt is Timestamp ? arrivedAt : null;
                children[index]['returnAt'] =
                    returnAt is Timestamp ? returnAt : null;
              }
            });
            break;
          }
        }
      }
    } catch (e) {
      print('Error refreshing child data: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error refreshing data')),
      );
    }
  }

  Future<void> updateAttendanceStatus(String childId, String? newStatus) async {
    try {
      var attendanceSnapshot = await FirebaseFirestore.instance
          .collection('attendance')
          .doc(widget.selectedClass)
          .get();

      if (attendanceSnapshot.exists) {
        List<dynamic> attendanceHistory =
            attendanceSnapshot['attendanceHistory'];

        for (var record in attendanceHistory) {
          if (record['childID'] == childId) {
            List<dynamic> records = record['records'] ?? [];

            for (var attendance in records) {
              if (attendance['date'] == widget.selectedDate) {
                if (newStatus == 'absent') {
                  attendance['arrivedAt'] = null;
                } else {
                  attendance['arrivedAt'] = Timestamp.now();
                }
                attendance['status'] = newStatus;
                break;
              }
            }
            break;
          }
        }

        await FirebaseFirestore.instance
            .collection('attendance')
            .doc(widget.selectedClass)
            .update({
          'attendanceHistory': attendanceHistory,
        });

        await updateAttendanceRecord(childId);
      }
    } catch (e) {
      print('Error updating attendance status: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error updating status')),
      );
    }
  }

  Future<void> updateReturnStatus(
      String childId, String? newReturnStatus) async {
    try {
      var attendanceSnapshot = await FirebaseFirestore.instance
          .collection('attendance')
          .doc(widget.selectedClass)
          .get();

      if (attendanceSnapshot.exists) {
        List<dynamic> attendanceHistory =
            attendanceSnapshot['attendanceHistory'];

        for (var record in attendanceHistory) {
          if (record['childID'] == childId) {
            List<dynamic> records = record['records'] ?? [];

            for (var attendance in records) {
              if (attendance['date'] == widget.selectedDate) {
                attendance['returnAt'] =
                    newReturnStatus == 'Yes' ? Timestamp.now() : null;
                break;
              }
            }
            break;
          }
        }

        await FirebaseFirestore.instance
            .collection('attendance')
            .doc(widget.selectedClass)
            .update({
          'attendanceHistory': attendanceHistory,
        });

        await updateAttendanceRecord(childId);
      }
    } catch (e) {
      print('Error updating return status: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error updating return status')),
      );
    }
  }

  Future<void> updateAttendanceRecord(String childId) async {
    try {
      var attendanceSnapshot = await FirebaseFirestore.instance
          .collection('attendance')
          .doc(widget.selectedClass)
          .get();

      if (attendanceSnapshot.exists) {
        List<dynamic> attendanceHistory =
            attendanceSnapshot['attendanceHistory'];

        var childRecord = attendanceHistory.firstWhere(
          (record) => record['childID'] == childId,
          orElse: () => null,
        );

        if (childRecord != null) {
          int totalDays = childRecord['records'].length;
          int daysPresent = childRecord['records']
              .where((record) => record['status'] == 'present')
              .length;

          var attendanceRecord = attendanceSnapshot['attendanceRecord'] ?? [];
          var childAttendanceRecord = attendanceRecord.firstWhere(
            (record) => record['childID'] == childId,
            orElse: () => null,
          );

          if (childAttendanceRecord != null) {
            childAttendanceRecord['totalDays'] = totalDays;
            childAttendanceRecord['daysPresent'] = daysPresent;
            childAttendanceRecord['attendancePercentage'] =
                (totalDays > 0) ? (daysPresent / totalDays) * 100 : 0;
          } else {
            attendanceRecord.add({
              'childID': childId,
              'totalDays': totalDays,
              'daysPresent': daysPresent,
              'attendancePercentage':
                  (totalDays > 0) ? (daysPresent / totalDays) * 100 : 0,
            });
          }

          await FirebaseFirestore.instance
              .collection('attendance')
              .doc(widget.selectedClass)
              .update({
            'attendanceRecord': attendanceRecord,
          });
        }
      }
    } catch (e) {
      print('Error updating attendance record: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error updating attendance record')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Edit Attendance'),
            Text(
              widget.selectedDate,
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context, true);
          },
        ),
        backgroundColor: Colors.blue[100],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      const Text(
                        '                                                    Attendance   |  Returned',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                      itemCount: children.length,
                      itemBuilder: (context, index) {
                        final child = children[index];
                        final childId = child['id']!;
                        final childName = child['name']!;
                        final profileImage = child['profileImage']!;
                        final timestamp = child['arrivedAt'] != null &&
                                child['arrivedAt'] is Timestamp
                            ? (child['arrivedAt'] as Timestamp).toDate()
                            : null;
                        final returnTimestamp = child['returnAt'] != null &&
                                child['returnAt'] is Timestamp
                            ? (child['returnAt'] as Timestamp).toDate()
                            : null;

                        String formattedArrivedTime = timestamp != null
                            ? "${timestamp.add(Duration(hours: 8)).hour.toString().padLeft(2, '0')}:${timestamp.add(Duration(hours: 8)).minute.toString().padLeft(2, '0')}"
                            : "  ";

                        String formattedReturnTime = returnTimestamp != null
                            ? "${returnTimestamp.add(Duration(hours: 8)).hour.toString().padLeft(2, '0')}:${returnTimestamp.add(Duration(hours: 8)).minute.toString().padLeft(2, '0')}"
                            : "  ";

                        return Container(
                          margin: const EdgeInsets.symmetric(vertical: 4.0),
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: const Color.fromARGB(255, 166, 157, 157),
                            ),
                            borderRadius: BorderRadius.circular(4.0),
                          ),
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundImage: profileImage.isNotEmpty
                                  ? NetworkImage(profileImage)
                                  : const AssetImage(
                                          'assets/images/default_avatar.png')
                                      as ImageProvider,
                              radius: 30,
                            ),
                            title: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  childName,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  "Arrived at: $formattedArrivedTime",
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey,
                                  ),
                                ),
                                Text(
                                  "Returned: $formattedReturnTime",
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey,
                                  ),
                                ),
                              ],
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                // Attendance Dropdown
                                Container(
                                  width: 67,
                                  decoration: BoxDecoration(
                                    color: attendanceStatus[childId] ==
                                            'present'
                                        ? const Color.fromARGB(
                                            255, 205, 241, 226)
                                        : attendanceStatus[childId] == 'absent'
                                            ? const Color.fromARGB(
                                                255, 251, 201, 206)
                                            : Colors.white,
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                  child: DropdownButton<String?>(
                                    value: attendanceStatus[childId],
                                    hint: const Text(
                                      'Select Status',
                                      style: TextStyle(fontSize: 12),
                                    ),
                                    underline: const SizedBox(),
                                    isExpanded: true,
                                    items: const [
                                      DropdownMenuItem(
                                        value: 'present',
                                        child: Text(
                                          'Present',
                                          style: TextStyle(fontSize: 12),
                                        ),
                                      ),
                                      DropdownMenuItem(
                                        value: 'absent',
                                        child: Text(
                                          'Absent',
                                          style: TextStyle(fontSize: 12),
                                        ),
                                      ),
                                    ],
                                    onChanged: (String? newValue) {
                                      setState(() {
                                        attendanceStatus[childId] = newValue;
                                        if (newValue == 'absent') {
                                          returnAtStatus[childId] = null;
                                        }
                                      });
                                      updateAttendanceStatus(childId, newValue);
                                      refreshChildData(childId);
                                    },
                                  ),
                                ),

                                const SizedBox(width: 8),

                                // Return Status Dropdown
                                Container(
                                  width: 74,
                                  decoration: BoxDecoration(
                                    color: returnAtStatus[childId] == 'Yes'
                                        ? const Color.fromARGB(
                                            255, 205, 241, 226)
                                        : Colors.white,
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                  child: DropdownButton<String?>(
                                    value: returnAtStatus[childId],
                                    hint: const Text(
                                      'Returned',
                                      style: TextStyle(fontSize: 12),
                                    ),
                                    underline: const SizedBox(),
                                    isExpanded: true,
                                    items: const [
                                      DropdownMenuItem(
                                        value: 'Yes',
                                        child: Text(
                                          'Yes',
                                          style: TextStyle(fontSize: 12),
                                        ),
                                      ),
                                      DropdownMenuItem(
                                        value: 'No',
                                        child: Text(
                                          'No',
                                          style: TextStyle(fontSize: 12),
                                        ),
                                      ),
                                    ],
                                    onChanged:
                                        attendanceStatus[childId] == 'absent'
                                            ? null
                                            : (String? newValue) {
                                                setState(() {
                                                  returnAtStatus[childId] =
                                                      newValue;
                                                });
                                                updateReturnStatus(
                                                    childId, newValue);
                                                refreshChildData(childId);
                                              },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
