import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:kms2/teacher/attendance/attendanceEdit.dart'; // Import the AttendanceEditPage
import 'package:kms2/teacher/attendance/attendanceTaking.dart'; // Import the attendanceTakingPage

class AttendanceTeacherPage extends StatefulWidget {
  final String docId; // Teacher ID

  const AttendanceTeacherPage({super.key, required this.docId});

  @override
  State<AttendanceTeacherPage> createState() => _AttendanceTeacherPageState();
}

class _AttendanceTeacherPageState extends State<AttendanceTeacherPage> {
  String? selectedClass = 'Year 4'; // Set default class to 'Year 4'
  List<String> assignedClasses = [];
  DateTime selectedDate = DateTime.now();
  String? formattedDate;
  List<String> attendanceDates = [];

  @override
  void initState() {
    super.initState();
    formattedDate = DateFormat('yyyy-MM-dd').format(selectedDate);
    // No need to call fetchAssignedClasses() here; it'll be called in didChangeDependencies.
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    fetchAssignedClasses(); // Fetch assigned classes when the page is displayed
    fetchAttendanceRecords(); // Fetch attendance records for default class (Year 4)
  }

  Future<void> fetchAssignedClasses() async {
    // Fetch assigned classes from Firestore
    var doc = await FirebaseFirestore.instance
        .collection('teachers')
        .doc(widget.docId)
        .get();
    setState(() {
      assignedClasses = List<String>.from(doc['assignedClasses']);
    });
  }

  Future<void> fetchAttendanceRecords() async {
    if (selectedClass == null) return;

    var attendanceSnapshot = await FirebaseFirestore.instance
        .collection('attendance')
        .doc(selectedClass)
        .get();

    if (attendanceSnapshot.exists) {
      List<dynamic> attendanceHistory = attendanceSnapshot['attendanceHistory'];

      // Extract unique dates from the attendance history records
      Set<String> uniqueDates = {};
      for (var record in attendanceHistory) {
        for (var attendance in record['records']) {
          uniqueDates.add(attendance['date']);
        }
      }

      setState(() {
        // Sort the dates in descending order to display the most recent first
        attendanceDates = uniqueDates.toList()
          ..sort((a, b) => b.compareTo(a)); // Sort in descending order
      });
    } else {
      setState(() {
        attendanceDates = []; // Clear if no records exist
      });
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(DateTime.now().year, 1, 1),
      lastDate: DateTime.now(),
    );

    if (pickedDate != null) {
      setState(() {
        selectedDate = pickedDate;
        formattedDate = DateFormat('yyyy-MM-dd').format(selectedDate);
      });
    }
  }

  void _navigateToAttendanceTaking() {
    if (selectedClass != null && formattedDate != null) {
      // Check if the selected date already exists in attendanceDates
      if (attendanceDates.contains(formattedDate)) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content:
                  Text('Attendance has already been created for this date.')),
        );
      } else {
        print('Navigating to AttendanceTakingPage with:');
        print('Class: $selectedClass, Date: $formattedDate');
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => AttendanceTakingPage(
              selectedClass: selectedClass!,
              selectedDate: formattedDate!,
            ),
          ),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a class and a date.')),
      );
    }
  }

  void _onDateSelected(String date) async {
    print("Selected date: $date");
    // Navigate to AttendanceEditPage with selected class and date
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AttendanceEditPage(
          selectedClass: selectedClass!,
          selectedDate: date,
        ),
      ),
    );

    // Check if changes were made
    if (result == true) {
      // Reload attendance records if changes were made
      fetchAttendanceRecords();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Attendance Management'),
        backgroundColor: Colors.blue[100],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0), // Padding around the container
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min, // Fit the size of the content
            children: [
              Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Add bold "Create Attendance" text
                    const Text(
                      'Create Attendance',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    const SizedBox(height: 4.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Select Class: ',
                            style: TextStyle(fontSize: 16)),
                        DropdownButton<String>(
                          value: selectedClass,
                          hint: const Text('Select'),
                          onChanged: (String? newValue) {
                            setState(() {
                              selectedClass = newValue;
                            });
                            fetchAttendanceRecords(); // Fetch attendance dates when class is selected
                          },
                          items: assignedClasses
                              .map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16.0),
                    GestureDetector(
                      onTap: () => _selectDate(context),
                      child: Container(
                        padding: const EdgeInsets.all(12.0),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(4.0),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(formattedDate ?? 'Select Date'),
                            const Icon(Icons.calendar_today),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 20.0),
                    Center(
                      child: ElevatedButton(
                        onPressed: _navigateToAttendanceTaking,
                        child: const Text('Create Attendance'),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20.0),
              if (attendanceDates.isNotEmpty)
                Container(
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Attendance Records:',
                        style: TextStyle(
                          fontSize: 18, // Increased font size
                          fontWeight: FontWeight.bold, // Bold text
                        ),
                      ),
                      const SizedBox(height: 10.0),
                      // Add subtitle text
                      const Text(
                        '*Click any date to view attendance details.',
                        style: TextStyle(
                          fontSize: 13.0, // Smaller font size for subtitle
                          color:
                              Colors.grey, // Optional: Grey color for subtitle
                        ),
                      ),
                      const SizedBox(height: 10.0),
                      SizedBox(
                        height: 350.0, // Set a fixed height for the list view
                        child: Container(
                          // Wrap ListView in a Container for background color
                          color:
                              Colors.grey[200], // Light grey background color
                          child: ListView.builder(
                            itemCount: attendanceDates.length,
                            itemBuilder: (context, index) {
                              String date = attendanceDates[index];

                              // Check if the date is today and append "(Today)" if it matches
                              String displayDate = date;
                              if (date ==
                                  DateFormat('yyyy-MM-dd')
                                      .format(DateTime.now())) {
                                displayDate += " (Today)";
                              }

                              return Container(
                                // Wrap ListTile in a Container
                                margin: const EdgeInsets.symmetric(
                                    vertical: 4.0), // Add margin for spacing
                                decoration: BoxDecoration(
                                  border: Border.all(
                                      color: const Color.fromARGB(
                                          255, 166, 157, 157)), // Black outline
                                  borderRadius: BorderRadius.circular(
                                      4.0), // Rounded corners
                                  color: Colors
                                      .white, // Background color for ListTile
                                ),
                                child: ListTile(
                                  title: Text(displayDate),
                                  onTap: () => _onDateSelected(date),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
