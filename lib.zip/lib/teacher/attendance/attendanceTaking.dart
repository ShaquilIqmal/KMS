import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AttendanceTakingPage extends StatefulWidget {
  final String selectedClass;
  final String selectedDate;

  const AttendanceTakingPage({
    super.key,
    required this.selectedClass,
    required this.selectedDate,
  });

  @override
  _AttendanceTakingPageState createState() => _AttendanceTakingPageState();
}

class _AttendanceTakingPageState extends State<AttendanceTakingPage> {
  final Map<String, String?> attendanceStatus = {};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Attendance Taking'),
            Text(
              widget.selectedDate,
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
        backgroundColor: Colors.blue[100],
      ),
      body: Column(
        children: [
          Expanded(
            child: FutureBuilder<List<Map<String, String>>>(
              future: fetchChildList(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (snapshot.hasError) {
                  return const Center(child: Text('Error fetching data'));
                }

                final children = snapshot.data;

                if (children == null || children.isEmpty) {
                  return const Center(
                      child: Text('No students found for this class'));
                }

                return Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ListView.builder(
                    itemCount: children.length,
                    itemBuilder: (context, index) {
                      final child = children[index];
                      final childId = child['id']!;
                      attendanceStatus.putIfAbsent(childId, () => null);

                      return FutureBuilder<Map<String, dynamic>>(
                        future: fetchChildData(childId),
                        builder: (context, dataSnapshot) {
                          if (dataSnapshot.connectionState ==
                              ConnectionState.waiting) {
                            return const ListTile(title: Text('Loading...'));
                          }

                          if (dataSnapshot.hasError || !dataSnapshot.hasData) {
                            return const ListTile(
                                title: Text('Error loading data'));
                          }

                          final childData = dataSnapshot.data!;
                          final childName = childData['nameC'] as String;
                          final profileImage =
                              childData['profileImage'] as String;

                          return Container(
                            margin: const EdgeInsets.symmetric(vertical: 4.0),
                            decoration: BoxDecoration(
                              border: Border.all(
                                  color:
                                      const Color.fromARGB(255, 166, 157, 157)),
                              borderRadius: BorderRadius.circular(4.0),
                              color: Colors.white,
                            ),
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundImage: profileImage.isNotEmpty
                                    ? NetworkImage(profileImage)
                                    : const AssetImage(
                                            'assets/images/default_avatar.png')
                                        as ImageProvider,
                                radius: 30,
                              ),
                              title: Text(
                                childName,
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold),
                              ),
                              trailing: Container(
                                decoration: BoxDecoration(
                                  color: attendanceStatus[childId] == 'present'
                                      ? const Color.fromARGB(255, 205, 241, 226)
                                      : attendanceStatus[childId] == 'absent'
                                          ? const Color.fromARGB(
                                              255, 251, 201, 206)
                                          : Colors.white,
                                  borderRadius: BorderRadius.circular(5),
                                ),
                                child: DropdownButton<String?>(
                                  value: attendanceStatus[childId],
                                  hint: const Text('Select Status'),
                                  underline: const SizedBox(),
                                  items: const [
                                    DropdownMenuItem(
                                      value: 'present',
                                      child: Text('Present'),
                                    ),
                                    DropdownMenuItem(
                                      value: 'absent',
                                      child: Text('Absent'),
                                    ),
                                  ],
                                  onChanged: (String? newValue) {
                                    setState(() {
                                      attendanceStatus[childId] = newValue;
                                    });
                                  },
                                ),
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton(
              onPressed: () {
                submitAttendance();
              },
              child: const Text('Submit'),
            ),
          ),
        ],
      ),
    );
  }

  Future<List<Map<String, String>>> fetchChildList() async {
    final snapshot = await FirebaseFirestore.instance.collection('child').get();
    return snapshot.docs.where((doc) {
      return doc['SectionA']['yearID'] == widget.selectedClass;
    }).map((doc) {
      return {
        'id': doc.id,
      };
    }).toList();
  }

  Future<Map<String, dynamic>> fetchChildData(String childId) async {
    String? childName = await fetchChildName(childId);
    String profileImage = await fetchChildProfileImage(childId);
    return {
      'nameC': childName ?? 'Unknown',
      'profileImage': profileImage,
    };
  }

  Future<String?> fetchChildName(String childId) async {
    DocumentSnapshot childDoc =
        await FirebaseFirestore.instance.collection('child').doc(childId).get();
    return childDoc.exists ? childDoc['SectionA']['nameC'] as String : null;
  }

  Future<String> fetchChildProfileImage(String childId) async {
    DocumentSnapshot childDoc =
        await FirebaseFirestore.instance.collection('child').doc(childId).get();
    if (childDoc.exists) {
      final data = childDoc.data() as Map<String, dynamic>;
      if (data.containsKey('profileImage')) {
        return data['profileImage'] as String;
      }
    }
    return ''; // Return an empty string if no image exists
  }

  void submitAttendance() async {
    bool allStatusSelected =
        attendanceStatus.entries.every((entry) => entry.value != null);

    if (!allStatusSelected) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Please choose a status for all children first!')),
      );
      return;
    }

    CollectionReference timetableCollection =
        FirebaseFirestore.instance.collection('attendance');
    DocumentReference attendanceDoc =
        timetableCollection.doc(widget.selectedClass);
    DocumentSnapshot timetableSnapshot = await attendanceDoc.get();

    List<dynamic> attendanceHistory = [];
    List<dynamic> attendanceRecord = [];

    if (timetableSnapshot.exists) {
      attendanceHistory = timetableSnapshot['attendanceHistory'];
      attendanceRecord = timetableSnapshot['attendanceRecord'];
    }

    Timestamp currentTimestamp = Timestamp.now();

    await Future.forEach(attendanceStatus.entries, (entry) async {
      final childId = entry.key;
      final status = entry.value;

      if (status == null) return;

      await updateAttendanceHistory(
          attendanceHistory, childId, status, currentTimestamp);
      await updateAttendanceRecord(
          attendanceRecord, attendanceHistory, childId);
    });

    await attendanceDoc.set(
      {
        'yearID': widget.selectedClass,
        'attendanceHistory': attendanceHistory,
        'attendanceRecord': attendanceRecord,
      },
      SetOptions(merge: true),
    );

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Success'),
          content: const Text('Attendance submitted successfully!'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
              },
              child: const Text('Okay'),
            ),
          ],
        );
      },
    );

    setState(() {
      attendanceStatus.clear();
    });
  }

  Future<void> updateAttendanceHistory(List<dynamic> attendanceHistory,
      String childId, String status, Timestamp timestamp) async {
    var childRecordHistory = attendanceHistory.firstWhere(
        (record) => record['childID'] == childId,
        orElse: () => null);

    if (childRecordHistory != null) {
      var recordForDate = childRecordHistory['records'].firstWhere(
          (record) => record['date'] == widget.selectedDate,
          orElse: () => null);

      if (recordForDate != null) {
        recordForDate['status'] = status;
        recordForDate['arrivedAt'] = timestamp; // Rename to arrivedAt
        recordForDate['returnAt'] = null; // Add returnAt field
      } else {
        childRecordHistory['records'].add({
          'date': widget.selectedDate,
          'status': status,
          'arrivedAt': timestamp,
          'returnAt': null,
        });
      }
    } else {
      attendanceHistory.add({
        'childID': childId,
        'records': [
          {
            'date': widget.selectedDate,
            'status': status,
            'arrivedAt': timestamp,
            'returnAt': null,
          }
        ],
      });
    }
  }

  Future<void> updateAttendanceRecord(List<dynamic> attendanceRecord,
      List<dynamic> attendanceHistory, String childId) async {
    int totalDays = 0;
    int daysPresent = 0;

    var updatedChildRecordHistory = attendanceHistory.firstWhere(
        (record) => record['childID'] == childId,
        orElse: () => null);

    if (updatedChildRecordHistory != null) {
      totalDays = updatedChildRecordHistory['records'].length;
      daysPresent = updatedChildRecordHistory['records']
          .where((record) => record['status'] == 'present')
          .length;
    }

    var childRecordAttendance = attendanceRecord.firstWhere(
        (record) => record['childID'] == childId,
        orElse: () => null);

    if (childRecordAttendance != null) {
      childRecordAttendance['totalDays'] = totalDays;
      childRecordAttendance['daysPresent'] = daysPresent;
      childRecordAttendance['attendancePercentage'] =
          (totalDays > 0) ? (daysPresent / totalDays) * 100 : 0;
    } else {
      attendanceRecord.add({
        'childID': childId,
        'totalDays': totalDays,
        'daysPresent': daysPresent,
        'attendancePercentage':
            (totalDays > 0) ? (daysPresent / totalDays) * 100 : 0,
      });
    }
  }
}
