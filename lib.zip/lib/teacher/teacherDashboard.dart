import 'package:flutter/material.dart';
import 'package:kms2/login.dart';
import 'package:kms2/service/database_service.dart';
import 'package:kms2/service/zmodel/teachermodel.dart';
import 'package:kms2/teacher/attendance/attendanceManagement.dart';
import 'package:kms2/teacher/milestone/menuMilestone.dart';
import 'package:kms2/teacher/teacherNotification.dart';
import 'package:kms2/teacher/timetableViewTeacher.dart';

import 'teacherProfile.dart'; // Import the TeacherProfile page

class TeacherDashboardPage extends StatefulWidget {
  final String docId;

  const TeacherDashboardPage({Key? key, required this.docId}) : super(key: key);

  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<TeacherDashboardPage> {
  String? name; // Nullable String for teacher's name
  String? profileImage; // Nullable String for profile image URL
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchTeacherData(); // Fetch teacher data on initialization
  }

  Future<void> fetchTeacherData() async {
    Teacher? teacher = await DatabaseService.fetchTeacherData(widget.docId);
    setState(() {
      name = teacher?.name; // Update name
      profileImage = teacher?.profileImage; // Update profile image
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Little Iman Kids'),
        backgroundColor: Colors.blue[100],
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        TeacherNotificationPage(teacherDocId: widget.docId)),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const LoginPage()),
              );
            },
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildProfileSection(),
                    const SizedBox(height: 16.0),
                    _buildDueAmountSection(),
                    const SizedBox(height: 16.0),
                    _buildMainMenuSection(),
                    const SizedBox(height: 16.0),
                    Text(
                      'Document ID: ${widget.docId}',
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildProfileSection() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              name ?? 'N/A', // Use fallback value
              style: const TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Text(
              "Teacher's Account",
              style: TextStyle(fontSize: 16.0, color: Colors.grey),
            ),
          ],
        ),
        const SizedBox(width: 16.0),
        InkWell(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => TeacherProfilePage(
                    docId: widget.docId), // Navigate to TeacherProfile
              ),
            );
          },
          child: CircleAvatar(
            radius: 30.0,
            backgroundImage: profileImage != null && profileImage!.isNotEmpty
                ? NetworkImage(profileImage!)
                : const AssetImage('assets/teacher1.png') as ImageProvider,
          ),
        ),
      ],
    );
  }

  Widget _buildDueAmountSection() {
    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Row(
        children: [
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '0',
                style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
              ),
              Text(
                'Due Amount',
                style: TextStyle(fontSize: 16.0, color: Colors.grey),
              ),
            ],
          ),
          const Spacer(),
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.orange),
            onPressed: () {
              // Handle refresh
            },
          ),
        ],
      ),
    );
  }

  Widget _buildMainMenuSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Main Menu',
          style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8.0),
        GridView.count(
          crossAxisCount: 3,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            _buildMainMenuItem(Icons.assignment, 'Schedule', () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      TeacherTimetablePage(teacherId: widget.docId),
                ),
              );
            }),
            _buildMainMenuItem(Icons.star, 'Child\'s Goal', () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TeacherMenuMilestonePage(
                    teacherId: widget.docId,
                  ),
                ),
              );
              print('Child\'s Goal clicked');
            }),
            _buildMainMenuItem(Icons.people, 'Attendance', () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      AttendanceTeacherPage(docId: widget.docId),
                ),
              );
            }),
          ],
        ),
      ],
    );
  }

  Widget _buildMainMenuItem(IconData icon, String label, VoidCallback onTap) {
    // Get the screen width from MediaQuery
    double screenWidth = MediaQuery.of(context).size.width;

    // Scale the icon and text size based on the screen width
    double iconSize = screenWidth < 360
        ? 28.0
        : (screenWidth < 480 ? 32.0 : 35.0); // Smaller for smaller screens
    double fontSize = screenWidth < 360
        ? 11.0
        : (screenWidth < 480 ? 12.0 : 13.0); // Adjust text size accordingly

    return Padding(
      padding: const EdgeInsets.all(8.0), // Adjust padding as needed
      child: InkWell(
        onTap: onTap,
        borderRadius:
            BorderRadius.circular(8.0), // Rounded corners for the tap area
        child: Container(
          padding: const EdgeInsets.all(
              10.0), // Increased padding for better spacing
          decoration: BoxDecoration(
            color: Colors.white, // Clean background
            borderRadius: BorderRadius.circular(8.0),
            boxShadow: [
              BoxShadow(
                color: const Color.fromARGB(255, 0, 0, 0)
                    .withOpacity(0.2), // Light shadow for depth
                spreadRadius: 2,
                blurRadius: 5,
                offset: const Offset(0, 3), // Shadow position
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: iconSize, // Adjust icon size based on screen width
                color: Colors.blue,
              ),
              const SizedBox(height: 9.0), // Increased spacing
              Text(
                label,
                style: TextStyle(
                  fontSize: fontSize, // Adjust text size based on screen width
                  color: Colors.black, // Dark color for contrast
                ),
                textAlign: TextAlign.center, // Center text alignment
              ),
            ],
          ),
        ),
      ),
    );
  }
}
