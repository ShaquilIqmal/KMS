import 'package:flutter/material.dart';
import 'package:kms2/teacher/milestone/childListMilestone.dart';

class TeacherMenuMilestonePage extends StatefulWidget {
  final String teacherId; // Add this parameter to the constructor

  const TeacherMenuMilestonePage({Key? key, required this.teacherId})
      : super(key: key);

  @override
  State<TeacherMenuMilestonePage> createState() => _SelectYearPageState();
}

class _SelectYearPageState extends State<TeacherMenuMilestonePage> {
  final List<String> years = ['Year 4', 'Year 5', 'Year 6'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Select Year'),
      ),
      body: ListView.builder(
        itemCount: years.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(years[index]),
            onTap: () {
              // Pass the teacherId along with the year to the ChildListPage
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ChildListPage(
                    year: years[index],
                    teacherId: widget.teacherId, // Access widget properties
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
