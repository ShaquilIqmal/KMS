// ignore_for_file: use_build_context_synchronously

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:kms2/teacher/teacherDashboard.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'admin/adminDashboard.dart';
import 'service/database_service.dart'; // Import the new file
import 'user/dashboard.dart';
import 'user/register.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final DatabaseService _databaseService =
      DatabaseService(); // Instantiate the service

  Future<void> _login(BuildContext context) async {
    String username = usernameController.text.trim();
    String password = passwordController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter both username and password.'),
        ),
      );
      return;
    }

    try {
      // Check if the user is in the 'users' collection
      QuerySnapshot userQuerySnapshot =
          await _databaseService.getUserByName(username, collection: 'users');

      // Check if the user is in the 'teachers' collection
      QuerySnapshot teacherQuerySnapshot = await _databaseService
          .getUserByName(username, collection: 'teachers');

      // Check if the user is in the 'admins' collection
      QuerySnapshot adminQuerySnapshot =
          await _databaseService.getUserByName(username, collection: 'admins');

      if (userQuerySnapshot.docs.isNotEmpty) {
        // User found in 'users' collection
        DocumentSnapshot userDoc = userQuerySnapshot.docs.first;
        Map<String, dynamic> userData = userDoc.data() as Map<String, dynamic>;

        // Check password
        if (userData['password'] == password) {
          await _storeSessionData(userDoc.id, 'user'); // Store user session
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => DashboardPage(docId: userDoc.id),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Incorrect password. Please try again.'),
            ),
          );
        }
      } else if (teacherQuerySnapshot.docs.isNotEmpty) {
        // User found in 'teachers' collection
        DocumentSnapshot teacherDoc = teacherQuerySnapshot.docs.first;
        Map<String, dynamic> teacherData =
            teacherDoc.data() as Map<String, dynamic>;

        // Check password
        if (teacherData['password'] == password) {
          await _storeSessionData(
              teacherDoc.id, 'teacher'); // Store teacher session
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => TeacherDashboardPage(docId: teacherDoc.id),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Incorrect password. Please try again.'),
            ),
          );
        }
      } else if (adminQuerySnapshot.docs.isNotEmpty) {
        // User found in 'admins' collection
        DocumentSnapshot adminDoc = adminQuerySnapshot.docs.first;
        Map<String, dynamic> adminData =
            adminDoc.data() as Map<String, dynamic>;

        // Check password
        if (adminData['password'] == password) {
          await _storeSessionData(adminDoc.id, 'admin'); // Store admin session
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => AdminDashboardPage(docId: adminDoc.id),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Incorrect password. Please try again.'),
            ),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Username not found. Please try again.'),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to sign in: $e'),
        ),
      );
    }
  }

  Future<void> _storeSessionData(String userId, String role) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('userId', userId);
    await prefs.setString('role', role); // Store role (user/teacher/admin)
    print('Session stored. User ID: $userId, Role: $role');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _buildLoginPageBody(context),
    );
  }

  Widget _buildLoginPageBody(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          _buildHeader(context),
          _buildLoginForm(),
          _buildLoginButton(context),
          const SizedBox(height: 8.0),
          _buildCreateAccountLink(context),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(height: 100.0),
          Image.asset(
            'assets/logo.jpg',
            width: 150.0,
            height: 150.0,
          ),
          const SizedBox(height: 16.0),
          const Text(
            'Little I.M.A.N Kids',
            style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16.0),
        ],
      ),
    );
  }

  Widget _buildLoginForm() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          _buildTextFormField(
            controller: usernameController,
            labelText: 'Username',
            hintText: 'Enter your username',
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: passwordController,
            labelText: 'Password',
            hintText: 'Enter your password',
            obscureText: true,
          ),
        ],
      ),
    );
  }

  Widget _buildLoginButton(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ElevatedButton(
        onPressed: () => _login(context),
        child: const Text('Login'),
      ),
    );
  }

  Widget _buildCreateAccountLink(BuildContext context) {
    return TextButton(
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const RegAccPage()),
        );
      },
      child: const Text('Create a new account'),
    );
  }

  Widget _buildTextFormField({
    required TextEditingController controller,
    required String labelText,
    required String hintText,
    bool obscureText = false,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: labelText,
        hintText: hintText,
        border: const OutlineInputBorder(),
      ),
      obscureText: obscureText,
      keyboardType: keyboardType,
    );
  }
}
