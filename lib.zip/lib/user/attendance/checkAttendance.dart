import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Import intl package for date formatting
import 'package:kms2/service/database_service.dart'; // Update with your actual import

class CheckAttendancePage extends StatefulWidget {
  final String childId; // Field to hold the child's ID
  final String selectedYear;

  const CheckAttendancePage({
    super.key,
    required this.childId, // Require the child's ID
    required this.selectedYear,
  });

  @override
  State<CheckAttendancePage> createState() => _CheckAttendancePageState();
}

class _CheckAttendancePageState extends State<CheckAttendancePage> {
  String childName = 'Loading...'; // Field to hold the child's name
  String? childProfileImage; // Field to hold the child's profile image URL
  List<Map<String, dynamic>> attendanceHistory = []; // Holds attendance history
  double attendancePercentage = 0.0; // Holds attendance percentage
  bool isLoading = true; // Track loading state

  @override
  void initState() {
    super.initState();
    fetchChildDetails(); // Fetch the child's name and profile image
    fetchChildAttendance(); // Fetch the child's attendance history
  }

  Future<void> fetchChildDetails() async {
    try {
      var childDetails =
          await DatabaseService().getChildDetailsById(widget.childId);
      setState(() {
        childName = childDetails['name'];
        childProfileImage =
            childDetails['profileImage']; // Update the profile image
      });
    } catch (e) {
      print('Error fetching child details: $e');
    }
  }

  Future<void> fetchChildAttendance() async {
    try {
      // Fetch all attendance data
      QuerySnapshot snapshot =
          await DatabaseService().attendanceCollection.get();
      bool attendanceFound = false;

      for (var doc in snapshot.docs) {
        var data = doc.data() as Map<String, dynamic>;

        // Fetch attendanceHistory
        List<dynamic> attendanceHistoryData = data['attendanceHistory'];

        for (var record in attendanceHistoryData) {
          if (record['childID'] == widget.childId) {
            setState(() {
              attendanceHistory =
                  List<Map<String, dynamic>>.from(record['records']);
              isLoading = false; // Stop loading once data is fetched
            });
            attendanceFound = true;
            break;
          }
        }

        // Fetch attendancePercentage
        List<dynamic> attendanceRecordData = data['attendanceRecord'];
        for (var record in attendanceRecordData) {
          if (record['childID'] == widget.childId) {
            setState(() {
              attendancePercentage = record['attendancePercentage'];
            });
            break;
          }
        }
      }

      // If no attendance was found for this child
      if (!attendanceFound) {
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      print('Error fetching attendance history: $e');
      setState(() {
        isLoading = false; // Stop loading even if there's an error
      });
    }
  }

  String _formatTimestamp(Timestamp timestamp) {
    DateTime dateTime = timestamp
        .toDate()
        .add(const Duration(hours: 8)); // Adjust for timezone if necessary
    return "${dateTime.hour % 12 == 0 ? 12 : dateTime.hour % 12}:${dateTime.minute.toString().padLeft(2, '0')} ${dateTime.hour >= 12 ? 'PM' : 'AM'}";
  }

  String _formatDate(String date) {
    // Assuming the date is in "YYYY-MM-DD" format
    DateTime dateTime = DateTime.parse(date);
    return DateFormat('dd-MM-yyyy').format(dateTime);
  }

  @override
  Widget build(BuildContext context) {
    String currentDate = DateFormat('dd-MM-yyyy')
        .format(DateTime.now()); // Get current date in "DD-MM-YYYY"
    double titleFontSize = 20.0; // Adjustable font size for the title

    return Scaffold(
      appBar: AppBar(
        title: RichText(
          text: TextSpan(
            text: 'Child Attendance - ',
            style: const TextStyle(
              color: Colors.black,
              fontSize: 20,
            ),
            children: <TextSpan>[
              TextSpan(
                text: childName, // Display the fetched child's name
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: 20,
                ),
              ),
            ],
          ),
        ),
        backgroundColor: Colors.blue[100],
      ),
      body: isLoading
          ? const Center(
              child:
                  CircularProgressIndicator(), // Show loading indicator while fetching
            )
          : Column(
              children: [
                // Child details with a light grey outline and padding
                Padding(
                  padding: const EdgeInsets.all(
                      10.0), // Padding around the container
                  child: Container(
                    padding: const EdgeInsets.all(16.0),
                    margin: const EdgeInsets.symmetric(
                        vertical: 8.0), // Add margin for spacing
                    decoration: BoxDecoration(
                      color: Colors.white, // Background color for the container
                      border: Border.all(
                          color: const Color.fromARGB(255, 45, 45, 45)),
                      borderRadius:
                          BorderRadius.circular(8.0), // Rounded corners
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 40, // Size of the circular icon
                          backgroundImage: childProfileImage != null &&
                                  childProfileImage!.isNotEmpty
                              ? NetworkImage(
                                  childProfileImage!) // Use the child's profile image
                              : const AssetImage('assets/child1.png')
                                  as ImageProvider, // Fallback image
                        ),
                        const SizedBox(
                            width: 16), // Space between the icon and details
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                childName,
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                widget.selectedYear,
                                style: const TextStyle(fontSize: 16),
                              ),
                              Text(
                                'Attendance Percentage: ${attendancePercentage.toString()}%', // Display attendance percentage
                                style: const TextStyle(fontSize: 16),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Title for Attendance Records
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16.0, vertical: 0.0),
                  child: Text(
                    'Attendance Record',
                    style: TextStyle(
                      fontSize: titleFontSize, // Adjustable font size
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                // Display the attendance history
                attendanceHistory.isEmpty
                    ? const Text(
                        'No attendance records found.',
                        style: TextStyle(fontSize: 16),
                      )
                    : Expanded(
                        child: Padding(
                          padding: const EdgeInsets.all(
                              13.0), // Add padding around the ListView
                          child: ListView.builder(
                            itemCount: attendanceHistory.length,
                            itemBuilder: (context, index) {
                              var record = attendanceHistory[index];
                              bool isToday = _formatDate(record['date']) ==
                                  currentDate; // Check if the date matches today
                              return Container(
                                margin: const EdgeInsets.symmetric(
                                    vertical:
                                        4.0), // Add vertical margin for spacing
                                decoration: BoxDecoration(
                                  color: Colors
                                      .white, // Background color for the container
                                  border: isToday
                                      ? Border.all(
                                          color: Colors.blue,
                                          width: 2) // Blue outline if today
                                      : Border.all(
                                          color: Colors
                                              .grey[300]!), // Default border
                                  borderRadius: BorderRadius.circular(
                                      4.0), // Rounded corners
                                ),
                                child: ListTile(
                                  title: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      // Display date
                                      Text(
                                        _formatDate(record[
                                            'date']), // Format date for display
                                        style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                        ), // Optional styling
                                      ),
                                      // Check status and display accordingly
                                      if (record['status'] == 'present') ...[
                                        Text(
                                          'Arrived at: ${record['arrivedAt'] != null ? _formatTimestamp(record['arrivedAt'] as Timestamp) : 'N/A'}',
                                          style: const TextStyle(
                                            fontSize: 12,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        // Check if returnedAt is not null and display accordingly
                                        if (record['returnAt'] != null) ...[
                                          Text(
                                            'Returned at: ${_formatTimestamp(record['returnAt'] as Timestamp)}',
                                            style: const TextStyle(
                                              fontSize: 12,
                                              color: Colors.grey,
                                            ),
                                          ),
                                          const Text(
                                            'Returned',
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: Colors.green,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ] else ...[
                                          const Text(
                                            'Returned at: N/A',
                                            style: const TextStyle(
                                              fontSize: 12,
                                              color: Colors.grey,
                                            ),
                                          ),
                                          // If returnedAt is null, display "At school" and "Returned at: N/A"
                                          const Text(
                                            'At school',
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: Colors.orange,
                                            ),
                                          ),
                                        ],
                                      ] else if (record['status'] ==
                                          'absent') ...[
                                        const Text(
                                          'Arrived at: N/A',
                                          style: const TextStyle(
                                            fontSize: 12,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        const Text(
                                          'Returned at: N/A',
                                          style: const TextStyle(
                                            fontSize: 12,
                                            color: Colors.grey,
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                  trailing: Text(
                                    '${record['status']}',
                                    style: TextStyle(
                                      fontSize: 16, // Optional styling
                                      color: record['status'] == 'present'
                                          ? Colors.green
                                          : Colors
                                              .red, // Green for present, red for absent
                                      fontWeight:
                                          FontWeight.bold, // Make text bold
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
              ],
            ),
    );
  }
}
