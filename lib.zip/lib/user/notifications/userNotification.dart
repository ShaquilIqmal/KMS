import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:kms2/user/notifications/notificationDetails.dart';

class UserNotificationPage extends StatefulWidget {
  final String userDocId;

  const UserNotificationPage({Key? key, required this.userDocId})
      : super(key: key);

  @override
  State<UserNotificationPage> createState() => _UserNotificationPageState();
}

class _UserNotificationPageState extends State<UserNotificationPage> {
  late Future<List<Map<String, dynamic>>> notifications;

  @override
  void initState() {
    super.initState();
    print('User Doc ID: ${widget.userDocId}');
    notifications = fetchNotifications();
  }

  Future<List<Map<String, dynamic>>> fetchNotifications() async {
    try {
      print('Fetching notifications...');
      QuerySnapshot snapshot =
          await FirebaseFirestore.instance.collection('notifications').get();

      print('Snapshot received: ${snapshot.docs.length} document(s) found.');

      List<Map<String, dynamic>> notificationList = [];
      for (var doc in snapshot.docs) {
        List<dynamic> recipients = doc['recipients'];
        for (var recipient in recipients) {
          if (recipient['id'] == widget.userDocId) {
            print(
                'Displaying notification: ${doc['title']} - ${doc['message']}');
            notificationList.add(doc.data() as Map<String, dynamic>);
            break;
          }
        }
      }

      notificationList.sort((a, b) {
        Timestamp timestampA = a['timestamp'];
        Timestamp timestampB = b['timestamp'];
        return timestampB.seconds.compareTo(timestampA.seconds);
      });

      return notificationList;
    } catch (e) {
      print('Error fetching notifications: $e');
      return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('User Notification Page'),
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: notifications,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            print('Loading notifications...');
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            print('Error occurred: ${snapshot.error}');
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            print('No notifications found for userDocId: ${widget.userDocId}');
            return const Center(child: Text('No notifications found.'));
          }

          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              print(
                  'Building notification card for index: $index'); // Debugging statement

              var notification = snapshot.data![index];

              String title = notification['title'] ?? 'No Title';
              String message = notification['message'] ?? 'No Message';
              Timestamp timestamp = notification['timestamp'];
              String timestampStr =
                  DateTime.fromMillisecondsSinceEpoch(timestamp.seconds * 1000)
                      .toString();

              // Truncate the message to display a preview
              String truncatedMessage = message.length > 50
                  ? message.substring(0, 50) + '...'
                  : message;

              print('Displaying notification: $title - $message');

              return GestureDetector(
                onTap: () {
                  // Debugging message to check if onTap is triggered
                  print('Card tapped!'); // Ensure this message is printed
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => NotificationDetailPage(
                        notification: notification,
                      ),
                    ),
                  );
                },
                child: Card(
                  margin:
                      const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  child: ListTile(
                    title: Text(
                      title,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold), // Bold title
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(truncatedMessage),
                        const SizedBox(height: 8),
                        Text(
                          'Sent on: $timestampStr',
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
