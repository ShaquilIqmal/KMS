import 'package:flutter/material.dart';
import 'package:kms2/user/registerchild/registerchildE.dart';

class RegisterChildDPage extends StatefulWidget {
  final String docId;
  final Map<String, dynamic> dataA;
  final Map<String, dynamic> dataB;
  final Map<String, dynamic> dataC;

  RegisterChildDPage({
    Key? key,
    required this.docId,
    required this.dataA,
    required this.dataB,
    required this.dataC,
  }) : super(key: key);

  @override
  State<RegisterChildDPage> createState() => _RegisterChildDPageState();
}

class _RegisterChildDPageState extends State<RegisterChildDPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController telController = TextEditingController();
  final TextEditingController relationshipController = TextEditingController();

  /* @override
  void initState() {
    super.initState();
    print('docId: ${widget.docId}');
    print('dataC: ${widget.dataC}');
  }*/

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Sec D - Emergency Contact"),
        backgroundColor: Colors.blue[100],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: _buildFormContent(),
      ),
    );
  }

  Widget _buildFormContent() {
    return Form(
      key: _formKey,
      child: ListView(
        children: <Widget>[
          const Text(
            "D. Emergency Contact",
            style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: nameController,
            labelText: 'Name',
            hintText: 'Enter name',
            validator: (value) =>
                value == null || value.isEmpty ? 'Please enter name' : null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: telController,
            labelText: 'Telephone',
            hintText: 'Enter telephone number',
            keyboardType: TextInputType.phone,
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter telephone number'
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: relationshipController,
            labelText: 'Relationship',
            hintText: 'Enter relationship',
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter relationship'
                : null,
          ),
          const SizedBox(height: 16.0),
          ElevatedButton(
            onPressed: _submitData,
            child: const Text('Submit'),
          ),
        ],
      ),
    );
  }

  void _submitData() {
    if (_formKey.currentState?.validate() ?? false) {
      String emergencyName = nameController.text;
      String emergencyTel = telController.text;
      String emergencyRelationship = relationshipController.text;

      // Create a Map to hold the data
      Map<String, dynamic> dataD = {
        'nameM': emergencyName,
        'telM': emergencyTel,
        'relationshipM': emergencyRelationship,
      };

      print('docId: ${widget.docId}');
      print('dataA: ${widget.dataA}');
      print('dataB: ${widget.dataB}');
      print('dataC: ${widget.dataC}');
      print('dataD: $dataD');

      // Here you can navigate to the next section or perform any necessary operations with the data
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => RegisterChildEPage(
                  docId: widget.docId,
                  dataA: widget.dataA,
                  dataB: widget.dataB,
                  dataC: widget.dataC,
                  dataD: dataD)));
    }
  }

  Widget _buildTextFormField({
    required TextEditingController controller,
    required String labelText,
    required String hintText,
    bool obscureText = false,
    TextInputType keyboardType = TextInputType.text,
    bool readOnly = false,
    String? Function(String?)? validator,
    InputDecoration? decoration,
  }) {
    return TextFormField(
      controller: controller,
      decoration: decoration ??
          InputDecoration(
            labelText: labelText,
            hintText: hintText,
            border: const OutlineInputBorder(),
          ),
      obscureText: obscureText,
      keyboardType: keyboardType,
      readOnly: readOnly,
      validator: validator,
    );
  }
}
