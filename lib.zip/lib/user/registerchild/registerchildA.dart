import 'package:flutter/material.dart';

//import 'package:kms2/utility.dart';

import 'registerchildB.dart';

class RegisterChildPage extends StatefulWidget {
  final String docId;

  const RegisterChildPage({Key? key, required this.docId}) : super(key: key);

  @override
  State<RegisterChildPage> createState() => _RegisterChildPageState();
}

class _RegisterChildPageState extends State<RegisterChildPage> {
  String? childGender; // Declare a local variable to hold the selected gender
  DateTime? selectedDate; // Variable to hold the selected date
  final _formKey = GlobalKey<FormState>();
  final TextEditingController childNameController = TextEditingController();
  final TextEditingController childAddressController = TextEditingController();
  final TextEditingController childDateofBirthController =
      TextEditingController();
  final TextEditingController childAgeController = TextEditingController();
  final TextEditingController childmyKidController = TextEditingController();
  final TextEditingController childReligionController = TextEditingController();
/*
  void initState() {
    super.initState();
    Utility.fetchUserData(widget.docId);
  }*/

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Sec A - Child's Particular"),
        backgroundColor: Colors.blue[100],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: _buildFormContent(),
      ),
    );
  }

  Widget _buildFormContent() {
    return Form(
      key: _formKey,
      child: ListView(
        children: <Widget>[
          const Text(
            "A. Child's Particular",
            style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: childNameController,
            labelText: 'Full Name (Child)',
            hintText: 'name',
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter your name'
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildGenderSelection(
            groupValue: childGender,
            onChanged: (value) {
              setState(() {
                childGender = value;
              });
            },
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: childAddressController,
            labelText: 'Address',
            hintText: 'address',
            validator: (value) => value == null || value.isEmpty
                ? "Please enter child's address"
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildDateOfBirthField(),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: childAgeController,
            labelText: 'Age',
            hintText: 'age',
            readOnly: true,
            validator: (value) => value == null || value.isEmpty
                ? "Please select child's date of birth to calculate age"
                : null,
            decoration: const InputDecoration(
              labelText: 'Age',
              hintText: 'age',
              border: OutlineInputBorder(),
              fillColor: Color.fromARGB(255, 216, 216, 216),
              filled: true,
            ),
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: childmyKidController, //tukar
            labelText: 'myKid no',
            hintText: 'myKid no',
            keyboardType: TextInputType.phone,
            validator: (value) => value == null || value.isEmpty
                ? "Please enter child's myKid number"
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: childReligionController, //tukar
            labelText: 'Religion',
            hintText: 'Religion',
            validator: (value) => value == null || value.isEmpty
                ? "Please enter child's religion"
                : null,
          ),
          const SizedBox(height: 16.0),
          ElevatedButton(
            onPressed: _submitData,
            child: const Text('Next - Section B'),
          ),
        ],
      ),
    );
  }

  void _submitData() async {
    if (_formKey.currentState?.validate() ?? false) {
      String childName = childNameController.text;
      String childAddress = childAddressController.text;
      String childDateOfBirth = childDateofBirthController.text;
      String childAge = childAgeController.text;
      String childMyKid = childmyKidController.text;
      String childReligion = childReligionController.text;

      // Format the age as "Year X"
      String formattedAge = 'Year $childAge';
      print('Formatted Age: $formattedAge');

      // Create a Map to hold the data
      Map<String, dynamic> dataA = {
        'nameC': childName,
        'genderC': childGender,
        'addressC': childAddress,
        'dateOfBirthC': childDateOfBirth,
        'yearID': formattedAge,
        'myKidC': childMyKid,
        'religionC': childReligion,
      };

      print('DocId: ${widget.docId}');
      print('DataB: $dataA');

      // Navigate to Section B
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) =>
                RegisterChildBPage(docId: widget.docId, dataA: dataA)),
      );
    }
  }

  Widget _buildTextFormField({
    required TextEditingController controller,
    required String labelText,
    required String hintText,
    bool obscureText = false,
    TextInputType keyboardType = TextInputType.text,
    bool readOnly = false,
    String? Function(String?)? validator,
    InputDecoration? decoration,
  }) {
    return TextFormField(
      controller: controller,
      decoration: decoration ??
          InputDecoration(
            labelText: labelText,
            hintText: hintText,
            border: const OutlineInputBorder(),
          ),
      obscureText: obscureText,
      keyboardType: keyboardType,
      readOnly: readOnly,
      validator: validator,
    );
  }

  Widget _buildGenderSelection({
    required String? groupValue,
    required ValueChanged<String?> onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Gender',
          style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
        ),
        RadioListTile<String>(
          title: const Text('Male'),
          value: 'Male',
          groupValue: groupValue,
          onChanged: onChanged,
        ),
        RadioListTile<String>(
          title: const Text('Female'),
          value: 'Female',
          groupValue: groupValue,
          onChanged: onChanged,
        ),
      ],
    );
  }

  Widget _buildDateOfBirthField() {
    return TextFormField(
      controller: childDateofBirthController,
      readOnly: true,
      decoration: const InputDecoration(
        labelText: 'Date of Birth',
        hintText: 'Select Date of Birth',
        border: OutlineInputBorder(),
      ),
      onTap: () async {
        DateTime now = DateTime.now();
        DateTime initialDate =
            now.subtract(const Duration(days: 365 * 5)); // 3 years ago
        DateTime firstDate =
            now.subtract(const Duration(days: 365 * 7)); // 6 years ago
        DateTime lastDate =
            now.subtract(const Duration(days: 365 * 5)); // 3 years ago

        DateTime? pickedDate = await showDatePicker(
          context: context,
          initialDate: initialDate,
          firstDate: firstDate,
          lastDate: lastDate,
        );

        if (pickedDate != null) {
          setState(() {
            selectedDate = pickedDate;
            childDateofBirthController.text =
                "${pickedDate.toLocal()}".split(' ')[0];
            _calculateAge(pickedDate);
          });
        }
      },
      validator: (value) => value == null || value.isEmpty
          ? "Please select child's date of birth"
          : null,
    );
  }

  void _calculateAge(DateTime birthDate) {
    DateTime today = DateTime.now();
    int age = today.year - birthDate.year;
    if (today.month < birthDate.month ||
        (today.month == birthDate.month && today.day < birthDate.day)) {
      age--;
    }
    childAgeController.text = age.toString();
  }
}
