// lib/user/userProfile/ProfilePage.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:kms2/service/cloudinary_service.dart';
import 'package:kms2/service/zmodel/childmodel.dart';
import 'package:kms2/service/zmodel/usermodel.dart';
import 'package:kms2/user/userProfile/userChildDetail.dart';

class ProfilePage extends StatefulWidget {
  final String docId;

  const ProfilePage({Key? key, required this.docId}) : super(key: key);

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final CloudinaryService _cloudinaryService = CloudinaryService();
  final ImagePicker _picker = ImagePicker();
  User? _user; // User object
  bool _isUploading = false;
  List<Child> _children = []; // List to hold Child objects
  String? _userProfileImage; // Variable to hold user profile image URL

  @override
  void initState() {
    super.initState();
    _loadProfileData();
  }

  Future<void> _loadProfileData() async {
    try {
      DocumentSnapshot userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.docId)
          .get();

      if (userDoc.exists) {
        setState(() {
          _user = User.fromDocument(userDoc);
          _userProfileImage = userDoc['profileImage'];
        });

        if (_user!.childIds.isNotEmpty) {
          _loadChildrenData(_user!.childIds);
        }
      } else {
        print("User document does not exist");
      }
    } catch (e) {
      print("Error loading profile data: $e");
    }
  }

  Future<void> _loadChildrenData(List<String> childIds) async {
    try {
      QuerySnapshot childrenSnapshot = await FirebaseFirestore.instance
          .collection('child')
          .where(FieldPath.documentId, whereIn: childIds)
          .get();

      setState(() {
        _children = childrenSnapshot.docs.map((doc) {
          return Child.fromDocument(doc);
        }).toList();
      });
    } catch (e) {
      print("Error loading children data: $e");
    }
  }

  Future<void> _pickImage() async {
    final XFile? pickedFile =
        await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _isUploading = true;
      });
      String imageUrl = await _uploadImageToCloudinary(pickedFile.path);
      if (imageUrl.isNotEmpty) {
        _updateProfileImage(imageUrl);
      } else {
        setState(() {
          _isUploading = false;
        });
      }
    }
  }

  Future<String> _uploadImageToCloudinary(String filePath) async {
    try {
      String imageUrl = await _cloudinaryService.uploadImage(filePath);
      return imageUrl;
    } catch (e) {
      print("Error uploading image: $e");
      return '';
    }
  }

  Future<void> _updateProfileImage(String imageUrl) async {
    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.docId)
          .update({'profileImage': imageUrl});
      setState(() {
        _userProfileImage = imageUrl;
        _isUploading = false;
      });
      print("Profile image updated!");
    } catch (e) {
      print("Error updating profile image: $e");
      setState(() {
        _isUploading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Existing code for user profile image...
              _userProfileImage != null && _userProfileImage!.isNotEmpty
                  ? CircleAvatar(
                      radius: 80,
                      backgroundImage: NetworkImage(_userProfileImage!),
                    )
                  : CircleAvatar(
                      radius: 80,
                      backgroundColor: Colors.grey[300],
                      child: const Icon(Icons.person,
                          size: 50, color: Colors.white),
                    ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _pickImage,
                child: const Text('Change Profile Picture'),
              ),
              const SizedBox(height: 16),
              Text('Name: ${_user?.name ?? 'N/A'}',
                  style: const TextStyle(fontSize: 16.0)),
              const SizedBox(height: 8),
              Text('Phone: ${_user?.noTel ?? 'N/A'}',
                  style: const TextStyle(fontSize: 16.0)),
              const SizedBox(height: 8),
              Text('Email: ${_user?.email ?? 'N/A'}',
                  style: const TextStyle(fontSize: 16.0)),
              const SizedBox(height: 16),
              const Text('Children:',
                  style:
                      TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
              if (_children.isNotEmpty)
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _children.length,
                  itemBuilder: (context, index) {
                    final child = _children[index];
                    return GestureDetector(
                      onTap: () {
                        print("Child tapped: ${child.sectionA['nameC']}");
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                UserChildDetailPage(child: child),
                          ),
                        );
                      },
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundImage: child.profileImage != null &&
                                  child.profileImage!.isNotEmpty
                              ? NetworkImage(child
                                  .profileImage!) // Use the profileImage directly
                              : const AssetImage('assets/child1.png')
                                  as ImageProvider, // Fallback image
                          child: child.profileImage == null ||
                                  child.profileImage!.isEmpty
                              ? const Icon(Icons.child_care, size: 40)
                              : null,
                        ),
                        title: Text(child.name), // Use the getter for name
                      ),
                    );
                  },
                )
              else
                const Text('No children registered.'),
              if (_isUploading)
                const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: CircularProgressIndicator(),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
