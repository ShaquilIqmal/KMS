import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Importing the intl package for date formatting

class GenerateFeesPage extends StatefulWidget {
  final String adminDocId;

  const GenerateFeesPage({Key? key, required this.adminDocId})
      : super(key: key);

  @override
  _GenerateFeesPageState createState() => _GenerateFeesPageState();
}

class _GenerateFeesPageState extends State<GenerateFeesPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<DocumentSnapshot> _feesList = [];
  List<String> _selectedFees = []; // To hold selected fee IDs
  List<DocumentSnapshot> _childrenList = []; // List of children
  List<String> _selectedChildren = []; // To hold selected children IDs
  String? _selectedYear; // To hold the currently selected year
  bool _selectAll = false; // Boolean to track select all state

  @override
  void initState() {
    super.initState();
    _fetchFees(); // Fetch available fees
  }

  Future<void> _fetchFees() async {
    QuerySnapshot snapshot = await _firestore.collection('fees').get();
    setState(() {
      _feesList = snapshot.docs;
    });
  }

  Future<void> _fetchChildren(String yearID) async {
    try {
      print('Fetching children for year: $yearID');
      QuerySnapshot snapshot = await _firestore
          .collection('child')
          .where('SectionA.yearID', isEqualTo: yearID)
          .get();
      print('Fetched ${snapshot.docs.length} children');

      setState(() {
        _childrenList = snapshot.docs;
        _selectedYear = yearID; // Set the selected year
        _selectedChildren.clear(); // Clear previous selections
        _selectAll = false; // Reset select all state
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error fetching children: $e')),
      );
    }
  }

  void _toggleSelectAll() {
    setState(() {
      _selectAll = !_selectAll;
      _selectedChildren.clear(); // Clear previous selections
      if (_selectAll) {
        _selectedChildren.addAll(_childrenList.map((child) => child.id));
      }
    });
  }

  Future<void> _generateFeesForSelectedChildren() async {
    DateTime dueDate = DateTime.now()
        .add(Duration(days: 10)); // Set due date to 10 days from now
    String formattedDueDate =
        DateFormat('yyyy-MM-dd').format(dueDate); // Format the due date

    for (var child in _childrenList
        .where((child) => _selectedChildren.contains(child.id))) {
      for (var feeId in _selectedFees) {
        // Check if the fee already exists in the payments subcollection
        DocumentSnapshot paymentSnapshot = await _firestore
            .collection('child')
            .doc(child.id)
            .collection('payments')
            .doc(feeId)
            .get();

        if (paymentSnapshot.exists) {
          // If the payment already exists, show an error snackbar
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content: Text(
                    'Fee ${feeId} already exists for ${child['SectionA']['nameC']}!')),
          );
        } else {
          // If it doesn't exist, create the fee record
          var fee = _feesList.firstWhere((fee) => fee.id == feeId);
          await _firestore
              .collection('child')
              .doc(child.id)
              .collection('payments')
              .doc(feeId)
              .set({
            'feeType': fee['feeType'],
            'amount': fee['amount'],
            'description': fee['description'],
            'category': fee['category'],
            'dueDate': formattedDueDate, // Store formatted due date
            'paid': false,
          });
        }
      }
    }

    // Show success message if fees were added
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content:
              Text('Fees generated for selected children in $_selectedYear!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Generate Fees'),
        backgroundColor: Colors.blue[100],
      ),
      body: Center(
        child: Column(
          children: [
            // Scrollable container for fees
            Container(
              height: MediaQuery.of(context).size.height * 0.3,
              color: Colors.grey[300],
              child: _feesList.isEmpty
                  ? const Center(child: CircularProgressIndicator())
                  : ListView.builder(
                      itemCount: _feesList.length,
                      itemBuilder: (context, index) {
                        final fee = _feesList[index];
                        return CheckboxListTile(
                          title: Text(fee['feeType']),
                          value: _selectedFees.contains(fee.id),
                          onChanged: (bool? selected) {
                            setState(() {
                              if (selected == true) {
                                _selectedFees.add(fee.id);
                              } else {
                                _selectedFees.remove(fee.id);
                              }
                            });
                          },
                        );
                      },
                    ),
            ),
            const SizedBox(height: 20), // Spacing

            // Row of buttons for selecting year
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () => _fetchChildren('Year 4'),
                  child: const Text('Year 4'),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () => _fetchChildren('Year 5'),
                  child: const Text('Year 5'),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () => _fetchChildren('Year 6'),
                  child: const Text('Year 6'),
                ),
              ],
            ),
            const SizedBox(height: 20), // Spacing

            // List of children for the selected year
            if (_childrenList.isNotEmpty) ...[
              Text('Children in $_selectedYear:',
                  style: TextStyle(fontSize: 18)),
              ElevatedButton(
                onPressed: _toggleSelectAll,
                child: Text(_selectAll ? 'Deselect All' : 'Select All'),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: _childrenList.length,
                  itemBuilder: (context, index) {
                    final child = _childrenList[index];
                    return CheckboxListTile(
                      title: Text(child['SectionA']
                          ['nameC']), // Accessing nameC in SectionA
                      value: _selectedChildren.contains(child.id),
                      onChanged: (bool? selected) {
                        setState(() {
                          if (selected == true) {
                            _selectedChildren.add(child.id);
                          } else {
                            _selectedChildren.remove(child.id);
                          }
                        });
                      },
                    );
                  },
                ),
              ),
            ],
            const SizedBox(height: 20), // Spacing
            ElevatedButton(
              onPressed: _generateFeesForSelectedChildren,
              child: const Text('Add Fees to Selected Children'),
            ),
          ],
        ),
      ),
    );
  }
}
