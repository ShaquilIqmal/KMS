import 'package:flutter/material.dart';
import 'package:kms2/admin/payment/generateFee.dart';
import 'package:kms2/admin/payment/manageFee.dart';
import 'package:kms2/admin/payment/userFeeList.dart';

class FeeOptionPage extends StatelessWidget {
  final String adminDocId;

  const FeeOptionPage({Key? key, required this.adminDocId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Fee Management'),
        backgroundColor: Colors.blue[100],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildOptionButton(
              context,
              'Manage Fees',
              () {
                // Navigate to the Fee Management Page
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          ManageFeesPage(adminDocId: adminDocId)),
                );
              },
            ),
            const SizedBox(height: 16.0),
            _buildOptionButton(
              context,
              'Generate Fees',
              () {
                // Navigate to Unpaid Fees Page
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          GenerateFeesPage(adminDocId: adminDocId)),
                );
              },
            ),
            const SizedBox(height: 16.0),
            _buildOptionButton(
              context,
              'User Fees',
              () {
                // Navigate to Paid Fees Page
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          UserFeesListPage(adminDocId: adminDocId)),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOptionButton(
      BuildContext context, String label, VoidCallback onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      child: Text(label),
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 32.0),
        textStyle: const TextStyle(fontSize: 18),
      ),
    );
  }
}
