import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ManageFeesPage extends StatefulWidget {
  final String adminDocId;

  const ManageFeesPage({Key? key, required this.adminDocId}) : super(key: key);

  @override
  _ManageFeesPageState createState() => _ManageFeesPageState();
}

class _ManageFeesPageState extends State<ManageFeesPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final TextEditingController _feeTypeController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();

  String? _selectedCategory;
  final List<String> _categories = [
    'Year 4',
    'Year 5',
    'Year 6',
    'All Students',
    'New Registration',
  ];

  List<DocumentSnapshot> _feesList = [];
  String? _editingFeeId; // To store the ID of the fee being edited

  @override
  void initState() {
    super.initState();
    _fetchFees();
  }

  Future<void> _fetchFees() async {
    QuerySnapshot snapshot = await _firestore.collection('fees').get();
    setState(() {
      _feesList = snapshot.docs;
    });
  }

  Future<void> _addOrUpdateFee() async {
    final feeType = _feeTypeController.text;
    final amount = double.tryParse(_amountController.text);
    final description = _descriptionController.text;

    if (feeType.isNotEmpty && amount != null && _selectedCategory != null) {
      // Generate initials from the feeType
      String initials =
          feeType.split(' ').map((word) => word[0].toUpperCase()).join('');

      if (_editingFeeId == null) {
        // Adding a new fee
        DocumentReference newDocRef = _firestore
            .collection('fees')
            .doc(); // Create a new document reference
        String feeId =
            '${initials}_${newDocRef.id}'; // Combine initials with the generated ID

        await newDocRef.set({
          'feeId': feeId, // Optionally store the feeId in the document
          'feeType': feeType,
          'amount': amount,
          'description': description,
          'category': _selectedCategory,
          'dueDate': Timestamp.now(),
        });
      } else {
        // Updating an existing fee
        await _firestore.collection('fees').doc(_editingFeeId).update({
          'feeType': feeType,
          'amount': amount,
          'description': description,
          'category': _selectedCategory,
        });
        _editingFeeId = null; // Reset the editing fee ID after update
      }

      _feeTypeController.clear();
      _amountController.clear();
      _descriptionController.clear();
      setState(() {
        _selectedCategory = null;
      });
      await _fetchFees();
    }
  }

  Future<void> _deleteFee(String feeId) async {
    DocumentSnapshot feeDoc =
        await _firestore.collection('fees').doc(feeId).get();

    // Move the fee to feeHistory
    await _firestore
        .collection('feeHistory')
        .doc(feeId)
        .set(feeDoc.data() as Map<String, dynamic>);

    // Delete the fee from the fees collection
    await _firestore.collection('fees').doc(feeId).delete();

    await _fetchFees();
  }

  Future<void> _updateExistingFees() async {
    QuerySnapshot snapshot = await _firestore.collection('fees').get();

    for (var doc in snapshot.docs) {
      if (!(doc.data() as Map<String, dynamic>).containsKey('category')) {
        await doc.reference.update({'category': 'Unspecified'});
      }
    }
  }

  void _editFee(DocumentSnapshot fee) {
    final data = fee.data() as Map<String, dynamic>;

    _feeTypeController.text = data['feeType'];
    _amountController.text = data['amount'].toString();
    _descriptionController.text = data['description'];
    _selectedCategory = data['category'];

    setState(() {
      _editingFeeId = fee.id; // Set the ID of the fee being edited
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Manage Fees'),
        backgroundColor: Colors.blue[100],
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _updateExistingFees,
            tooltip: 'Update Existing Fees',
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildFeeInputForm(),
            const SizedBox(height: 16.0),
            Expanded(child: _buildFeesList()),
          ],
        ),
      ),
    );
  }

  Widget _buildFeeInputForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: _feeTypeController,
          decoration: const InputDecoration(labelText: 'Fee Type'),
        ),
        TextField(
          controller: _amountController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Amount'),
        ),
        TextField(
          controller: _descriptionController,
          decoration: const InputDecoration(labelText: 'Description'),
        ),
        const SizedBox(height: 16.0),
        DropdownButtonFormField<String>(
          value: _selectedCategory,
          decoration: const InputDecoration(labelText: 'Select Category'),
          items: _categories.map((String category) {
            return DropdownMenuItem<String>(
              value: category,
              child: Text(category),
            );
          }).toList(),
          onChanged: (String? newValue) {
            setState(() {
              _selectedCategory = newValue;
            });
          },
          isExpanded: true,
        ),
        const SizedBox(height: 16.0),
        ElevatedButton(
          onPressed: _addOrUpdateFee,
          child: Text(_editingFeeId == null ? 'Add Fee' : 'Update Fee'),
        ),
      ],
    );
  }

  Widget _buildFeesList() {
    return ListView.builder(
      itemCount: _feesList.length,
      itemBuilder: (context, index) {
        final fee = _feesList[index];
        final data = fee.data() as Map<String, dynamic>?; // Cast to Map

        // Check for null and existence of category
        String category = (data != null && data.containsKey('category'))
            ? data['category']
            : 'N/A';

        return Card(
          margin: const EdgeInsets.symmetric(vertical: 8.0),
          child: ListTile(
            title: Text(data?['feeType'] ?? 'N/A'),
            subtitle: Text(
                '${data?['description'] ?? ''} - \$${data?['amount'] ?? 0} ($category)'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.edit, color: Colors.blue),
                  onPressed: () => _editFee(fee), // Edit fee
                ),
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () => _deleteFee(fee.id),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
