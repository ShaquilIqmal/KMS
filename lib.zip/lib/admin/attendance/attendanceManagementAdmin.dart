import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:kms2/admin/attendance/attendanceChildDetail.dart';
import 'package:kms2/service/database_service.dart';

class AttendanceManagementAdminPage extends StatefulWidget {
  const AttendanceManagementAdminPage({super.key});

  @override
  State<AttendanceManagementAdminPage> createState() =>
      _AttendanceManagementAdminPageState();
}

class _AttendanceManagementAdminPageState
    extends State<AttendanceManagementAdminPage> {
  final DatabaseService _databaseService = DatabaseService();
  String selectedYearID = 'Year 4';
  List<Map<String, dynamic>> attendanceRecords = [];

  @override
  void initState() {
    super.initState();
    fetchAttendanceData(selectedYearID);
  }

  // Function to fetch attendance data by yearID
  Future<void> fetchAttendanceData(String yearID) async {
    try {
      List<Map<String, dynamic>> records =
          await _databaseService.getAttendanceByYear(yearID);

      // Fetch child names and profile images from the child document
      List<Map<String, dynamic>> enrichedRecords =
          await Future.wait(records.map((record) async {
        String childID = record['childID'];
        String childName = await fetchChildName(childID); // Fetch child's name
        String profileImage = await fetchChildProfileImage(
            childID); // Fetch child's profile image
        return {
          ...record,
          'nameC': childName, // Add child name to the record
          'profileImage': profileImage, // Add profile image to the record
        };
      }));

      setState(() {
        attendanceRecords =
            enrichedRecords; // Update state with the fetched records
      });
    } catch (e) {
      print('Error fetching attendance data: $e');
    }
  }

  // Fetch child's name from Firestore using childID
  Future<String> fetchChildName(String childID) async {
    DocumentSnapshot childDoc =
        await FirebaseFirestore.instance.collection('child').doc(childID).get();
    return childDoc.exists
        ? childDoc['SectionA']['nameC'] as String
        : 'Unknown';
  }

  // Fetch child's profile image from Firestore using childID
  Future<String> fetchChildProfileImage(String childID) async {
    DocumentSnapshot childDoc =
        await FirebaseFirestore.instance.collection('child').doc(childID).get();
    if (childDoc.exists) {
      // Cast the data to a Map<String, dynamic>
      final data = childDoc.data() as Map<String, dynamic>?;
      // Check if the 'profileImage' field exists
      if (data != null && data.containsKey('profileImage')) {
        return data['profileImage'] as String;
      }
    }
    return ''; // Return an empty string if no image exists or document does not exist
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Attendance Management'),
        backgroundColor: Colors.blue[100],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.grey,
                  width: 2.0,
                ),
                borderRadius: BorderRadius.circular(8.0),
              ),
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Choose Class',
                    style: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 3.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Attendance:',
                        style: TextStyle(
                          fontSize: 16.0,
                        ),
                      ),
                      DropdownButton<String>(
                        value: selectedYearID,
                        onChanged: (String? newValue) {
                          if (newValue != null) {
                            setState(() {
                              selectedYearID = newValue;
                              fetchAttendanceData(newValue);
                            });
                          }
                        },
                        items: <String>['Year 4', 'Year 5', 'Year 6']
                            .map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: attendanceRecords.isNotEmpty
                  ? ListView.builder(
                      itemCount: attendanceRecords.length,
                      itemBuilder: (context, index) {
                        final record = attendanceRecords[index];
                        final attendancePercentage =
                            record['attendancePercentage'] ?? 0.0;
                        final percentageColor = attendancePercentage > 50.00
                            ? Colors.green
                            : Colors.red;

                        return Container(
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: Colors.grey,
                              width: 1.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          margin: const EdgeInsets.only(bottom: 8.0),
                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      AttendanceChildDetailPage(
                                    childID: record['childID'],
                                    yearID: selectedYearID,
                                  ),
                                ),
                              ).then((shouldRefresh) {
                                if (shouldRefresh == true) {
                                  fetchAttendanceData(selectedYearID);
                                }
                              });
                            },
                            child: ListTile(
                              leading: CircleAvatar(
                                radius: 25,
                                backgroundImage:
                                    record['profileImage'] != null &&
                                            record['profileImage'].isNotEmpty
                                        ? NetworkImage(record['profileImage'])
                                        : null,
                                child: record['profileImage'] == null ||
                                        record['profileImage'].isEmpty
                                    ? const Icon(Icons.person,
                                        size: 30, color: Colors.grey)
                                    : null,
                              ),
                              title: Text(record['nameC'] ?? 'Unknown'),
                              subtitle: Text('Child ID: ${record['childID']}'),
                              trailing: Text(
                                '${attendancePercentage.toStringAsFixed(2)}%',
                                style: TextStyle(color: percentageColor),
                              ),
                            ),
                          ),
                        );
                      },
                    )
                  : const Center(
                      child: Text('No students available for this year.'),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
