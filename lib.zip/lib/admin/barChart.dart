import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class BarChartSample2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BarChart(
      BarChartData(
        gridData: FlGridData(show: false), // Hide grid lines
        titlesData: FlTitlesData(
          show: true,
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 22, // Space for the month labels
              getTitlesWidget: (value, meta) {
                return Text(
                  _getMonthName(value.toInt()),
                  style: const TextStyle(fontSize: 12, color: Colors.black),
                );
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 40, // Adjust space for Y axis labels
              getTitlesWidget: (value, meta) {
                return Text(
                  value.toStringAsFixed(0), // Display integer values on Y axis
                  style: const TextStyle(fontSize: 12, color: Colors.black),
                );
              },
            ),
          ),
        ),
        borderData: FlBorderData(show: false), // Hide borders
        barGroups: _buildBarGroups(), // Use dynamic method to create bar groups
      ),
    );
  }

  // Method to map month index to month name
  String _getMonthName(int monthIndex) {
    switch (monthIndex) {
      case 1:
        return 'Jan';
      case 2:
        return 'Feb';
      case 3:
        return 'Mar';
      case 4:
        return 'Apr';
      case 5:
        return 'May';
      case 6:
        return 'Jun';
      case 7:
        return 'Jul';
      case 8:
        return 'Aug';
      case 9:
        return 'Sep';
      case 10:
        return 'Oct';
      case 11:
        return 'Nov';
      case 12:
        return 'Dec';
      default:
        return '';
    }
  }

  // Method to create bar groups dynamically
  List<BarChartGroupData> _buildBarGroups() {
    return [
      _buildBar(1, 8), // January
      _buildBar(2, 10), // February
      _buildBar(3, 14), // March
      _buildBar(4, 15), // April
      _buildBar(5, 12), // May
      _buildBar(6, 20), // June
      _buildBar(7, 18), // July
      _buildBar(8, 25), // August
      _buildBar(9, 22), // September
      _buildBar(10, 30), // October
      _buildBar(11, 28), // November
      _buildBar(12, 35), // December
    ];
  }

  // Helper method to create bar data
  BarChartGroupData _buildBar(int monthIndex, double value) {
    return BarChartGroupData(
      x: monthIndex,
      barRods: [
        BarChartRodData(
          toY: value,
          color: Colors.blue,
          width: 16.0, // Adjust bar width as needed
          borderRadius: BorderRadius.zero,
        ),
      ],
    );
  }
}
