import 'package:flutter/material.dart';
import 'package:kms2/admin/milestone/addMilestone.dart';
import 'package:kms2/admin/milestone/viewMilestone.dart';

class MenuMilestone extends StatelessWidget {
  const MenuMilestone({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Milestone Menu'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const AdminMilestonePage()),
                );
              },
              child: const Text('Add Milestone'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const ViewMilestonePage()),
                );
              },
              child: const Text('View Milestone'),
            ),
          ],
        ),
      ),
    );
  }
}
