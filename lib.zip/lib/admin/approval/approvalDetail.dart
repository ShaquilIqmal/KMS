// ignore_for_file: unnecessary_const

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ApprovalDetailPage extends StatelessWidget {
  final String docId;
  final Map<String, dynamic> data;

  ApprovalDetailPage({required this.docId, required this.data});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Applicant Details'),
        backgroundColor: Colors.blue[100],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            const Text('Section A - Child\'s Particulars',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text('Name: ${data['SectionA']['nameC']}'),
            Text('Gender: ${data['SectionA']['genderC']}'),
            Text('Address: ${data['SectionA']['addressC']}'),
            Text('Date of Birth: ${data['SectionA']['dateOfBirthC']}'),
            Text('Age: ${data['SectionA']['yearID']}'),
            Text('MyKid: ${data['SectionA']['myKidC']}'),
            Text('Religion: ${data['SectionA']['religionC']}'),
            const SizedBox(height: 16),
            const Text('Section B - Guardian\'s Particulars',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text('Father\'s Name: ${data['SectionB']['nameF']}'),
            Text('Father\'s IC: ${data['SectionB']['icF']}'),
            Text('Father\'s Income: ${data['SectionB']['incomeF']}'),
            Text('Father\'s Address: ${data['SectionB']['addressF']}'),
            Text('Father\'s Home Tel: ${data['SectionB']['homeTelF']}'),
            Text('Father\'s Handphone: ${data['SectionB']['handphoneF']}'),
            Text('Father\'s Email: ${data['SectionB']['emailF']}'),
            const SizedBox(height: 16),
            const Text('Section C - Medical Information',
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text('Medical Condition: ${data['SectionC']['medicalCondition']}'),
            Text('Doctor\'s Tel: ${data['SectionC']['doctorTel']}'),
            Text('Clinic/Hospital: ${data['SectionC']['clinicHospital']}'),
            const SizedBox(height: 16),
            const Text('Section D - Emergency Contact',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text('Emergency Name: ${data['SectionD']['nameM']}'),
            Text('Emergency Tel: ${data['SectionD']['telM']}'),
            Text('Relationship: ${data['SectionD']['relationshipM']}'),
            const SizedBox(height: 16),
            const Text('Section E - Transportation Needs',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text('Transportation: ${data['SectionE']['transportation']}'),
            if (data['SectionE']['transportation'] == 'school') ...[
              Text('Pickup Address: ${data['SectionE']['pickupAddress']}'),
              Text('Drop Address: ${data['SectionE']['dropAddress']}'),
            ],
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () async {
                    await approveRegistration(docId, data);
                    Navigator.pop(context); //remove data from database
                  },
                  child: const Text('Approve'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    await denyRegistration(docId);
                    Navigator.pop(context); //remove data from database
                  },
                  style: ElevatedButton.styleFrom(
                    primary: Colors.red, // Set the button color to red
                  ),
                  child: const Text('Deny'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  //DATABASE BACKEND

  Future<void> approveRegistration(
      String docId, Map<String, dynamic> data) async {
    print('Entering approveRegistration with docId: $docId');

    try {
      FirebaseFirestore firestore = FirebaseFirestore.instance;

      // Fetch the current count of documents in the 'child' collection
      QuerySnapshot childSnapshot = await firestore.collection('child').get();
      int childCount = childSnapshot.docs.length;
      print('Current child count: $childCount');

      // Generate the new child ID
      String newChildId =
          'child_${(childCount + 1).toString().padLeft(7, '0')}';
      print('Generated new child ID: $newChildId');

      // Create a new document in the 'child' collection with the formatted ID
      DocumentReference childRef =
          firestore.collection('child').doc(newChildId);

      // Store the userId in the child's document to link it to the user
      data['userId'] =
          data['userId']; // Assuming userId is already part of the data
      print('User ID to be linked: ${data['userId']}');

      // Add data to the 'child' collection
      await childRef.set(data);
      print('Child document created with data: $data');

      // Fetch the fee based on category "New Registration"
      QuerySnapshot feeSnapshot = await firestore
          .collection('fees')
          .where('category', isEqualTo: 'New Registration')
          .get();

      if (feeSnapshot.docs.isNotEmpty) {
        // Assuming only one fee for "New Registration"
        DocumentSnapshot feeDoc = feeSnapshot.docs.first;
        Map<String, dynamic> feeData = feeDoc.data() as Map<String, dynamic>;
        print('Fee data fetched: $feeData');

        // Calculate the due date (one month after the current date)
        DateTime dueDate = DateTime.now().add(Duration(days: 30));
        print('Calculated due date: $dueDate');

        // Create a new payment document in the payments subcollection
        DocumentReference paymentRef = childRef.collection('payments').doc();
        print('Creating payment document with reference: ${paymentRef.id}');

        await paymentRef.set({
          'amount': feeData['amount'],
          'date': Timestamp.now(), // Current timestamp
          'paid': false,
          'paymentMethod': 'credit_card',
          'dueDate':
              Timestamp.fromDate(dueDate), // Convert DateTime to Timestamp
          'category': feeData['category'],
          'feeType':
              feeData['feeType'], // Assuming feeType exists in the fee document
        });
        print('Payment document created successfully.');
      } else {
        print('No fee found for category "New Registration".');
      }

      // Optionally, you can store the child's document ID in the user's document if needed
      String userId = data['userId'];
      DocumentReference userRef = firestore.collection('users').doc(userId);
      await userRef.update({
        'childIds': FieldValue.arrayUnion(
            [newChildId]), // Adding child ID to an array in the user's document
      });
      print('User document updated with new child ID.');

      // Delete the document from the 'pending_approvals' collection
      await firestore.collection('pending_approvals').doc(docId).delete();
      print('Pending approval document deleted for docId: $docId');

      print(
          'Registration approved and moved to child collection with ID: $newChildId');
    } catch (e) {
      print('Failed to approve registration: $e');
    } finally {
      print('Exiting approveRegistration method.');
    }
  }

  Future<void> denyRegistration(String docId) async {
    try {
      FirebaseFirestore firestore = FirebaseFirestore.instance;

      // Delete the document from the 'pending_approvals' collection
      await firestore.collection('pending_approvals').doc(docId).delete();

      print('Registration denied and removed from pending approvals');
    } catch (e) {
      print('Failed to deny registration: $e');
    }
  }
}
