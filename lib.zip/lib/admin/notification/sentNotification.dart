import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:kms2/admin/notification/notification.dart';
import 'package:kms2/user/notifications/notificationDetails.dart'; // Importing the NotificationDetailPage

class SentNotificationsPage extends StatefulWidget {
  final String adminDocId;

  const SentNotificationsPage({Key? key, required this.adminDocId})
      : super(key: key);

  @override
  _SentNotificationsPageState createState() => _SentNotificationsPageState();
}

class _SentNotificationsPageState extends State<SentNotificationsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sent Notifications'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('notifications')
            .orderBy('timestamp', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("No notifications sent yet."));
          }

          // Display list of sent notifications
          return ListView.builder(
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              final notification = snapshot.data!.docs[index];
              final title = notification['title'] ?? 'No Title';
              final message = notification['message'] ?? 'No Message';
              final timestamp = notification['timestamp'] as Timestamp?;
              final recipients = notification['recipients'] ?? [];

              // Format recipients' names as a comma-separated string
              final recipientNames = recipients
                  .map((recipient) => recipient['name'] ?? 'Unknown')
                  .join(', ');

              return GestureDetector(
                onTap: () {
                  // Navigate to NotificationDetailPage when the card is tapped
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => NotificationDetailPage(
                        notification:
                            notification.data() as Map<String, dynamic>,
                      ),
                    ),
                  );
                },
                child: Card(
                  margin:
                      const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  child: ListTile(
                    isThreeLine: true, // Allow more space for the subtitle
                    title: Text(
                      title,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold), // Bold title
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 4),
                        // Limit the message length to prevent it from being too long
                        Text(
                          message.length > 50
                              ? '${message.substring(0, 50)}...'
                              : message,
                        ),
                        const SizedBox(height: 8),
                        // Display recipients as comma-separated names
                        Text(
                          'Sent To: $recipientNames',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Sent on: ${timestamp != null ? DateTime.fromMillisecondsSinceEpoch(timestamp.millisecondsSinceEpoch).toLocal().toString() : 'Unknown'}',
                          style:
                              const TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Navigate to the NotificationPage to send a new notification
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  NotificationPage(adminDocId: widget.adminDocId),
            ),
          );
        },
        child: const Icon(Icons.add),
        tooltip: 'Send New Notification',
      ),
    );
  }
}
