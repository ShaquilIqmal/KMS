import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:kms2/service/cloudinary_service.dart'; // Adjust based on your project structure
import 'package:kms2/service/database_service.dart'; // Adjust based on your project structure
import 'package:kms2/service/zmodel/childmodel.dart'; // Adjust based on your project structure

class ViewUserChildInfoPage extends StatefulWidget {
  final Child child;

  const ViewUserChildInfoPage({Key? key, required this.child})
      : super(key: key);

  @override
  _ViewUserChildInfoPageState createState() => _ViewUserChildInfoPageState();
}

class _ViewUserChildInfoPageState extends State<ViewUserChildInfoPage> {
  late Child child;
  final ImagePicker _picker = ImagePicker();
  final CloudinaryService _cloudinaryService = CloudinaryService();
  bool _isUploading = false;

  @override
  void initState() {
    super.initState();
    child = widget.child; // Initialize with the child data passed to the widget
  }

  Future<void> _pickImage() async {
    final XFile? pickedFile =
        await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _isUploading = true;
      });
      String imageUrl = await _uploadImageToCloudinary(pickedFile.path);
      if (imageUrl.isNotEmpty) {
        _updateProfileImage(imageUrl);
      } else {
        setState(() {
          _isUploading = false;
        });
      }
    }
  }

  Future<String> _uploadImageToCloudinary(String filePath) async {
    try {
      String imageUrl = await _cloudinaryService.uploadImage(filePath);
      return imageUrl;
    } catch (e) {
      print("Error uploading image: $e");
      return '';
    }
  }

  Future<void> _updateProfileImage(String imageUrl) async {
    try {
      await FirebaseFirestore.instance.collection('child').doc(child.id).update(
          {'profileImage': imageUrl}); // Save directly under child document
      setState(() {
        child.profileImage = imageUrl; // Update local state for display
        _isUploading = false;
      });
      print("Profile image updated!");
    } catch (e) {
      print("Error updating profile image: $e");
      setState(() {
        _isUploading = false;
      });
    }
  }

  Future<Child> fetchUpdatedChildData(String childId) async {
    DocumentSnapshot doc =
        await FirebaseFirestore.instance.collection('child').doc(childId).get();

    if (doc.exists) {
      return Child.fromDocument(doc);
    } else {
      throw Exception('Child not found');
    }
  }

  void refreshChildData() async {
    try {
      final updatedChild = await fetchUpdatedChildData(child.id);
      setState(() {
        child = updatedChild; // Update the local state with the new data
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error fetching updated data: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(child.sectionA['nameC'] ?? 'Child Details'),
        backgroundColor: Colors.blue[100],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: _pickImage,
                child: CircleAvatar(
                  radius: 80,
                  backgroundImage: (child.profileImage != null &&
                          child.profileImage!.isNotEmpty)
                      ? NetworkImage(child.profileImage!)
                      : null,
                  backgroundColor: Colors.grey[300],
                  child: (child.profileImage == null ||
                          child.profileImage!.isEmpty)
                      ? const Icon(Icons.child_care,
                          size: 50, color: Colors.white)
                      : null,
                ),
              ),
              const SizedBox(height: 16),
              _buildSectionA('Section A: Child\'s Particulars', child.sectionA,
                  context, 'A'),
              _buildSectionB('Section B: Guardian\'s Particulars',
                  child.sectionB, context, 'B'),
              _buildSectionC('Section C: Medical Information', child.sectionC,
                  context, 'C'),
              _buildSectionD(
                  'Section D: Emergency Contact', child.sectionD, context, 'D'),
              _buildSectionE('Section E: Transportation Needs', child.sectionE,
                  context, 'E'),
              if (_isUploading)
                const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: CircularProgressIndicator(),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionA(String title, Map<String, dynamic> details,
      BuildContext context, String section) {
    return _buildSection(title, details, context, section, [
      {'label': 'Child Name', 'key': 'nameC'},
      {'label': 'Year', 'key': 'yearID'},
      {'label': 'My Kid', 'key': 'myKidC'},
      {'label': 'Gender', 'key': 'genderC'},
      {'label': 'Date Of Birth', 'key': 'dateOfBirthC'},
      {'label': 'Address', 'key': 'addressC'},
      {'label': 'Religion', 'key': 'religionC'},
    ]);
  }

  Widget _buildSectionB(String title, Map<String, dynamic> details,
      BuildContext context, String section) {
    return _buildSection(title, details, context, section, [
      {'label': 'Name', 'key': 'nameF'},
      {'label': 'Address', 'key': 'addressF'},
      {'label': 'Email', 'key': 'emailF'},
      {'label': 'Tel No', 'key': 'handphoneF'},
      {'label': 'Home Tel No', 'key': 'homeTelF'},
      {'label': 'IC', 'key': 'icF'},
      {'label': 'Income', 'key': 'incomeF'},
    ]);
  }

  Widget _buildSectionC(String title, Map<String, dynamic> details,
      BuildContext context, String section) {
    return _buildSection(title, details, context, section, [
      {'label': 'Clinic/Hospital Name', 'key': 'clinicHospital'},
      {'label': 'Doctor Tel', 'key': 'doctorTel'},
      {'label': 'Medical Condition', 'key': 'medicalCondition'},
    ]);
  }

  Widget _buildSectionD(String title, Map<String, dynamic> details,
      BuildContext context, String section) {
    return _buildSection(title, details, context, section, [
      {'label': 'Name', 'key': 'nameM'},
      {'label': 'Relationship', 'key': 'relationshipM'},
      {'label': 'Emergency Tel', 'key': 'telM'},
    ]);
  }

  Widget _buildSectionE(String title, Map<String, dynamic> details,
      BuildContext context, String section) {
    return _buildSection(title, details, context, section, [
      {'label': 'Drop Address', 'key': 'dropAddress'},
      {'label': 'Pickup Address', 'key': 'pickupAddress'},
      {'label': 'Transportation', 'key': 'transportation'},
    ]);
  }

  Widget _buildSection(String title, Map<String, dynamic> details,
      BuildContext context, String section, List<Map<String, String>> fields) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        ...fields.map(
            (field) => _buildDetailRow(field['label']!, details[field['key']])),
        const SizedBox(height: 8),
        ElevatedButton(
          onPressed: () {
            _showEditDialog(context, child.id, details, section, fields);
          },
          child: const Text('Edit'),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildDetailRow(String label, dynamic value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Text('$label: ${value ?? 'N/A'}',
          style: const TextStyle(fontSize: 14)),
    );
  }

  void _showEditDialog(
      BuildContext context,
      String childId,
      Map<String, dynamic> details,
      String section,
      List<Map<String, String>> fields) {
    final controllers = {
      for (var field in fields)
        field['key']!: TextEditingController(text: details[field['key']])
    };

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Edit Section $section'),
          content: SingleChildScrollView(
            child: Column(
              children: fields.map((field) {
                return _buildDialogTextField(
                    field['label']!, controllers[field['key']]!);
              }).toList(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                Map<String, dynamic> updatedDetails = {};
                for (var field in fields) {
                  updatedDetails[field['key']!] =
                      controllers[field['key']]!.text;
                }
                await _saveUpdatedDetails(childId, updatedDetails, section);
                refreshChildData(); // Refresh the data
                Navigator.of(context).pop(); // Close the dialog
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildDialogTextField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(labelText: label),
      ),
    );
  }

  Future<void> _saveUpdatedDetails(String childId,
      Map<String, dynamic> updatedDetails, String section) async {
    Map<String, dynamic> sectionData = {};

    switch (section) {
      case 'A':
        sectionData = {
          'SectionA': {
            'nameC': updatedDetails['nameC'],
            'yearID': updatedDetails['yearID'],
            'myKidC': updatedDetails['myKidC'],
            'genderC': updatedDetails['genderC'],
            'dateOfBirthC': updatedDetails['dateOfBirthC'],
            'addressC': updatedDetails['addressC'],
            'religionC': updatedDetails['religionC'],
          }
        };
        break;
      case 'B':
        sectionData = {
          'SectionB': {
            'nameF': updatedDetails['nameF'],
            'addressF': updatedDetails['addressF'],
            'emailF': updatedDetails['emailF'],
            'handphoneF': updatedDetails['handphoneF'],
            'homeTelF': updatedDetails['homeTelF'],
            'icF': updatedDetails['icF'],
            'incomeF': updatedDetails['incomeF'],
          }
        };
        break;
      case 'C':
        sectionData = {
          'SectionC': {
            'clinicHospital': updatedDetails['clinicHospital'],
            'doctorTel': updatedDetails['doctorTel'],
            'medicalCondition': updatedDetails['medicalCondition'],
          }
        };
        break;
      case 'D':
        sectionData = {
          'SectionD': {
            'nameM': updatedDetails['nameM'],
            'relationshipM': updatedDetails['relationshipM'],
            'telM': updatedDetails['telM'],
          }
        };
        break;
      case 'E':
        sectionData = {
          'SectionE': {
            'dropAddress': updatedDetails['dropAddress'],
            'pickupAddress': updatedDetails['pickupAddress'],
            'transportation': updatedDetails['transportation'],
          }
        };
        break;
    }

    await DatabaseService().updateChildDetails(childId, sectionData);
  }
}
