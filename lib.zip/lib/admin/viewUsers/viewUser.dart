import 'package:flutter/material.dart';
import 'package:kms2/service/database_service.dart';
import 'package:kms2/service/zmodel/usermodel.dart';
import 'package:provider/provider.dart';

import 'addUser.dart';
import 'viewUserInfoPage.dart';

class ViewUserPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('View Users'),
        backgroundColor: Colors.blue[100],
      ),
      body: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const Text(
                'Add Users',
                style: TextStyle(fontSize: 18, color: Colors.blue),
              ),
              IconButton(
                iconSize: 30,
                icon: const Icon(Icons.add, color: Colors.green),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const AddUserPage(),
                    ),
                  );
                },
              ),
            ],
          ),
          Expanded(
            child: StreamProvider<List<User>>.value(
              value: DatabaseService().getUsersWithChildren(),
              initialData: [],
              child: UserList(),
            ),
          ),
        ],
      ),
    );
  }
}

class UserList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var users = Provider.of<List<User>>(context);

    if (users.isEmpty) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    List<User> usersWithChildren = [];
    List<User> usersWithoutChildren = [];

    users.forEach((user) {
      if (user.name != 'admin') {
        if (user.children.isNotEmpty) {
          usersWithChildren.add(user);
        } else {
          usersWithoutChildren.add(user);
        }
      }
    });

    return ListView(
      children: <Widget>[
        ExpansionTile(
          title: const Text('Users With Children'),
          children: usersWithChildren.map((user) {
            return InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => UserInformationPage(user: user),
                  ),
                );
              },
              child: ListTile(
                leading: CircleAvatar(
                  radius: 25,
                  backgroundImage:
                      user.profileImage != null && user.profileImage!.isNotEmpty
                          ? NetworkImage(user.profileImage!)
                          : null,
                  child: user.profileImage == null || user.profileImage!.isEmpty
                      ? const Icon(Icons.person, size: 25)
                      : null,
                ),
                title: Text(
                  user.name,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold, // Make user name bold
                  ),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: user.children.map((child) {
                    return Text(
                      child.name,
                      style: const TextStyle(
                        color: Colors
                            .grey, // Light grey color for children's names
                      ),
                    );
                  }).toList(),
                ),
              ),
            );
          }).toList(),
        ),
        ExpansionTile(
          title: const Text('Users Without Children'),
          children: usersWithoutChildren.map((user) {
            return ListTile(
              leading: CircleAvatar(
                radius: 25,
                backgroundImage:
                    user.profileImage != null && user.profileImage!.isNotEmpty
                        ? NetworkImage(user.profileImage!)
                        : null,
                child: user.profileImage == null || user.profileImage!.isEmpty
                    ? const Icon(Icons.person, size: 25)
                    : null,
              ),
              title: Text(
                user.name,
                style: const TextStyle(
                  fontWeight: FontWeight.bold, // Make user name bold
                ),
              ),
              subtitle: const Text('No children'), // Indicating no children
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () {
                      // Edit user functionality
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () {
                      // Delete user functionality
                    },
                  ),
                ],
              ),
            );
          }).toList(),
        ),
      ],
    );
  }
}
