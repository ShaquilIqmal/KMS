import 'dart:async';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'admin/adminDashboard.dart'; // Import for admin dashboard
import 'login.dart'; // Import for login page
import 'teacher/teacherDashboard.dart'; // Import for teacher dashboard
import 'user/dashboard.dart'; // Import for user dashboard

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkSession();
  }

  Future<void> _checkSession() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString('userId');
    String? role = prefs.getString('role');

    // Debugging: print session data
    print('Checking session. User ID: $userId, Role: $role');

    // Check if session exists and navigate accordingly
    if (userId != null) {
      if (role == 'admin') {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
              builder: (context) => AdminDashboardPage(docId: userId)),
        );
      } else if (role == 'teacher') {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
              builder: (context) => TeacherDashboardPage(docId: userId)),
        );
      } else {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => DashboardPage(docId: userId)),
        );
      }
    } else {
      // No session, go to login
      Timer(const Duration(seconds: 3), () {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => const LoginPage()),
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              'assets/logo.jpg', // Replace with your logo
              width: 200,
              height: 200,
            ),
            const SizedBox(height: 20),
            const Text(
              'Little I.M.A.N Kids Kindergarten',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Text(
              'Portal for Parents',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
