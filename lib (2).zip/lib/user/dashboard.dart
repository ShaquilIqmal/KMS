// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:kms2/login.dart';
import 'package:kms2/service/database_service.dart';
import 'package:kms2/user/attendance/checkAttendance.dart';
import 'package:kms2/user/childMilestone.dart';
import 'package:kms2/user/childTimetable/childTimetable.dart';
import 'package:kms2/user/notifications/userNotification.dart';
import 'package:kms2/user/payment/paymentOverview.dart';
import 'package:kms2/user/registerchild/registerchildA.dart';
import 'package:kms2/user/userProfile/userProfile.dart';

class DashboardPage extends StatefulWidget {
  final String docId;

  const DashboardPage({Key? key, required this.docId}) : super(key: key);

  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  String name = '';
  String? profileImageUrl;
  bool isLoading = true;
  List<String> childrenNames = [];
  List<String> childrenIds = [];
  int? selectedCardIndex;
  String? selectedChildId;

  @override
  void initState() {
    super.initState();
    fetchUserNameAndChildren();
  }

  Future<void> fetchUserNameAndChildren() async {
    setState(() {
      isLoading = true; // Show loading indicator
    });
    print('Fetching user name and children...');
    try {
      String? fetchedName = await DatabaseService.fetchUserData(widget.docId);
      print('Fetched name: $fetchedName');

      profileImageUrl =
          await DatabaseService().fetchUserProfileImage(widget.docId);
      print('Fetched profile image URL: $profileImageUrl');

      List<String> fetchedChildrenIds =
          await DatabaseService().getChildrenIds(widget.docId);
      print('Fetched children IDs: $fetchedChildrenIds');

      List<String> fetchedChildrenNames = [];
      if (fetchedChildrenIds.isNotEmpty) {
        fetchedChildrenNames = await Future.wait(
          fetchedChildrenIds
              .map((id) => DatabaseService().getChildNameById(id))
              .toList(),
        );
      } else {
        print("No child IDs found.");
      }

      setState(() {
        name = fetchedName ?? 'N/A';
        childrenNames = fetchedChildrenNames;
        childrenIds = fetchedChildrenIds;
        selectedCardIndex = childrenNames.isNotEmpty ? 0 : null;
        selectedChildId =
            selectedCardIndex != null ? childrenIds[selectedCardIndex!] : null;
      });
    } catch (e) {
      print('Error fetching user data: $e');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Little Iman Kids'),
        backgroundColor:
            Colors.blue[200], // Slightly lighter blue for a fresh look
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications, size: 28.0),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      UserNotificationPage(userDocId: widget.docId),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout, size: 28.0),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const LoginPage()),
              );
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: fetchUserNameAndChildren, // Call the fetch method on refresh
        child: isLoading
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                padding: const EdgeInsets.all(16.0),
                children: [
                  _buildProfileSection(),
                  const SizedBox(height: 16.0),
                  _buildDueAmountSection(),
                  const SizedBox(height: 16.0),
                  _buildConnectedStudentsSection(),
                  const SizedBox(height: 16.0),
                  _buildMainMenuSection(),
                  const SizedBox(height: 16.0),
                  Text('Document ID: ${widget.docId}'),
                ],
              ),
      ),
    );
  }

  Widget _buildProfileSection() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              name,
              style: const TextStyle(
                fontSize: 22.0,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            const Text(
              'Parent Account',
              style: TextStyle(fontSize: 16.0, color: Colors.grey),
            ),
          ],
        ),
        const SizedBox(width: 16.0),
        GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ProfilePage(docId: widget.docId),
              ),
            );
          },
          child: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: const Color.fromARGB(255, 132, 132, 132)
                      .withOpacity(0.5), // Shadow color
                  blurRadius: 10.0, // Blur effect
                  spreadRadius: 2.0, // Shadow spread
                  offset: const Offset(0, 4), // Shadow position
                ),
              ],
            ),
            child: CircleAvatar(
              radius: 40.0,
              backgroundImage: profileImageUrl != null
                  ? NetworkImage(profileImageUrl!)
                  : const AssetImage('assets/mom.png')
                      as ImageProvider, // Fallback image
              backgroundColor: Color.fromARGB(0, 199, 198, 198),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDueAmountSection() {
    return FutureBuilder<double>(
      future: selectedChildId != null
          ? DatabaseService().fetchTotalDueAmount(selectedChildId!)
          : Future.value(0.0),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return const Center(child: Text('Error fetching due amount'));
        } else {
          double totalDueAmount = snapshot.data ?? 0.0;

          return GestureDetector(
            onTap: () {
              if (selectedChildId != null) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PaymentOverviewPage(
                      docId: widget.docId,
                      childId: selectedChildId!,
                    ),
                  ),
                );
              } else {
                print('No child selected for Payment Overview');
              }
            },
            child: Container(
              padding: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Colors.blue[50],
                borderRadius: BorderRadius.circular(12.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    spreadRadius: 3,
                    blurRadius: 6,
                    offset: const Offset(0, 3), // Shadow position
                  ),
                ],
              ),
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        totalDueAmount.toStringAsFixed(2),
                        style: const TextStyle(
                            fontSize: 30.0, fontWeight: FontWeight.bold),
                      ),
                      const Text(
                        'Due Amount',
                        style: TextStyle(fontSize: 18.0, color: Colors.grey),
                      ),
                    ],
                  ),
                  const Spacer(),
                  const Icon(Icons.arrow_forward, color: Colors.orange),
                ],
              ),
            ),
          );
        }
      },
    );
  }

  Widget _buildConnectedStudentsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Children Registered',
          style: TextStyle(
            fontSize: 20.0,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        const SizedBox(height: 8.0),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              ...childrenNames.asMap().entries.map((entry) {
                int index = entry.key;
                String name = entry.value;
                return _buildStudentCard(name, index);
              }).toList(),
              _buildAddStudentButton(context),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStudentCard(String childName, int index) {
    List<String> words = childName.split(' ');
    String displayName =
        words.length > 1 ? '${words[0]} ${words[1]}' : words[0];
    bool isSelected = selectedCardIndex == index;

    // Get the child ID
    String childId = childrenIds[index];

    // Fetch the child's profile image
    Future<String?> childProfileImageFuture =
        DatabaseService().getChildProfileImage(childId);

    return FutureBuilder<String?>(
      future: childProfileImageFuture,
      builder: (context, snapshot) {
        ImageProvider profileImage =
            const AssetImage('assets/child1.png'); // Default image

        if (snapshot.connectionState == ConnectionState.waiting) {
          // While the data is loading, show a placeholder
          profileImage = const AssetImage(
              'assets/loading.png'); // You could have a loading image
        } else if (snapshot.hasData &&
            snapshot.data != null &&
            snapshot.data!.isNotEmpty) {
          // If there's data, use the profile image
          profileImage = NetworkImage(snapshot.data!);
        }

        return GestureDetector(
          onTap: () {
            setState(() {
              selectedCardIndex = isSelected ? null : index;
              selectedChildId = isSelected ? null : childrenIds[index];
            });
            print('Child ID: ${childrenIds[index]}');
          },
          child: Container(
            margin: const EdgeInsets.only(right: 8.0),
            padding: const EdgeInsets.all(8.0),
            decoration: BoxDecoration(
              color: isSelected ? Colors.blue[100] : Colors.grey[200],
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 30.0,
                  backgroundImage: profileImage,
                ),
                const SizedBox(height: 8.0),
                Text(displayName),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildAddStudentButton(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => RegisterChildPage(docId: widget.docId),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(12.0),
        decoration: BoxDecoration(
          color: Colors.blue[200],
          borderRadius: BorderRadius.circular(12.0),
          boxShadow: [
            BoxShadow(
              color: Colors.blue.withOpacity(0.2),
              blurRadius: 8.0,
              spreadRadius: 2.0,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          children: [
            const Icon(Icons.add, size: 35.0, color: Colors.white),
            const SizedBox(height: 10.0),
            const Text(
              'Register',
              style: TextStyle(color: Colors.white, fontSize: 14.0),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMainMenuSection() {
    String selectedChildName =
        selectedCardIndex != null ? childrenNames[selectedCardIndex!] : '';

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'Main Menu - ',
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
              ),
              Text(
                selectedChildName,
                style: const TextStyle(
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 1, 77, 139),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12.0),
          GridView.count(
            crossAxisCount: 3,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              _buildMainMenuItem(Icons.bar_chart, 'Attendance', () async {
                String selectedYear = '';
                if (selectedChildId != null) {
                  selectedYear = await DatabaseService()
                          .getChildYearID(selectedChildId!) ??
                      '';
                }

                print('Attendance clicked for child ID: $selectedChildId');
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => CheckAttendancePage(
                      childId: selectedChildId!,
                      selectedYear: selectedYear,
                    ),
                  ),
                );
              }),
              _buildMainMenuItem(Icons.calendar_today, 'Timetable', () async {
                String selectedYear = '';
                if (selectedChildId != null) {
                  selectedYear = await DatabaseService()
                          .getChildYearID(selectedChildId!) ??
                      '';
                }

                print(
                    'Timetable clicked for child ID: $selectedChildId with selectedYear: $selectedYear');

                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ChildTimetablePage(
                      childId: selectedChildId!,
                      selectedYear: selectedYear,
                    ),
                  ),
                );
              }),
              _buildMainMenuItem(Icons.star, 'Milestone', () {
                if (selectedChildId != null) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          MilestonePage(childId: selectedChildId!),
                    ),
                  );
                } else {
                  print('No child selected');
                }
                print('Milestone clicked for child ID: $selectedChildId');
              }),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMainMenuItem(IconData icon, String label, VoidCallback onTap) {
    // Get the screen width from MediaQuery
    double screenWidth = MediaQuery.of(context).size.width;

    // Scale the icon and text size based on the screen width
    double iconSize = screenWidth < 360
        ? 28.0
        : (screenWidth < 480 ? 32.0 : 35.0); // Smaller for smaller screens
    double fontSize = screenWidth < 360
        ? 11.0
        : (screenWidth < 480 ? 12.0 : 13.0); // Adjust text size accordingly

    return Padding(
      padding: const EdgeInsets.all(8.0), // Adjust padding as needed
      child: InkWell(
        onTap: onTap,
        borderRadius:
            BorderRadius.circular(8.0), // Rounded corners for the tap area
        child: Container(
          padding: const EdgeInsets.all(
              10.0), // Increased padding for better spacing
          decoration: BoxDecoration(
            color: Colors.white, // Clean background
            borderRadius: BorderRadius.circular(8.0),
            boxShadow: [
              BoxShadow(
                color: const Color.fromARGB(255, 0, 0, 0)
                    .withOpacity(0.2), // Light shadow for depth
                spreadRadius: 2,
                blurRadius: 5,
                offset: const Offset(0, 3), // Shadow position
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: iconSize, // Adjust icon size based on screen width
                color: Colors.blue,
              ),
              const SizedBox(height: 9.0), // Increased spacing
              Text(
                label,
                style: TextStyle(
                  fontSize: fontSize, // Adjust text size based on screen width
                  color: Colors.black, // Dark color for contrast
                ),
                textAlign: TextAlign.center, // Center text alignment
              ),
            ],
          ),
        ),
      ),
    );
  }
}
