import 'package:flutter/material.dart';

class ChildProfilePage extends StatefulWidget {
  const ChildProfilePage({super.key});

  @override
  State<ChildProfilePage> createState() => _ChildProfilePageState();
}

class _ChildProfilePageState extends State<ChildProfilePage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
