import 'package:flutter/material.dart';

class ChildProfileEditPage extends StatefulWidget {
  const ChildProfileEditPage({super.key});

  @override
  State<ChildProfileEditPage> createState() => _ChildProfileEditPageState();
}

class _ChildProfileEditPageState extends State<ChildProfileEditPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
