import 'package:cloud_firestore/cloud_firestore.dart'; // Ensure this import is present
import 'package:flutter/material.dart';

class NotificationDetailPage extends StatelessWidget {
  final Map<String, dynamic> notification;

  const NotificationDetailPage({Key? key, required this.notification})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    String title = notification['title'] ?? 'No Title';
    String message = notification['message'] ?? 'No Message';
    Timestamp timestamp = notification['timestamp'];
    String timestampStr =
        DateTime.fromMillisecondsSinceEpoch(timestamp.seconds * 1000)
            .toString();

    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: TextStyle(fontSize: 24)),
            SizedBox(height: 10),
            Text(message),
            SizedBox(height: 10),
            Text('Sent on: $timestampStr'),
          ],
        ),
      ),
    );
  }
}
