import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:kms2/service/database_service.dart'; // Import the new file

import 'dashboard.dart';

class RegAccPage extends StatefulWidget {
  const RegAccPage({Key? key}) : super(key: key);

  @override
  _RegAccPageState createState() => _RegAccPageState();
}

class _RegAccPageState extends State<RegAccPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController noTelController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController repeatPasswordController =
      TextEditingController();

  final DatabaseService _databaseService =
      DatabaseService(); // Instantiate the service

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Little I.M.A.N Kids - Register'),
        backgroundColor: Colors.blue[100],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: _buildFormContent(),
      ),
    );
  }

  void _showSnackbar(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  void _submitData() async {
    if (_formKey.currentState?.validate() ?? false) {
      String name = nameController.text;
      String email = emailController.text;
      String noTel = noTelController.text;
      String password = passwordController.text;
      String repeatPassword = repeatPasswordController.text;

      if (password == repeatPassword) {
        try {
          DocumentReference docRef = await _databaseService.addUser({
            //add new users
            'name': name,
            'email': email,
            'noTel': noTel,
            'password': password,
            'timestamp': FieldValue.serverTimestamp(),
          });
          _showSuccessDialog(docRef.id);
        } catch (e) {
          _showSnackbar('Failed to register: $e');
        }
      } else {
        _showSnackbar('Passwords do not match.');
      }
    }
  }

  void _showSuccessDialog(String docId) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Registration Successful'),
          content: const Text('You have successfully registered.'),
          actions: <Widget>[
            TextButton(
              child: const Text('Go to Dashboard'),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (context) => DashboardPage(docId: docId),
                  ),
                );
              },
            ),
          ],
        );
      },
    );
  }

  Widget _buildFormContent() {
    return Form(
      key: _formKey,
      child: ListView(
        children: <Widget>[
          const Text(
            'Register',
            style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: nameController,
            labelText: 'Name (Parent)',
            hintText: 'name',
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter your name'
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: emailController,
            labelText: 'Email',
            hintText: 'email',
            keyboardType: TextInputType.emailAddress,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter your email';
              } else if (!value.contains('@')) {
                return 'Please enter a valid email address';
              }
              return null;
            },
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: noTelController,
            labelText: 'No Tel',
            hintText: 'tel',
            keyboardType: TextInputType.phone,
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter your phone number'
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: passwordController,
            labelText: 'Password',
            hintText: 'password',
            obscureText: true,
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter your password'
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: repeatPasswordController,
            labelText: 'Retype Password',
            hintText: 'retypePassword',
            obscureText: true,
            validator: (value) => value == null || value.isEmpty
                ? 'Please retype your password'
                : null,
          ),
          const SizedBox(height: 16.0),
          ElevatedButton(
            onPressed: _submitData,
            child: const Text('Register'),
          ),
        ],
      ),
    );
  }

  Widget _buildTextFormField({
    required TextEditingController controller,
    required String labelText,
    required String hintText,
    bool obscureText = false,
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: labelText,
        hintText: hintText,
        border: const OutlineInputBorder(),
      ),
      obscureText: obscureText,
      keyboardType: keyboardType,
      validator: validator,
    );
  }
}
