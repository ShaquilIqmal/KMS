import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:kms2/service/database_service.dart';
import 'package:kms2/service/stripe_service.dart';
import 'package:kms2/user/payment/paymentReceipt.dart'; // Import your ReceiptsPage here

class PaymentOverviewPage extends StatefulWidget {
  final String docId;
  final String childId;

  const PaymentOverviewPage({
    Key? key,
    required this.docId,
    required this.childId,
  }) : super(key: key);

  @override
  State<PaymentOverviewPage> createState() => _PaymentOverviewPageState();
}

class _PaymentOverviewPageState extends State<PaymentOverviewPage> {
  String _filter = "Current";
  List<Map<String, dynamic>> _selectedPayments = [];
  List<Map<String, dynamic>> _pastPayments = []; // Store past payments

  Future<double> _fetchTotalDueAmount() async {
    try {
      final dueAmount =
          await DatabaseService().fetchTotalDueAmount(widget.childId);
      return dueAmount;
    } catch (e) {
      return 0.0;
    }
  }

  Future<List<Map<String, dynamic>>> _fetchPaymentRecords() async {
    try {
      final records =
          await DatabaseService().fetchPaymentRecords(widget.childId);
      return records;
    } catch (e) {
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> _fetchPastPayments() async {
    try {
      final paymentIntents =
          await DatabaseService().fetchPaymentIntents(widget.childId);
      return paymentIntents;
    } catch (e) {
      return [];
    }
  }

  double _calculateSelectedAmount() {
    return _selectedPayments.fold(
        0.0, (total, payment) => total + (payment['amount'] ?? 0.0));
  }

  bool _isPaymentSelected(Map<String, dynamic> payment) {
    return _selectedPayments.any((selected) =>
        selected['description'] == payment['description'] &&
        selected['amount'] == payment['amount'] &&
        selected['dueDate'] == payment['dueDate']);
  }

  void _toggleSelection(Map<String, dynamic> payment) {
    setState(() {
      if (_isPaymentSelected(payment)) {
        _selectedPayments.removeWhere((selected) =>
            selected['description'] == payment['description'] &&
            selected['amount'] == payment['amount'] &&
            selected['dueDate'] == payment['dueDate']);
      } else {
        _selectedPayments.add({
          'id': payment['id'],
          'childId': widget.childId,
          'amount': payment['amount'],
          'feeType': payment['feeType'],
          ...payment,
        });
      }
    });
  }

  Future<void> _handlePayment() async {
    double paymentAmount = _calculateSelectedAmount();
    if (paymentAmount > 0) {
      List<String> selectedFeeTypes = _selectedPayments
          .map((payment) => payment['feeType'] as String? ?? 'N/A')
          .toList()
          .cast<String>();

      await StripeService.instance
          .makePayment(paymentAmount, _selectedPayments, selectedFeeTypes);
      setState(() {
        _selectedPayments.clear(); // Clear selections after payment
      });
    }
  }

  void _navigateToPastPayments() async {
    List<Map<String, dynamic>> pastPayments = await _fetchPastPayments();
    setState(() {
      _pastPayments = pastPayments;
      _filter = "Past"; // Set filter to Past
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Payment Overview (Doc ID: ${widget.docId})'),
        backgroundColor: Colors.blue[100],
      ),
      body: Column(
        children: [
          FutureBuilder<double>(
            future: _fetchTotalDueAmount(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return const Center(child: Text('Error fetching due amount'));
              } else {
                double dueAmount = snapshot.data ?? 0.0;
                double selectedAmount = _calculateSelectedAmount();

                return Container(
                  padding: const EdgeInsets.all(16.0),
                  color: Colors.blue[50],
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text.rich(
                            TextSpan(
                              children: [
                                const TextSpan(
                                  text: 'Due Amount: ',
                                  style: TextStyle(
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                TextSpan(
                                  text: '\$${dueAmount.toStringAsFixed(2)}',
                                  style: const TextStyle(
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.red,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          ElevatedButton(
                            onPressed: _handlePayment,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                            ),
                            child: const Text('Pay Now'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8.0),
                      Text.rich(
                        TextSpan(
                          children: [
                            const TextSpan(
                              text: 'Selected Amount: ',
                              style: TextStyle(
                                fontSize: 16.0,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                            TextSpan(
                              text: '\$${selectedAmount.toStringAsFixed(2)}',
                              style: const TextStyle(
                                fontSize: 16.0,
                                fontWeight: FontWeight.normal,
                                color: Colors.red,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              }
            },
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _filter = "Current"; // Reset filter to Current
                      _pastPayments.clear(); // Clear past payments
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        _filter == "Current" ? Colors.blue : Colors.grey[300],
                  ),
                  child: const Text('Current'),
                ),
                ElevatedButton(
                  onPressed: _navigateToPastPayments,
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        _filter == "Past" ? Colors.blue : Colors.grey[300],
                  ),
                  child: const Text('Past'),
                ),
              ],
            ),
          ),
          Expanded(
            child: _filter == "Past"
                ? _buildPastPaymentsList()
                : _buildCurrentPaymentsList(),
          ),
        ],
      ),
    );
  }

  Widget _buildCurrentPaymentsList() {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _fetchPaymentRecords(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return const Center(child: Text('Error fetching payment records'));
        } else {
          List<Map<String, dynamic>> paymentRecords = snapshot.data ?? [];

          // Filter payments based on the selected filter
          List<Map<String, dynamic>> filteredPayments =
              paymentRecords.where((payment) {
            return _filter == "Current" && !payment['paid'] ||
                _filter == "Past";
          }).toList();

          // Sort based on the filter
          if (_filter == "Current") {
            filteredPayments.sort((a, b) {
              DateTime dueDateA = DateTime.parse(a['dueDate']);
              DateTime dueDateB = DateTime.parse(b['dueDate']);
              return dueDateA.compareTo(dueDateB);
            });
            filteredPayments = filteredPayments.reversed.toList();
          }

          return filteredPayments.isEmpty
              ? const Center(child: Text('No payment records found.'))
              : ListView.builder(
                  padding: const EdgeInsets.all(16.0),
                  itemCount: filteredPayments.length,
                  itemBuilder: (context, index) {
                    final payment = filteredPayments[index];
                    bool isSelected = _isPaymentSelected(payment);

                    return Card(
                      margin: const EdgeInsets.only(bottom: 16.0),
                      child: ListTile(
                        tileColor: isSelected ? Colors.lightBlue[100] : null,
                        title: Text(
                          '${payment['feeType'] ?? 'N/A'}',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Amount: \$${payment['amount'] ?? 0.0}'),
                            if (_filter == "Current")
                              Text('Due Date: ${payment['dueDate'] ?? 'N/A'}'),
                            Text(
                                'Status: ${payment['paid'] ? 'Paid' : 'Unpaid'}'),
                          ],
                        ),
                        onTap: () => _toggleSelection(payment),
                        trailing: payment['paid']
                            ? const Icon(Icons.check_circle,
                                color: Colors.green)
                            : const Icon(Icons.error, color: Colors.red),
                      ),
                    );
                  },
                );
        }
      },
    );
  }

  Widget _buildPastPaymentsList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: _pastPayments.length,
      itemBuilder: (context, index) {
        final payment = _pastPayments[index];

        return Card(
          margin: const EdgeInsets.only(bottom: 16.0),
          child: ListTile(
            title: Text(
              DateFormat('yyyy-MM-dd')
                  .format(payment['date'].toDate()), // Format date
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Items:'),
                if (payment['fees'] != null && payment['fees'] is List)
                  ...payment['fees'].map<Widget>((fee) {
                    return Padding(
                      padding: const EdgeInsets.only(
                          left: 8.0, bottom: 4.0), // Indent and spacing
                      child: Row(
                        children: [
                          const Text('• '), // Bullet point
                          Expanded(
                            child: Text(
                              '${fee['feeType']}: \RM${fee['amount']}',
                              style: const TextStyle(fontSize: 14.0),
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                Text(
                  'Total: \RM${payment['totalAmount'] ?? 0.0}',
                ),
                const Text(
                  'PAID',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.green,
                    fontSize: 16.0,
                  ),
                ),
              ],
            ),
            trailing: IconButton(
              icon: const Icon(Icons.receipt_long, color: Colors.blue),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ReceiptsPage(
                      childId: widget.childId, // Pass childId
                      paymentId: payment['id_pi'], // Pass paymentId
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }
}
