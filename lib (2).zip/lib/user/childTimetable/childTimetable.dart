import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ChildTimetablePage extends StatefulWidget {
  final String childId; // Field to hold the child's ID
  final String selectedYear; // Field to hold the selected year

  const ChildTimetablePage({
    super.key,
    required this.childId, // Require the child's ID
    required this.selectedYear, // Require the selected year
  });

  @override
  State<ChildTimetablePage> createState() => _ChildTimetablePageState();
}

class _ChildTimetablePageState extends State<ChildTimetablePage> {
  List<String> timetableData =
      []; // List to hold timetable data for the selected day
  String selectedDay = 'Monday'; // Default selected day
  bool isLoading = false; // Loading state variable
  Map<String, List<String>> timetableCache =
      {}; // Local cache for timetable data

  @override
  void initState() {
    super.initState();
    _fetchTimetableForDay(
        selectedDay); // Fetch timetable for the default selected day
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: RichText(
          text: TextSpan(
            text: 'Child Timetable - ',
            style: const TextStyle(
              color: Colors.black,
              fontSize: 20,
            ),
            children: <TextSpan>[
              TextSpan(
                text: widget.selectedYear,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: 20,
                ),
              ),
            ],
          ),
        ),
        backgroundColor: Colors.blue[100],
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildDayButton(context, 'Mon', 'Monday'),
              const SizedBox(width: 5),
              _buildDayButton(context, 'Tue', 'Tuesday'),
              const SizedBox(width: 5),
              _buildDayButton(context, 'Wed', 'Wednesday'),
              const SizedBox(width: 5),
              _buildDayButton(context, 'Thu', 'Thursday'),
              const SizedBox(width: 5),
              _buildDayButton(context, 'Fri', 'Friday'),
            ],
          ),
          const SizedBox(height: 20),
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : _buildTimetable(), // Call the timetable build method
          ),
        ],
      ),
    );
  }

  // Build the timetable view
  Widget _buildTimetable() {
    if (timetableData.isEmpty) {
      return const Center(child: Text('No timetable available'));
    }

    return ListView.builder(
      itemCount: timetableData.length,
      itemBuilder: (context, index) {
        final entry = timetableData[index].split(' - ');
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            padding: const EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              color: Colors.lightBlue[100],
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  flex: 2,
                  child: Text(
                    entry[0],
                    style: const TextStyle(fontSize: 16),
                    textAlign: TextAlign.left,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  flex: 3,
                  child: Text(
                    entry[1],
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  flex: 2,
                  child: Text(
                    entry[2],
                    style: const TextStyle(fontSize: 16),
                    textAlign: TextAlign.left,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // Build day button with short and full names
  Widget _buildDayButton(
      BuildContext context, String shortDay, String fullDay) {
    Color buttonColor = selectedDay == fullDay
        ? const Color.fromARGB(255, 173, 216, 230)
        : Colors.grey[300]!;

    return ElevatedButton(
      onPressed: () {
        if (selectedDay != fullDay) {
          setState(() {
            selectedDay = fullDay; // Update selected day
            timetableData
                .clear(); // Clear previous timetable data for the new selection
          });
          _fetchTimetableForDay(fullDay); // Fetch timetable for the new day
        }
      },
      child: Text(shortDay), // Display short day label (e.g., "Mon")
      style: ElevatedButton.styleFrom(
        minimumSize: const Size(40, 40), // Minimum size for height
        primary: buttonColor, // Use the determined button color
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  // Fetch timetable data for the selected year and day
  Future<void> _fetchTimetableForDay(String day) async {
    // Log the fetching parameters
    print('Fetching timetable for year: ${widget.selectedYear}, day: $day');

    // Check if data is already cached
    if (timetableCache.containsKey(day)) {
      timetableData = timetableCache[day]!;
      setState(() {});
      return; // Return early if data is cached
    }

    setState(() {
      isLoading = true; // Start loading
    });

    try {
      // Fetch timetable data from Firestore
      await _getTimetableFromFirestore(day);
      // Sort the fetched timetable data
      _sortTimetableData();
      timetableCache[day] = List.from(timetableData);

      setState(() {}); // Update UI
    } catch (e) {
      print('Error fetching timetable for $day: $e');
    } finally {
      setState(() {
        isLoading = false; // Stop loading
      });
    }
  }

  // Fetch timetable data from Firestore
  Future<void> _getTimetableFromFirestore(String day) async {
    QuerySnapshot timeslotsSnapshot = await FirebaseFirestore.instance
        .collection('timetable')
        .where('year', isEqualTo: widget.selectedYear)
        .where('day', isEqualTo: day)
        .get();

    print('Fetched ${timeslotsSnapshot.docs.length} timeslot documents.');

    // Clear previous timetable data
    timetableData.clear();

    for (var doc in timeslotsSnapshot.docs) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      String timeslot =
          data['timeslot'] ?? 'No timeslot'; // Use the 'timeslot' field
      String subject = data['subject'] ?? 'No subject';
      String teacher = data['teacher'] ?? 'No teacher';

      // Create a formatted string for the timetable
      String timetableEntry = '$timeslot - $subject - $teacher';
      timetableData.add(timetableEntry); // Add the entry to the list
    }

    print('Timetable data for $day: $timetableData');
  }

  // Sort timetable data based on the timeslot
  void _sortTimetableData() {
    timetableData.sort((a, b) {
      DateTime startTimeA = _parseTime(a.split(' - ')[0].split('-')[0]);
      DateTime startTimeB = _parseTime(b.split(' - ')[0].split('-')[0]);
      return startTimeA.compareTo(startTimeB); // Compare times as DateTime
    });
  }

  // Helper function to parse time string into DateTime
  DateTime _parseTime(String time) {
    List<String> parts = time.split('.');
    int hour = int.parse(parts[0]);
    int minute = int.parse(parts[1]);

    // Create a DateTime object; year/month/day are arbitrary here
    return DateTime(0, 1, 1, hour, minute);
  }
}
