import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:kms2/user/registerchild/registerchildC.dart';

class RegisterChildBPage extends StatefulWidget {
  final String docId;
  final Map<String, dynamic> dataA;

  RegisterChildBPage({Key? key, required this.docId, required this.dataA})
      : super(key: key);

  @override
  State<RegisterChildBPage> createState() => _RegisterChildBPageState();
}

class _RegisterChildBPageState extends State<RegisterChildBPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController fatherNameController = TextEditingController();
  final TextEditingController fatherICController = TextEditingController();
  final TextEditingController fatherAddressController = TextEditingController();
  final TextEditingController fatherHomeTelController = TextEditingController();
  final TextEditingController fatherHandphoneController =
      TextEditingController();
  final TextEditingController fatherEmailController = TextEditingController();
  String? selectedIncomeRange;

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  Future<void> _fetchData() async {
    DocumentSnapshot userDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.docId)
        .get();

    if (userDoc.exists) {
      setState(() {
        fatherNameController.text = userDoc['name'] ?? '';
        fatherHandphoneController.text = userDoc['noTel'] ?? '';
        fatherEmailController.text = userDoc['email'] ?? '';
      });
    }
  }

  @override
  void dispose() {
    fatherNameController.dispose();
    fatherICController.dispose();
    fatherAddressController.dispose();
    fatherHomeTelController.dispose();
    fatherHandphoneController.dispose();
    fatherEmailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Sec B - Guardian's Particulars"),
        backgroundColor: Colors.blue[100],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: _buildFormContent(),
      ),
    );
  }

  Widget _buildFormContent() {
    return Form(
      key: _formKey,
      child: ListView(
        children: <Widget>[
          const Text(
            "B. Guardian's Particulars",
            style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: fatherNameController,
            labelText: 'Name (as per IC)',
            hintText: 'Enter name (as per IC)',
            readOnly: true,
            validator: (value) =>
                value == null || value.isEmpty ? 'Please enter name' : null,
            decoration: const InputDecoration(
              labelText: 'Name (as per IC)',
              hintText: 'Enter name (as per IC)',
              border: OutlineInputBorder(),
              fillColor: Color.fromARGB(255, 216, 216, 216),
              filled: true,
            ),
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: fatherICController,
            labelText: 'IC ',
            hintText: 'Enter IC number',
            keyboardType: TextInputType.number,
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter IC number'
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildDropdownFormField(
            value: selectedIncomeRange,
            items: [
              '0-RM2000',
              'RM2000-RM4000',
              'RM4000-RM6000',
              'RM6000-RM8000',
              'RM8000 and above'
            ],
            labelText: 'Total Monthly Income',
            hintText: 'Select total monthly income',
            validator: (value) => value == null || value.isEmpty
                ? 'Please select total monthly income'
                : null,
            onChanged: (value) {
              setState(() {
                selectedIncomeRange = value as String?;
              });
            },
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: fatherAddressController,
            labelText: 'Home Address',
            hintText: 'Enter home address',
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter home address with postcode'
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: fatherHomeTelController,
            labelText: 'Tel no (Home)',
            hintText: 'Enter home telephone number',
            keyboardType: TextInputType.phone,
            validator: (value) => null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: fatherHandphoneController,
            labelText: 'Tel no (Handphone)',
            hintText: 'Enter handphone number',
            readOnly: true,
            keyboardType: TextInputType.phone,
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter handphone number'
                : null,
            decoration: const InputDecoration(
              labelText: 'Tel no (Handphone)',
              hintText: 'Enter handphone number',
              border: OutlineInputBorder(),
              fillColor: Color.fromARGB(255, 216, 216, 216),
              filled: true,
            ),
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: fatherEmailController,
            labelText: 'Email',
            hintText: 'Enter email',
            readOnly: true,
            keyboardType: TextInputType.emailAddress,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter email';
              } else if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                return 'Please enter a valid email';
              }
              return null;
            },
            decoration: const InputDecoration(
              labelText: 'Email',
              hintText: 'Enter email',
              border: OutlineInputBorder(),
              fillColor: Color.fromARGB(255, 216, 216, 216),
              filled: true,
            ),
          ),
          const SizedBox(height: 16.0),
          ElevatedButton(
            onPressed: _submitData,
            child: const Text('Next - Section C'),
          ),
        ],
      ),
    );
  }

  void _submitData() {
    if (_formKey.currentState?.validate() ?? false) {
      String fatherName = fatherNameController.text;
      String fatherIC = fatherICController.text;
      String fatherIncome = selectedIncomeRange ?? '';
      String fatherAddress = fatherAddressController.text;
      String fatherHomeTel = fatherHomeTelController.text;
      String fatherHandphone = fatherHandphoneController.text;
      String fatherEmail = fatherEmailController.text;

      // Create a Map to hold the data
      Map<String, dynamic> dataB = {
        'nameF': fatherName,
        'icF': fatherIC,
        'incomeF': fatherIncome,
        'addressF': fatherAddress,
        'homeTelF': fatherHomeTel,
        'handphoneF': fatherHandphone,
        'emailF': fatherEmail,
      };

      print('docId: ${widget.docId}');
      print('DataA: ${widget.dataA}');
      print('DataB: $dataB');

      // Navigate to the next section or perform any necessary operations with the data
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => RegisterChildCPage(
            docId: widget.docId,
            dataA: widget.dataA,
            dataB: dataB,
          ),
        ),
      );
    }
  }

  Widget _buildTextFormField({
    required TextEditingController controller,
    required String labelText,
    required String hintText,
    bool obscureText = false,
    TextInputType keyboardType = TextInputType.text,
    bool readOnly = false,
    String? Function(String?)? validator,
    InputDecoration? decoration,
  }) {
    return TextFormField(
      controller: controller,
      decoration: decoration ??
          InputDecoration(
            labelText: labelText,
            hintText: hintText,
            border: const OutlineInputBorder(),
          ),
      obscureText: obscureText,
      keyboardType: keyboardType,
      readOnly: readOnly,
      validator: validator,
    );
  }

  Widget _buildDropdownFormField({
    required String? value,
    required List<String> items,
    required String labelText,
    required String hintText,
    String? Function(String?)? validator,
    void Function(String?)? onChanged,
  }) {
    return DropdownButtonFormField<String>(
      value: value,
      decoration: InputDecoration(
        labelText: labelText,
        hintText: hintText,
        border: const OutlineInputBorder(),
      ),
      items: items.map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(value),
        );
      }).toList(),
      validator: validator,
      onChanged: onChanged,
    );
  }
}
