import 'package:flutter/material.dart';

import 'registerchildD.dart';

class RegisterChildCPage extends StatefulWidget {
  final String docId;
  final Map<String, dynamic> dataA;
  final Map<String, dynamic> dataB;

  RegisterChildCPage({
    Key? key,
    required this.docId,
    required this.dataA,
    required this.dataB,
  }) : super(key: key);

  @override
  State<RegisterChildCPage> createState() => _RegisterChildCPageState();
}

class _RegisterChildCPageState extends State<RegisterChildCPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController medicalConditionController =
      TextEditingController();
  final TextEditingController doctorTelController = TextEditingController();
  final TextEditingController clinicHospitalController =
      TextEditingController();

/*
  @override
  void initState() {
    super.initState();
    print('docId: ${widget.docId}');
    print('dataA: ${widget.dataA}');
    print('dataB: ${widget.dataB}');
  }*/

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Sec C - Medical Data"),
        backgroundColor: Colors.blue[100],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: _buildFormContent(),
      ),
    );
  }

  Widget _buildFormContent() {
    return Form(
      key: _formKey,
      child: ListView(
        children: <Widget>[
          const Text(
            "C. Medical Data",
            style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: medicalConditionController,
            labelText: "Medical Condition | Type '-' for no Info",
            hintText: 'Enter medical condition',
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter medical condition'
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: doctorTelController,
            labelText: "Doctor Tel No | Type '-' for no Info",
            hintText: 'Enter doctor\'s telephone number',
            keyboardType: TextInputType.phone,
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter doctor\'s telephone number'
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: clinicHospitalController,
            labelText: "Clinic/Hospital | Type '-' for no Info",
            hintText: 'Enter clinic or hospital name',
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter clinic or hospital name'
                : null,
          ),
          const SizedBox(height: 16.0),
          ElevatedButton(
            onPressed: _submitData,
            child: const Text('Next - Section D'),
          ),
        ],
      ),
    );
  }

  void _submitData() {
    if (_formKey.currentState?.validate() ?? false) {
      String medicalCondition = medicalConditionController.text;
      String doctorTel = doctorTelController.text;
      String clinicHospital = clinicHospitalController.text;

      // Create a Map to hold the data
      Map<String, dynamic> dataC = {
        'medicalCondition': medicalCondition,
        'doctorTel': doctorTel,
        'clinicHospital': clinicHospital,
      };

      print('docId: ${widget.docId}');
      print('DataA: ${widget.dataA}');
      print('DataB: ${widget.dataB}');
      print('DataC: $dataC');

      // Here you can navigate to the next section or perform any necessary operations with the data
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => RegisterChildDPage(
            docId: widget.docId,
            dataA: widget.dataA,
            dataB: widget.dataB,
            dataC: dataC,
          ),
        ),
      );
    }
  }

  Widget _buildTextFormField({
    required TextEditingController controller,
    required String labelText,
    required String hintText,
    bool obscureText = false,
    TextInputType keyboardType = TextInputType.text,
    bool readOnly = false,
    String? Function(String?)? validator,
    InputDecoration? decoration,
  }) {
    return TextFormField(
      controller: controller,
      decoration: decoration ??
          InputDecoration(
            labelText: labelText,
            hintText: hintText,
            border: const OutlineInputBorder(),
          ),
      obscureText: obscureText,
      keyboardType: keyboardType,
      readOnly: readOnly,
      validator: validator,
    );
  }
}
