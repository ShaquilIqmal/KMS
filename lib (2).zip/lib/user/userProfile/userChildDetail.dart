// lib/user/userProfile/userChildDetail.dart

import 'package:flutter/material.dart';
import 'package:kms2/service/zmodel/childmodel.dart'; // Make sure this import is correct

class UserChildDetailPage extends StatelessWidget {
  final Child child;

  const UserChildDetailPage({Key? key, required this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(child.sectionA['nameC'] ?? 'Child Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Section A: Child\'s Particulars',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text('Child Name: ${child.sectionA['nameC'] ?? 'N/A'}'),
            Text('Gender: ${child.sectionA['genderC'] ?? 'N/A'}'),
            Text('Address: ${child.sectionA['addressC'] ?? 'N/A'}'),
            Text('Date of Birth: ${child.sectionA['dateOfBirthC'] ?? 'N/A'}'),
            Text('Age: ${child.sectionA['yearID'] ?? 'N/A'}'),
            Text('MyKid: ${child.sectionA['myKidC'] ?? 'N/A'}'),
            Text('Religion: ${child.sectionA['religionC'] ?? 'N/A'}'),
            const SizedBox(height: 16),
            const Text('Section B: Guardian\'s Particulars',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text('Father\'s Name: ${child.sectionB['nameF'] ?? 'N/A'}'),
            Text('Father\'s IC: ${child.sectionB['icF'] ?? 'N/A'}'),
            Text('Father\'s Income: ${child.sectionB['incomeF'] ?? 'N/A'}'),
            Text('Father\'s Address: ${child.sectionB['addressF'] ?? 'N/A'}'),
            Text('Father\'s Home Tel: ${child.sectionB['homeTelF'] ?? 'N/A'}'),
            Text(
                'Father\'s Handphone: ${child.sectionB['handphoneF'] ?? 'N/A'}'),
            Text('Father\'s Email: ${child.sectionB['emailF'] ?? 'N/A'}'),
            const SizedBox(height: 16),
            const Text('Section C: Medical Information',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text(
                'Medical Condition: ${child.sectionC['medicalCondition'] ?? 'N/A'}'),
            Text('Doctor\'s Tel: ${child.sectionC['doctorTel'] ?? 'N/A'}'),
            Text(
                'Clinic/Hospital: ${child.sectionC['clinicHospital'] ?? 'N/A'}'),
            const SizedBox(height: 16),
            const Text('Section D: Emergency Contact',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text('Name: ${child.sectionD['nameM'] ?? 'N/A'}'),
            Text('Tel: ${child.sectionD['telM'] ?? 'N/A'}'),
            Text('Relationship: ${child.sectionD['relationshipM'] ?? 'N/A'}'),
            const SizedBox(height: 16),
            const Text('Section E: Transportation Needs',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text(
                'Transportation: ${child.sectionE['transportation'] ?? 'N/A'}'),
            Text('Pickup Address: ${child.sectionE['pickupAddress'] ?? 'N/A'}'),
            Text('Drop Address: ${child.sectionE['dropAddress'] ?? 'N/A'}'),
            const SizedBox(height: 16),
            // Add more details about the child as needed
            // For example: display other sections or milestones
          ],
        ),
      ),
    );
  }
}
