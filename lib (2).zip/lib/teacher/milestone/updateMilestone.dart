import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class UpdateMilestonePage extends StatefulWidget {
  final String childId;
  final String childName;

  const UpdateMilestonePage(
      {Key? key, required this.childId, required this.childName})
      : super(key: key);

  @override
  State<UpdateMilestonePage> createState() => _UpdateMilestonePageState();
}

class _UpdateMilestonePageState extends State<UpdateMilestonePage> {
  List<Map<String, dynamic>> milestones = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchMilestones();
  }

  // Fetch milestones from the 'child' document and the corresponding details from the 'milestones' collection
  Future<void> fetchMilestones() async {
    try {
      // Fetch the 'child' document to get the milestone data
      DocumentSnapshot snapshot = await FirebaseFirestore.instance
          .collection('child')
          .doc(widget.childId)
          .get();

      final data = snapshot.data() as Map<String, dynamic>;

      // Get the milestone data (including IDs, achieved status, etc.)
      List<dynamic> milestoneEntries = data['milestones'] ?? [];

      // Fetch the milestone details from the 'milestones' collection
      List<Map<String, dynamic>> fetchedMilestones = [];

      for (var milestoneData in milestoneEntries) {
        if (milestoneData is Map<String, dynamic>) {
          String milestoneId = milestoneData['milestoneId'] ?? '';

          // Fetch the corresponding milestone document from the 'milestones' collection using milestoneId
          DocumentSnapshot milestoneDoc = await FirebaseFirestore.instance
              .collection('milestones')
              .doc(milestoneId)
              .get();

          if (milestoneDoc.exists) {
            var milestoneDocData = milestoneDoc.data() as Map<String, dynamic>;

            // Add all milestone details (including those fetched from 'milestones' collection)
            fetchedMilestones.add({
              'milestoneId': milestoneId,
              'title': milestoneDocData['title'],
              'description': milestoneDocData['description'],
              'criteria': milestoneDocData['criteria'],
              'year': milestoneDocData['year'],
              'milestoneLevel':
                  milestoneDocData['milestoneLevel'], // Added field
              'category': milestoneDocData['category'],
              'achieved': milestoneData['achieved'] ?? false,
              'lastUpdated': milestoneData['lastUpdated'],
            });
          }
        } else {
          print('Milestone data is not a Map: $milestoneData');
        }
      }

      setState(() {
        milestones = fetchedMilestones;
        isLoading = false; // Hide loading indicator when data is fetched
      });
    } catch (e) {
      print('Error fetching milestones: $e');
      setState(() {
        isLoading = false; // Hide loading indicator in case of error
      });
    }
  }

  // Update the status of a milestone
  Future<void> updateMilestoneStatus(int index, bool achieved) async {
    milestones[index]['achieved'] = achieved;
    milestones[index]['lastUpdated'] = Timestamp.now();

    try {
      await FirebaseFirestore.instance
          .collection('child')
          .doc(widget.childId)
          .update({'milestones': milestones});

      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Milestone updated')),
      );
    } catch (e) {
      print('Error updating milestone: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to update milestone')),
      );
    }
  }

  // Format the 'lastUpdated' timestamp
  String formatDate(Timestamp? timestamp) {
    if (timestamp == null) return 'Not updated';
    DateTime date = timestamp.toDate();
    return DateFormat('yyyy-MM-dd HH:mm').format(date);
  }

  // Show a dialog with milestone details
  void showMilestoneDetails(Map<String, dynamic> milestone) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(milestone['title']),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Description: ${milestone['description']}'),
              Text('Criteria: ${milestone['criteria']}'),
              Text('Year: ${milestone['year']}'),
              Text('Achieved: ${milestone['achieved'] ? "Yes" : "No"}'),
              Text(
                  'Milestone Level: ${milestone['milestoneLevel'] ?? "Not Available"}'), // New line for milestoneLevel
              Text('Last Updated: ${formatDate(milestone['lastUpdated'])}'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  // Group milestones by category
  Map<String, List<Map<String, dynamic>>> groupMilestonesByCategory() {
    Map<String, List<Map<String, dynamic>>> groupedMilestones = {};

    for (var milestone in milestones) {
      String category = milestone['criteria'] ?? 'Uncategorized';
      if (!groupedMilestones.containsKey(category)) {
        groupedMilestones[category] = [];
      }
      groupedMilestones[category]!.add(milestone);
    }

    return groupedMilestones;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Milestones for ${widget.childName}'),
      ),
      body: isLoading
          ? const Center(
              child:
                  CircularProgressIndicator()) // Show loading indicator while data is being fetched
          : ListView(
              children: groupMilestonesByCategory().entries.map((entry) {
                String category = entry.key;
                List<Map<String, dynamic>> milestonesInCategory = entry.value;

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        category,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    ...milestonesInCategory.map((milestone) {
                      final lastUpdated = milestone['lastUpdated'] != null
                          ? DateFormat('yyyy-MM-dd HH:mm').format(
                              (milestone['lastUpdated'] as Timestamp).toDate(),
                            )
                          : 'Not updated';

                      return Card(
                        margin: const EdgeInsets.all(8.0),
                        child: ListTile(
                          title: Text(
                            milestone['milestoneId'],
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                  'Achieved: ${milestone['achieved'] ? "Yes" : "No"}'),
                              Text('Last Updated: $lastUpdated'),
                            ],
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              // Button to view milestone details
                              IconButton(
                                icon: const Icon(Icons.info_outline),
                                onPressed: () {
                                  showMilestoneDetails(milestone);
                                },
                              ),
                              // Switch to update milestone status
                              Switch(
                                value: milestone['achieved'],
                                onChanged: (value) {
                                  updateMilestoneStatus(
                                      milestones.indexOf(milestone), value);
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  ],
                );
              }).toList(),
            ),
    );
  }
}
