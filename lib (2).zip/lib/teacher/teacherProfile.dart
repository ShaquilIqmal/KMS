import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:kms2/service/zmodel/teachermodel.dart';

class TeacherProfilePage extends StatefulWidget {
  final String docId; // Add docId as a parameter

  const TeacherProfilePage({Key? key, required this.docId}) : super(key: key);

  @override
  _TeacherProfilePageState createState() => _TeacherProfilePageState();
}

class _TeacherProfilePageState extends State<TeacherProfilePage> {
  Teacher? teacher; // To hold the fetched teacher data
  bool isLoading = true; // Loading state

  @override
  void initState() {
    super.initState();
    fetchTeacherData(); // Fetch teacher data on initialization
  }

  Future<void> fetchTeacherData() async {
    try {
      DocumentSnapshot doc = await FirebaseFirestore.instance
          .collection('teachers') // Replace with your collection name
          .doc(widget.docId)
          .get();
      setState(() {
        teacher =
            Teacher.fromDocument(doc); // Convert document to Teacher object
        isLoading = false; // Set loading to false after fetching data
      });
    } catch (e) {
      print('Error fetching teacher data: $e');
      setState(() {
        isLoading = false; // Set loading to false on error
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Teacher Profile'),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : teacher != null
              ? Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CircleAvatar(
                        radius: 50.0,
                        backgroundImage: teacher!.profileImage != null &&
                                teacher!.profileImage!.isNotEmpty
                            ? NetworkImage(teacher!.profileImage!)
                            : const AssetImage('assets/default_profile.png')
                                as ImageProvider,
                      ),
                      const SizedBox(height: 16.0),
                      Text(
                        'Name: ${teacher!.name}',
                        style: const TextStyle(fontSize: 20.0),
                      ),
                      Text('Date of Birth: ${teacher!.dateOfBirth}'),
                      Text('Gender: ${teacher!.gender}'),
                      Text('ID Number: ${teacher!.idNumber}'),
                      const SizedBox(height: 16.0),
                      const Text(
                        'Contact Information:',
                        style: TextStyle(
                            fontSize: 18.0, fontWeight: FontWeight.bold),
                      ),
                      Text('Phone: ${teacher!.contactInfo.phoneNumber}'),
                      Text('Email: ${teacher!.contactInfo.email}'),
                      Text('Address: ${teacher!.contactInfo.homeAddress}'),
                      const SizedBox(height: 16.0),
                      const Text(
                        'Employment Information:',
                        style: TextStyle(
                            fontSize: 18.0, fontWeight: FontWeight.bold),
                      ),
                      Text('Position: ${teacher!.employmentInfo.position}'),
                      Text(
                          'Joining Date: ${teacher!.employmentInfo.joiningDate}'),
                      Text(
                          'Status: ${teacher!.employmentInfo.employmentStatus}'),
                      Text('Salary: ${teacher!.employmentInfo.salary}'),
                    ],
                  ),
                )
              : const Center(child: Text('Teacher not found')),
    );
  }
}
