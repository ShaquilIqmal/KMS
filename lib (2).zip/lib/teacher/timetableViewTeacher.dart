import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:kms2/service/database_service.dart'; // Import your DatabaseService

class TeacherTimetablePage extends StatefulWidget {
  final String teacherId;

  const TeacherTimetablePage({super.key, required this.teacherId});

  @override
  State<TeacherTimetablePage> createState() => _TeacherTimetablePageState();
}

class _TeacherTimetablePageState extends State<TeacherTimetablePage> {
  List<String> timetableData = [];
  String selectedDay = 'Monday';
  bool isLoading = false;
  Map<String, List<String>> timetableCache = {};
  String? teacherName; // To hold the teacher's name

  @override
  void initState() {
    super.initState();
    _fetchTeacherName(); // Fetch teacher's name
  }

  // Fetch the teacher's name using DatabaseService
  Future<void> _fetchTeacherName() async {
    teacherName = await DatabaseService.fetchUserName(widget.teacherId);
    if (teacherName != null) {
      print('Teacher Name: $teacherName'); // Print the teacher's name
      _fetchTimetableForDay(
          selectedDay); // Fetch timetable data after getting the teacher's name
    } else {
      print('Teacher not found for ID: ${widget.teacherId}');
    }
  }

  // Fetch timetable data for the selected day
  Future<void> _fetchTimetableForDay(String day) async {
    if (timetableCache.containsKey(day)) {
      timetableData = timetableCache[day]!;
      setState(() {});
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      QuerySnapshot timeslotsSnapshot = await FirebaseFirestore.instance
          .collection('timetable') // Collection name
          .where('day', isEqualTo: day) // Filter by day
          .where('teacher', isEqualTo: teacherName) // Filter by teacher's name
          .get();

      timetableData.clear();

      for (var doc in timeslotsSnapshot.docs) {
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        String timeslot = data['timeslot'] ?? 'No timeslot';
        String subject = data['subject'] ?? 'No subject';
        String year = data['year'] ?? 'No year';

        String timetableEntry = '$timeslot - $subject -  $year';
        timetableData.add(timetableEntry);
      }

      timetableData.sort((a, b) {
        String timeA = a.split(' - ')[0]; // Extract timeslot for sorting
        String timeB = b.split(' - ')[0];
        return double.parse(timeA.split('-')[0])
            .compareTo(double.parse(timeB.split('-')[0]));
      });

      timetableCache[day] = List.from(timetableData);
      setState(() {});
    } catch (e) {
      print('Error fetching timetable for $day: $e');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Teacher Timetable'),
        backgroundColor: Colors.blue[100],
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildDayButton('Mon', 'Monday'),
              const SizedBox(width: 5),
              _buildDayButton('Tue', 'Tuesday'),
              const SizedBox(width: 5),
              _buildDayButton('Wed', 'Wednesday'),
              const SizedBox(width: 5),
              _buildDayButton('Thu', 'Thursday'),
              const SizedBox(width: 5),
              _buildDayButton('Fri', 'Friday'),
            ],
          ),
          const SizedBox(height: 20),
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : _buildTimetable(),
          ),
        ],
      ),
    );
  }

  Widget _buildTimetable() {
    return timetableData.isEmpty
        ? const Center(child: Text('No timetable available'))
        : ListView.builder(
            itemCount: timetableData.length,
            itemBuilder: (context, index) {
              final entry = timetableData[index].split(' - ');
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    color: Colors.lightBlue[100],
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Expanded(
                        flex: 2,
                        child: Text(
                          entry[0], // timeslot
                          style: const TextStyle(fontSize: 16),
                          textAlign: TextAlign.left,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        flex: 3,
                        child: Text(
                          entry[1], // subject
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.left,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        flex: 2,
                        child: Text(
                          entry[2], // year
                          style: const TextStyle(fontSize: 16),
                          textAlign: TextAlign.left,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
  }

  Widget _buildDayButton(String shortDay, String fullDay) {
    Color buttonColor = selectedDay == fullDay
        ? const Color.fromARGB(255, 173, 216, 230)
        : Colors.grey[300]!;

    return ElevatedButton(
      onPressed: () {
        if (selectedDay != fullDay) {
          setState(() {
            selectedDay = fullDay;
            timetableData.clear();
          });
          _fetchTimetableForDay(fullDay);
        }
      },
      child: Text(shortDay),
      style: ElevatedButton.styleFrom(
        minimumSize: const Size(40, 40),
        primary: buttonColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }
}
