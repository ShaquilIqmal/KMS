import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:kms2/admin/viewUsers/viewUserChildInfo.dart';
import 'package:kms2/service/cloudinary_service.dart'; // Import your cloudinary service or appropriate service
import 'package:kms2/service/database_service.dart'; // Ensure this import is correct
import 'package:kms2/service/zmodel/childmodel.dart';
import 'package:kms2/service/zmodel/usermodel.dart';

class UserInformationPage extends StatefulWidget {
  final User user;

  UserInformationPage({required this.user});

  @override
  _UserInformationPageState createState() => _UserInformationPageState();
}

class _UserInformationPageState extends State<UserInformationPage> {
  final ImagePicker _picker = ImagePicker();
  bool _isUploading = false;

  Future<void> _pickImage() async {
    final XFile? pickedFile =
        await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _isUploading = true;
      });
      String imageUrl = await _uploadImageToCloudinary(pickedFile.path);
      if (imageUrl.isNotEmpty) {
        await _updateProfileImage(imageUrl);
      } else {
        setState(() {
          _isUploading = false;
        });
      }
    }
  }

  Future<String> _uploadImageToCloudinary(String filePath) async {
    try {
      String imageUrl = await CloudinaryService().uploadImage(filePath);
      return imageUrl;
    } catch (e) {
      print("Error uploading image: $e");
      return '';
    }
  }

  Future<void> _updateProfileImage(String imageUrl) async {
    try {
      await DatabaseService().updateUserProfileImage(widget.user.id, imageUrl);
      setState(() {
        widget.user.profileImage = imageUrl; // Update local state for display
        _isUploading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profile image updated successfully')),
      );
    } catch (e) {
      print("Error updating profile image: $e");
      setState(() {
        _isUploading = false;
      });
    }
  }

  void _editUserData() {
    final TextEditingController nameController =
        TextEditingController(text: widget.user.name);
    final TextEditingController emailController =
        TextEditingController(text: widget.user.email);
    final TextEditingController phoneController =
        TextEditingController(text: widget.user.noTel);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Edit User Information'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(labelText: 'Name'),
                ),
                TextField(
                  controller: emailController,
                  decoration: const InputDecoration(labelText: 'Email'),
                ),
                TextField(
                  controller: phoneController,
                  decoration: const InputDecoration(labelText: 'Telephone'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                String newName = nameController.text;
                String newEmail = emailController.text;
                String newPhone = phoneController.text;

                // Update user data in Firestore
                await DatabaseService().updateUserData(
                    widget.user.id, newName, newEmail, newPhone);
                setState(() {
                  widget.user.name = newName;
                  widget.user.email = newEmail;
                  widget.user.noTel = newPhone;
                });

                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                      content: Text('User information updated successfully')),
                );
                Navigator.of(context).pop();
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('User Information'),
        backgroundColor: Colors.blue[100],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            // User Profile Image
            Center(
              child: GestureDetector(
                onTap: _pickImage, // Change image on tap
                child: CircleAvatar(
                  radius: 50, // Adjust the radius as needed
                  backgroundImage: widget.user.profileImage != null &&
                          widget.user.profileImage!.isNotEmpty
                      ? NetworkImage(widget.user.profileImage!)
                      : null,
                  child: widget.user.profileImage == null ||
                          widget.user.profileImage!.isEmpty
                      ? const Icon(Icons.person,
                          size: 50) // Default icon if no image
                      : null,
                ),
              ),
            ),
            if (_isUploading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16.0),
                child: Center(child: CircularProgressIndicator()),
              ),
            const SizedBox(height: 16),
            Text('Name: ${widget.user.name}',
                style: const TextStyle(fontSize: 18)),
            Text('Email: ${widget.user.email}',
                style: const TextStyle(fontSize: 18)),
            Text('Telephone: ${widget.user.noTel}',
                style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _editUserData, // Call the edit function
              child: const Text('Edit User Information'),
            ),
            const Text('Children:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            if (widget.user.children.isEmpty)
              const Text('No children registered.')
            else
              ..._buildChildrenList(context, widget.user.children),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildChildrenList(BuildContext context, List<Child> children) {
    return children.map<Widget>((child) {
      return ListTile(
        leading: CircleAvatar(
          backgroundImage:
              child.profileImage != null && child.profileImage!.isNotEmpty
                  ? NetworkImage(child.profileImage!)
                  : null,
          child: child.profileImage == null || child.profileImage!.isEmpty
              ? const Icon(Icons.child_care, size: 40)
              : null,
        ),
        title: Text(child.sectionA['nameC'] ?? 'No Name'),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextButton(
              child: const Text('View'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ViewUserChildInfoPage(child: child),
                  ),
                );
              },
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () async {
                await _confirmDelete(context, child.id, widget.user.id);
              },
            ),
          ],
        ),
      );
    }).toList();
  }

  Future<void> _confirmDelete(
      BuildContext context, String childId, String userId) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Child'),
        content: const Text('Are you sure you want to delete this child?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (shouldDelete == true) {
      //attendanceCollection
      // Call the delete method from the DatabaseService
      await DatabaseService().deleteChild(childId, userId);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Child deleted successfully')),
      );
      Navigator.of(context).pop(); // Navigate back or refresh the UI
    }
  }
}
