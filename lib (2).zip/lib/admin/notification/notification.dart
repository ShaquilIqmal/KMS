import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class NotificationPage extends StatefulWidget {
  final String adminDocId;

  const NotificationPage({Key? key, required this.adminDocId})
      : super(key: key);
  @override
  _NotificationPageState createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();
  List<Map<String, dynamic>> _filteredUsers = [];
  List<Map<String, dynamic>> _filteredTeachers = [];
  List<Map<String, dynamic>> _selectedUsers = []; // Store as dynamic
  List<Map<String, dynamic>> _selectedTeachers = []; // Store as dynamic

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Send Notification'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTitleField(),
              SizedBox(height: 16),
              _buildMessageField(),
              SizedBox(height: 16),
              _buildRecipientHeader("Send To:"),
              _buildUserSearchField(),
              _buildSelectAllUsersButton(), // Add Select All Users Button
              _buildSelectedUsersDisplay(),
              _buildFilteredUserList(),
              _buildTeacherSearchField(),
              _buildSelectAllTeachersButton(), // Add Select All Teachers Button
              _buildSelectedTeachersDisplay(),
              _buildFilteredTeacherList(),
              SizedBox(height: 24),
              _buildSendNotificationButton(),
            ],
          ),
        ),
      ),
    );
  }

  // UI Widgets
  Widget _buildTitleField() {
    return TextFormField(
      controller: _titleController,
      decoration: InputDecoration(labelText: 'Title'),
      validator: (value) => value!.isEmpty ? 'Please enter a title' : null,
    );
  }

  Widget _buildMessageField() {
    return TextFormField(
      controller: _messageController,
      decoration: InputDecoration(labelText: 'Message'),
      maxLines: 4,
      validator: (value) => value!.isEmpty ? 'Please enter a message' : null,
    );
  }

  Widget _buildRecipientHeader(String title) {
    return Text(
      title,
      style: TextStyle(fontWeight: FontWeight.bold),
    );
  }

  Widget _buildUserSearchField() {
    return TextFormField(
      decoration: InputDecoration(labelText: 'Search Users'),
      onChanged: _searchUsers,
    );
  }

  Widget _buildSelectAllUsersButton() {
    return TextButton(
      onPressed: _selectAllUsers,
      child: Text('Select All Users'),
    );
  }

  Widget _buildSelectedUsersDisplay() {
    return Wrap(
      children: _selectedUsers.map((user) {
        return Container(
          margin: EdgeInsets.only(right: 8, bottom: 8),
          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.blueAccent,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            user['name']!, // Display the name of the selected user
            style: TextStyle(color: Colors.white, fontSize: 12),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildFilteredUserList() {
    return _filteredUsers.isNotEmpty
        ? ListView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: _filteredUsers.length,
            itemBuilder: (context, index) {
              final user = _filteredUsers[index];
              return ListTile(
                title: Text(user['name']),
                onTap: () {
                  _toggleUserSelection(user);
                },
              );
            },
          )
        : Container(); // Return an empty container if no users are found
  }

  Widget _buildTeacherSearchField() {
    return TextFormField(
      decoration: InputDecoration(labelText: 'Search Teachers'),
      onChanged: _searchTeachers,
    );
  }

  Widget _buildSelectAllTeachersButton() {
    return TextButton(
      onPressed: _selectAllTeachers,
      child: Text('Select All Teachers'),
    );
  }

  Widget _buildSelectedTeachersDisplay() {
    return Wrap(
      children: _selectedTeachers.map((teacher) {
        return Container(
          margin: EdgeInsets.only(right: 8, bottom: 8),
          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.greenAccent,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            teacher['name']!, // Display the name of the selected teacher
            style: TextStyle(color: Colors.white, fontSize: 12),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildFilteredTeacherList() {
    return _filteredTeachers.isNotEmpty
        ? ListView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: _filteredTeachers.length,
            itemBuilder: (context, index) {
              final teacher = _filteredTeachers[index];
              return ListTile(
                title: Text(teacher['name']),
                onTap: () {
                  _toggleTeacherSelection(teacher);
                },
              );
            },
          )
        : Container(); // Return an empty container if no teachers are found
  }

  Widget _buildSendNotificationButton() {
    return ElevatedButton(
      onPressed: _sendNotification,
      child: Text('Send Notification'),
    );
  }

  // Backend Functions
  void _searchUsers(String query) async {
    if (query.isEmpty) {
      setState(() {
        _filteredUsers.clear();
      });
      return;
    }

    final snapshot = await FirebaseFirestore.instance.collection('users').get();
    setState(() {
      _filteredUsers = snapshot.docs
          .where((user) => user['name']
              .toString()
              .toLowerCase()
              .contains(query.toLowerCase()))
          .map((user) => {
                'id': user.id,
                'name': user['name'],
              })
          .toList();
    });
  }

  void _searchTeachers(String query) async {
    if (query.isEmpty) {
      setState(() {
        _filteredTeachers.clear();
      });
      return;
    }

    final snapshot =
        await FirebaseFirestore.instance.collection('teachers').get();
    setState(() {
      _filteredTeachers = snapshot.docs
          .where((teacher) => teacher['name']
              .toString()
              .toLowerCase()
              .contains(query.toLowerCase()))
          .map((teacher) => {
                'id': teacher.id,
                'name': teacher['name'],
              })
          .toList();
    });
  }

  void _selectAllUsers() {
    setState(() {
      _selectedUsers = List.from(_filteredUsers
          .map((user) => {'id': user['id'], 'name': user['name']}));
    });
  }

  void _selectAllTeachers() {
    setState(() {
      _selectedTeachers = List.from(_filteredTeachers
          .map((teacher) => {'id': teacher['id'], 'name': teacher['name']}));
    });
  }

  Future<void> _sendNotificationToUser(
      String notificationId, String userId) async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection('notifications')
        .doc(notificationId)
        .set({
      'notificationId': notificationId,
      'title': _titleController.text,
      'message': _messageController.text,
      'timestamp': FieldValue.serverTimestamp(),
      'isRead': false,
    });
  }

  Future<void> _sendNotification() async {
    if (!_formKey.currentState!.validate()) return;

    // Ensure at least one recipient is selected
    if (_selectedUsers.isEmpty && _selectedTeachers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please select at least one recipient")),
      );
      return;
    }

    try {
      // Add notification document to the Firestore 'notifications' collection
      DocumentReference notificationRef =
          await FirebaseFirestore.instance.collection('notifications').add({
        'title': _titleController.text,
        'message': _messageController.text,
        'senderId': widget.adminDocId, // Replace with actual admin ID
        'timestamp': FieldValue.serverTimestamp(),
        'recipients': [
          ..._selectedUsers
              .map((user) => {'id': user['id'], 'name': user['name']}),
          ..._selectedTeachers
              .map((teacher) => {'id': teacher['id'], 'name': teacher['name']}),
        ],
      });

      // Send notification to selected users
      for (var user in _selectedUsers) {
        String? userId = user['id'];
        if (userId != null) {
          await _sendNotificationToUser(notificationRef.id, userId);
        }
      }

      // Send notification to selected teachers
      for (var teacher in _selectedTeachers) {
        String? teacherId = teacher['id'];
        if (teacherId != null) {
          await _sendNotificationToUser(notificationRef.id, teacherId);
        }
      }

      // Confirmation message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Notification sent successfully")),
      );

      // Clear fields and selections
      _titleController.clear();
      _messageController.clear();
      setState(() {
        _selectedUsers.clear();
        _selectedTeachers.clear();
        _filteredUsers.clear();
        _filteredTeachers.clear();
      });
    } catch (e) {
      print("Error sending notification: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error sending notification")),
      );
    }
  }

  void _toggleUserSelection(Map<String, dynamic> user) {
    setState(() {
      if (_selectedUsers.contains(user)) {
        _selectedUsers.remove(user);
      } else {
        _selectedUsers.add(user);
      }
    });
  }

  void _toggleTeacherSelection(Map<String, dynamic> teacher) {
    setState(() {
      if (_selectedTeachers.contains(teacher)) {
        _selectedTeachers.remove(teacher);
      } else {
        _selectedTeachers.add(teacher);
      }
    });
  }
}
