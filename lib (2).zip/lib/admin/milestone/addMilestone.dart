import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:kms2/service/database_service.dart'; // Adjust import as necessary

class AdminMilestonePage extends StatefulWidget {
  const AdminMilestonePage({super.key});

  @override
  State<AdminMilestonePage> createState() => _AdminMilestonePageState();
}

class _AdminMilestonePageState extends State<AdminMilestonePage> {
  String? selectedYear;
  String? selectedCriteria;
  String? selectedLevel;
  final TextEditingController titleController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();

  final List<String> years = ['Year 4', 'Year 5', 'Year 6'];
  final List<String> criteriaOptions = [
    'General',
    'Reading',
    'Writing',
    'Speaking',
    'Listening'
  ];
  final List<String> levels = ['1', '2', '3', '4'];

  @override
  void initState() {
    super.initState();
  }

  // Check if a milestone already exists for the selected criteria, year, and level
  Future<bool> checkIfLevelExists() async {
    if (selectedCriteria == null ||
        selectedLevel == null ||
        selectedYear == null) {
      return false; // No criteria, year, or level selected, no need to check
    }

    QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection('milestones')
        .where('criteria', isEqualTo: selectedCriteria)
        .where('year', isEqualTo: selectedYear)
        .where('milestoneLevel', isEqualTo: selectedLevel)
        .get();

    return snapshot.docs
        .isNotEmpty; // Return true if any document exists with the same criteria, year, and level
  }

  // Save the milestone data to Firestore
  Future<void> saveMilestone() async {
    bool levelExists = await checkIfLevelExists();

    if (levelExists) {
      // Show snackbar if the level already exists for the selected criteria and year
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              'The level for the selected criteria and year already exists.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    if (selectedLevel == null) {
      print('Please select a milestone level.');
      return;
    }

    final String title = titleController.text;
    final String description = descriptionController.text;

    // Generate milestone ID
    String milestoneId =
        '${selectedCriteria}_${selectedYear}_Level$selectedLevel';

    Map<String, dynamic> milestoneData = {
      'year': selectedYear,
      'title': title,
      'description': description,
      'criteria': selectedCriteria,
      'milestoneLevel': selectedLevel,
    };

    try {
      await DatabaseService().addMilestone(milestoneId, milestoneData);
      print('Milestone added with ID: $milestoneId');
      await linkMilestoneToChildren(milestoneId, selectedYear, achieved: false);

      titleController.clear();
      descriptionController.clear();
      setState(() {
        selectedYear = null;
        selectedCriteria = null;
        selectedLevel = null;
      });
    } catch (e) {
      print('Error saving milestone: $e');
    }
  }

  // Link the milestone to all children in the selected year
  Future<void> linkMilestoneToChildren(String milestoneId, String? year,
      {required bool achieved}) async {
    QuerySnapshot childrenSnapshot = await FirebaseFirestore.instance
        .collection('child')
        .where('SectionA.yearID', isEqualTo: year)
        .get();

    for (var childDoc in childrenSnapshot.docs) {
      var data = childDoc.data() as Map<String, dynamic>?;

      List<Map<String, dynamic>> currentMilestones =
          List<Map<String, dynamic>>.from(data?['milestones'] ?? []);

      currentMilestones.add({
        'milestoneId': milestoneId,
        'achieved': achieved,
      });

      await DatabaseService().childCollection.doc(childDoc.id).update({
        'milestones': currentMilestones,
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Milestone Setup'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Select Year:', style: TextStyle(fontSize: 16)),
            DropdownButton<String>(
              value: selectedYear,
              hint: const Text('Select Year'),
              isExpanded: true,
              items: years.map((String year) {
                return DropdownMenuItem<String>(
                  value: year,
                  child: Text(year),
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  selectedYear = newValue;
                });
              },
            ),
            const SizedBox(height: 16),
            const Text('Select Criteria:', style: TextStyle(fontSize: 16)),
            DropdownButton<String>(
              value: selectedCriteria,
              hint: const Text('Select Criteria'),
              isExpanded: true,
              items: criteriaOptions.map((String criteria) {
                return DropdownMenuItem<String>(
                  value: criteria,
                  child: Text(criteria),
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  selectedCriteria = newValue;
                });
              },
            ),
            const SizedBox(height: 16),
            const Text('Select Level:', style: TextStyle(fontSize: 16)),
            DropdownButton<String>(
              value: selectedLevel,
              hint: const Text('Select Level'),
              isExpanded: true,
              items: levels.map((String level) {
                return DropdownMenuItem<String>(
                  value: level,
                  child: Text(level),
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  selectedLevel = newValue;
                });
              },
            ),
            const SizedBox(height: 16),
            const Text('Title:', style: TextStyle(fontSize: 16)),
            TextField(
              controller: titleController,
              decoration: const InputDecoration(border: OutlineInputBorder()),
            ),
            const SizedBox(height: 16),
            const Text('Description:', style: TextStyle(fontSize: 16)),
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(border: OutlineInputBorder()),
              maxLines: 3,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: saveMilestone,
              child: const Text('Save Milestone'),
            ),
          ],
        ),
      ),
    );
  }
}
