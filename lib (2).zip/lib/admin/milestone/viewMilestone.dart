import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ViewMilestonePage extends StatefulWidget {
  const ViewMilestonePage({super.key});

  @override
  State<ViewMilestonePage> createState() => _ViewMilestonePageState();
}

class _ViewMilestonePageState extends State<ViewMilestonePage> {
  String selectedYear = 'Year 4'; // Default to Year 4
  Map<String, List<Map<String, dynamic>>> categorizedMilestones = {};

  final List<String> years = ['Year 4', 'Year 5', 'Year 6'];

  @override
  void initState() {
    super.initState();
    fetchMilestones();
  }

  Future<void> fetchMilestones() async {
    categorizedMilestones.clear();

    QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection('milestones')
        .where('year', isEqualTo: selectedYear)
        .get();

    for (var doc in snapshot.docs) {
      final milestoneData = doc.data() as Map<String, dynamic>;
      final criteria = milestoneData['criteria'] ?? 'General';

      if (!categorizedMilestones.containsKey(criteria)) {
        categorizedMilestones[criteria] = [];
      }

      categorizedMilestones[criteria]!.add({
        'id': doc.id,
        ...milestoneData,
      });
    }
    setState(() {});
  }

  Future<void> deleteMilestone(String id) async {
    try {
      print('Attempting to delete milestone with ID: $id');

      DocumentReference milestoneRef =
          FirebaseFirestore.instance.collection('milestones').doc(id);

      QuerySnapshot childDocsSnapshot =
          await FirebaseFirestore.instance.collection('child').get();

      for (var doc in childDocsSnapshot.docs) {
        var childData = doc.data() as Map<String, dynamic>?;
        if (childData == null || !childData.containsKey('milestones')) continue;

        List<dynamic> currentMilestones = childData['milestones'];
        List<Map<String, dynamic>> updatedMilestones =
            currentMilestones.cast<Map<String, dynamic>>().where((milestone) {
          return milestone['milestoneId'] != id;
        }).toList();

        if (updatedMilestones.length != currentMilestones.length) {
          await doc.reference.update({'milestones': updatedMilestones});
        }
      }

      await milestoneRef.delete();
      await fetchMilestones();
    } catch (e) {
      print('Error deleting milestone: $e');
    }
  }

  Future<void> editMilestone(
      String id, String currentTitle, String currentDescription) async {
    final TextEditingController titleController =
        TextEditingController(text: currentTitle);
    final TextEditingController descriptionController =
        TextEditingController(text: currentDescription);

    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Edit Milestone'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                decoration: const InputDecoration(labelText: 'Title'),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: descriptionController,
                decoration: const InputDecoration(labelText: 'Description'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                final newTitle = titleController.text;
                final newDescription = descriptionController.text;

                await FirebaseFirestore.instance
                    .collection('milestones')
                    .doc(id)
                    .update({
                  'title': newTitle,
                  'description': newDescription,
                });

                Navigator.of(context).pop();
                await fetchMilestones();
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('View Milestones'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Select Year:', style: TextStyle(fontSize: 16)),
                DropdownButton<String>(
                  value: selectedYear,
                  items: years.map((String year) {
                    return DropdownMenuItem<String>(
                      value: year,
                      child: Text(year),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      setState(() {
                        selectedYear = newValue;
                        fetchMilestones();
                      });
                    }
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: categorizedMilestones.entries.map((entry) {
                  final criteria = entry.key;
                  final milestones = entry.value;

                  return ExpansionTile(
                    title: Text(criteria,
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    children: milestones.map((milestone) {
                      return Card(
                        margin: const EdgeInsets.symmetric(vertical: 8.0),
                        child: ListTile(
                          title: Text(milestone['title'] ?? 'No Title'),
                          subtitle: Text(
                              '${milestone['description'] ?? 'No Description'}\nLevel: ${milestone['milestoneLevel'] ?? 'N/A'}'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit),
                                onPressed: () {
                                  editMilestone(
                                    milestone['id'],
                                    milestone['title'] ?? '',
                                    milestone['description'] ?? '',
                                  );
                                },
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete),
                                onPressed: () {
                                  showDialog(
                                    context: context,
                                    builder: (context) {
                                      return AlertDialog(
                                        title: const Text('Confirm Deletion'),
                                        content: const Text(
                                            'Are you sure you want to delete this milestone?'),
                                        actions: [
                                          TextButton(
                                            onPressed: () =>
                                                Navigator.of(context).pop(),
                                            child: const Text('Cancel'),
                                          ),
                                          TextButton(
                                            onPressed: () {
                                              deleteMilestone(milestone['id']);
                                              Navigator.of(context).pop();
                                            },
                                            child: const Text('Delete'),
                                          ),
                                        ],
                                      );
                                    },
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
