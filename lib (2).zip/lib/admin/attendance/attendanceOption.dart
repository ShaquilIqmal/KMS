import 'package:flutter/material.dart';
import 'package:kms2/admin/attendance/attendanceByWeek.dart';
import 'package:kms2/admin/attendance/attendanceManagementAdmin.dart';

class AttendanceOption extends StatelessWidget {
  const AttendanceOption({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Attendance Options'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                // Navigate to Individual Attendance page
                print('Individual Attendance clicked');
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const AttendanceManagementAdminPage(),
                  ),
                );
              },
              child: const Text('Individual Attendance'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Navigate to By Week Attendance page
                print('By Week Attendance clicked');
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const AttendanceByWeekPage(),
                  ),
                );
              },
              child: const Text('By Week Attendance'),
            ),
          ],
        ),
      ),
    );
  }
}
