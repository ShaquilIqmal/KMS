import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AttendanceChildDetailPage extends StatefulWidget {
  final String childID;
  final String yearID;

  const AttendanceChildDetailPage({
    Key? key,
    required this.childID,
    required this.yearID,
  }) : super(key: key);

  @override
  State<AttendanceChildDetailPage> createState() =>
      _AttendanceChildDetailPageState();
}

class _AttendanceChildDetailPageState extends State<AttendanceChildDetailPage> {
  final CollectionReference attendanceCollection =
      FirebaseFirestore.instance.collection('attendance');

  List<Map<String, dynamic>> attendanceRecords = [];
  String childName = 'Loading...';
  String profileImage = '';

  @override
  void initState() {
    super.initState();
    fetchChildDetails();
    checkAttendanceCollection();
  }

  Future<void> fetchChildDetails() async {
    childName = await fetchChildName(widget.childID);
    profileImage = await fetchChildProfileImage(widget.childID);
    setState(() {}); // Refresh UI after fetching details
  }

  Future<void> checkAttendanceCollection() async {
    try {
      QuerySnapshot snapshot = await attendanceCollection.get();
      for (var doc in snapshot.docs) {
        var data = doc.data() as Map<String, dynamic>;

        // Check attendanceHistory for the specific childID
        for (var history in data['attendanceHistory']) {
          if (history['childID'] == widget.childID) {
            for (var record in history['records']) {
              attendanceRecords.add({
                'date': record['date'],
                'status': record['status'],
                'docId': doc.id, // Store document ID for updates
                'historyId':
                    history['childID'] // To identify the correct history
              });
            }
          }
        }
      }
      setState(() {}); // Refresh the UI after fetching data
    } catch (e) {
      print('Error fetching attendance collection: $e');
    }
  }

  Future<void> updateStatus(
      String date, String newStatus, String docId, String historyId) async {
    try {
      // Get the reference to the document
      DocumentReference docRef = attendanceCollection.doc(docId);

      // Fetch the current data
      DocumentSnapshot snapshot = await docRef.get();
      var data = snapshot.data() as Map<String, dynamic>;

      // Locate the specific history entry
      Map<String, dynamic>? targetHistory;
      for (var history in data['attendanceHistory']) {
        if (history['childID'] == historyId) {
          targetHistory = history;
          break;
        }
      }

      // Update the status in the records
      if (targetHistory != null) {
        for (var record in targetHistory['records']) {
          if (record['date'] == date) {
            // Update the status
            record['status'] = newStatus;
            break;
          }
        }

        // Update daysPresent based on the new status
        var attendanceRecord = data['attendanceRecord']
            .firstWhere((rec) => rec['childID'] == historyId);

        // Count the number of "present" statuses
        int presentCount = 0;
        for (var record in targetHistory['records']) {
          if (record['status'] == 'present') {
            presentCount++;
          }
        }

        // Update daysPresent
        attendanceRecord['daysPresent'] = presentCount;

        // Update attendancePercentage
        attendanceRecord['attendancePercentage'] =
            (attendanceRecord['daysPresent'] / attendanceRecord['totalDays']) *
                100;

        // Save the updated data back to Firestore
        await docRef.update(data);

        // Update the local attendanceRecords to reflect the new status
        for (var record in attendanceRecords) {
          if (record['date'] == date && record['docId'] == docId) {
            record['status'] = newStatus; // Update the local record
            break;
          }
        }
      }

      // Refresh the local state to reflect the change
      setState(() {});
    } catch (e) {
      print('Error updating status: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Attendance Details for Child ID: ${widget.childID}'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back), // Back arrow icon
          onPressed: () {
            Navigator.pop(
                context, true); // Pass true to indicate changes were made
          },
        ),
      ),
      body: Column(
        children: [
          // Display child's name and profile image
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundImage: profileImage.isNotEmpty
                      ? NetworkImage(profileImage)
                      : null,
                  child: profileImage.isEmpty
                      ? const Icon(Icons.person, size: 30, color: Colors.grey)
                      : null,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    childName,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
          attendanceRecords.isEmpty
              ? Center(
                  child:
                      CircularProgressIndicator()) // Show loading indicator while fetching data
              : Expanded(
                  child: ListView.builder(
                    itemCount: attendanceRecords.length,
                    itemBuilder: (context, index) {
                      final record = attendanceRecords[index];
                      return ListTile(
                        title: Text('Date: ${record['date']}'),
                        subtitle: Row(
                          children: [
                            Text('Status: ${record['status']}'),
                            SizedBox(width: 10),
                            DropdownButton<String>(
                              value: record['status'],
                              onChanged: (String? newValue) {
                                if (newValue != null) {
                                  updateStatus(record['date'], newValue,
                                      record['docId'], record['historyId']);
                                }
                              },
                              items: <String>[
                                'present',
                                'absent'
                              ].map<DropdownMenuItem<String>>((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
        ],
      ),
    );
  }

  // Fetch child's name from Firestore using childID
  Future<String> fetchChildName(String childID) async {
    DocumentSnapshot childDoc =
        await FirebaseFirestore.instance.collection('child').doc(childID).get();
    return childDoc.exists
        ? childDoc['SectionA']['nameC'] as String
        : 'Unknown';
  }

  // Fetch child's profile image from Firestore using childID
  Future<String> fetchChildProfileImage(String childID) async {
    DocumentSnapshot childDoc =
        await FirebaseFirestore.instance.collection('child').doc(childID).get();
    if (childDoc.exists) {
      final data = childDoc.data() as Map<String, dynamic>?;
      if (data != null && data.containsKey('profileImage')) {
        return data['profileImage'] as String;
      }
    }
    return ''; // Return an empty string if no image exists or document does not exist
  }
}
