// ignore_for_file: library_private_types_in_public_api, unused_local_variable, prefer_const_constructors, deprecated_member_use, sort_child_properties_last, unnecessary_this, avoid_print

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:kms2/service/database_service.dart';
import 'package:kms2/teacher/attendance/attendanceEdit.dart';

class AttendanceByWeekPage extends StatefulWidget {
  const AttendanceByWeekPage({Key? key}) : super(key: key);

  @override
  _AttendanceByWeekPageState createState() => _AttendanceByWeekPageState();
}

class _AttendanceByWeekPageState extends State<AttendanceByWeekPage> {
  DateTime startOfWeek;
  String? selectedYear = 'Year 4';
  List<Map<String, dynamic>> attendanceDetails = [];
  DateTime? selectedDate;
  final DatabaseService dbService = DatabaseService();
  List<double> attendanceRatios = []; // To store attendance ratios

  _AttendanceByWeekPageState()
      : startOfWeek =
            DateTime.now().subtract(Duration(days: DateTime.now().weekday - 1));

  @override
  void initState() {
    super.initState();
    selectedDate = DateTime.now(); // Set the default selected date to today
    fetchAttendance(selectedDate!); // Fetch attendance for today
    checkAttendance();
  }

  Future<void> checkAttendance() async {
    await dbService.checkAttendanceCollection();
  }

  Future<void> fetchAttendance(DateTime date) async {
    String yearDocumentId = selectedYear == 'Year 4'
        ? 'Year 4'
        : selectedYear == 'Year 5'
            ? 'Year 5'
            : 'Year 6';

    DocumentSnapshot snapshot = await FirebaseFirestore.instance
        .collection('attendance')
        .doc(yearDocumentId)
        .get();

    if (snapshot.exists) {
      List<dynamic> attendanceHistory = snapshot['attendanceHistory'];
      List<Map<String, dynamic>> details = [];
      String formattedSelectedDate = DateFormat('yyyy-MM-dd').format(date);
      attendanceRatios.clear(); // Clear previous ratios

      for (var i = 0; i < 5; i++) {
        // Check past 5 days
        DateTime checkDate = startOfWeek.add(Duration(days: i));
        int totalChildren = 0;
        int presentChildren = 0;

        for (var record in attendanceHistory) {
          String childID = record['childID'];

          for (var childRecord in record['records']) {
            String recordDate = childRecord['date'];

            if (recordDate == DateFormat('yyyy-MM-dd').format(checkDate)) {
              totalChildren++;
              if (childRecord['status'] == 'present') {
                presentChildren++;
              }
            }
          }
        }

        // Calculate the ratio and add it to the list
        double ratio =
            totalChildren > 0 ? presentChildren / totalChildren : 0.0;
        attendanceRatios.add(ratio);
      }

      // Now fetch details for the selected date
      for (var record in attendanceHistory) {
        String childID = record['childID'];

        for (var childRecord in record['records']) {
          String recordDate = childRecord['date'];

          if (recordDate == formattedSelectedDate) {
            var childInfo = await _getChildInfo(childID);
            details.add({
              'childName': childInfo['name'],
              'profileImage': childInfo['profileImage'],
              'arrivedAt': childRecord['arrivedAt'] != null
                  ? DateFormat('HH:mm').format(
                      childRecord['arrivedAt'].toDate().add(Duration(hours: 8)))
                  : 'N/A',
              'returnAt': childRecord['returnAt'] != null
                  ? DateFormat('HH:mm').format(
                      childRecord['returnAt'].toDate().add(Duration(hours: 8)))
                  : 'N/A',
              'status': childRecord['status'],
            });
          }
        }
      }

      setState(() {
        attendanceDetails = details;
      });
    } else {
      print('No document found for year: $yearDocumentId');
    }
  }

  Future<Map<String, String>> _getChildInfo(String childID) async {
    DocumentSnapshot childSnapshot =
        await FirebaseFirestore.instance.collection('child').doc(childID).get();

    if (childSnapshot.exists) {
      return {
        'name': childSnapshot['SectionA']['nameC'] ?? 'Unknown',
        'profileImage': childSnapshot['profileImage'] ?? '',
      };
    } else {
      return {
        'name': 'Unknown',
        'profileImage': '',
      };
    }
  }

  @override
  Widget build(BuildContext context) {
    DateTime today = DateTime.now();
    DateTime currentWeekStart =
        DateTime.now().subtract(Duration(days: DateTime.now().weekday - 1));

    bool isCurrentWeek = startOfWeek.year == currentWeekStart.year &&
        startOfWeek.month == currentWeekStart.month &&
        startOfWeek.day == currentWeekStart.day;

    return Scaffold(
      appBar: AppBar(
        title: const Text('By Week Attendance'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                DropdownButton<String>(
                  value: selectedYear,
                  items: <String>['Year 4', 'Year 5', 'Year 6']
                      .map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    setState(() {
                      selectedYear = newValue;
                      selectedDate = DateTime.now(); // Set to current date
                      attendanceDetails.clear();
                      attendanceRatios.clear(); // Clear ratios on year change
                      fetchAttendance(
                          selectedDate!); // Fetch attendance for the current date
                    });
                  },
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.chevron_left),
                  onPressed: _navigateToPreviousWeek,
                ),
                IconButton(
                  icon: const Icon(Icons.chevron_right),
                  onPressed: isCurrentWeek ? null : _navigateToNextWeek,
                ),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(5, (index) {
              DateTime date = startOfWeek.add(Duration(days: index));
              String dayInitials = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'][index];
              String formattedDate = DateFormat('MMM dd').format(date);
              double ratio = attendanceRatios.length > index
                  ? attendanceRatios[index]
                  : 0.0;
              String ratioText =
                  ratio > 0 ? '${(ratio * 100).toStringAsFixed(0)}%' : '0%';

              bool isSelectedDate = selectedDate?.isSameDay(date) ?? false;

              return SizedBox(
                width: 70,
                height: 100, // Increased height
                child: ElevatedButton(
                  onPressed: () {
                    setState(() {
                      selectedDate = date;
                    });
                    fetchAttendance(date);
                  },
                  style: ElevatedButton.styleFrom(
                    primary: isSelectedDate
                        ? Colors.blue[200]
                        : null, // Highlight if selected
                    side: BorderSide(
                        color: isSelectedDate ? Colors.blue : Colors.grey),
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                    ),
                    padding: EdgeInsets.zero,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        dayInitials,
                        style: const TextStyle(fontSize: 12),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        formattedDate,
                        style: const TextStyle(fontSize: 12),
                        textAlign: TextAlign.center,
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        ratioText, // Display attendance ratio
                        style: const TextStyle(fontSize: 12),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: ListView.builder(
              itemCount: attendanceDetails.length,
              itemBuilder: (context, index) {
                final attendance = attendanceDetails[index];
                return Container(
                  margin: const EdgeInsets.symmetric(
                      vertical: 4.0, horizontal: 8.0),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundImage: attendance['profileImage'] != ''
                          ? NetworkImage(attendance['profileImage'])
                          : null,
                      child: attendance['profileImage'] == ''
                          ? Icon(Icons.person)
                          : null,
                    ),
                    title: Text('Child Name: ${attendance['childName']}'),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Arrived At: ${attendance['arrivedAt']}'),
                        Text('Return At: ${attendance['returnAt']}'),
                        const SizedBox(
                            height: 4), // Add some space before the status
                        Text(
                          'Status: ${attendance['status']}',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: attendance['status'] == 'present'
                                ? Colors.green
                                : Colors.red,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          if (selectedDate != null) {
            String formattedDate =
                DateFormat('yyyy-MM-dd').format(selectedDate!);
            Navigator.of(context).push(MaterialPageRoute(
              builder: (context) => AttendanceEditPage(
                selectedClass: selectedYear!,
                selectedDate: formattedDate,
              ),
            ));
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Please select a date first.')),
            );
          }
        },
        child: const Icon(Icons.edit),
        tooltip: 'Edit',
      ),
    );
  }

  void _navigateToPreviousWeek() {
    setState(() {
      startOfWeek = startOfWeek.subtract(Duration(days: 7));
    });
    fetchAttendance(selectedDate!); // Fetch attendance for the updated week
  }

  void _navigateToNextWeek() {
    setState(() {
      startOfWeek = startOfWeek.add(Duration(days: 7));
    });
    fetchAttendance(selectedDate!); // Fetch attendance for the updated week
  }
}

extension DateTimeComparison on DateTime {
  bool isSameDay(DateTime other) {
    return this.year == other.year &&
        this.month == other.month &&
        this.day == other.day;
  }
}
