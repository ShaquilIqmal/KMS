import 'package:flutter/material.dart';
import 'package:kms2/admin/viewTeachers/viewTeacher.dart';
import 'package:kms2/service/database_service.dart'; // Import the new file

class AddTeacherPage extends StatefulWidget {
  const AddTeacherPage({Key? key}) : super(key: key);

  @override
  _AddTeacherPageState createState() => _AddTeacherPageState();
}

class _AddTeacherPageState extends State<AddTeacherPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController dateOfBirthController = TextEditingController();
  final TextEditingController genderController = TextEditingController();
  final TextEditingController phoneNumberController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController homeAddressController = TextEditingController();
  final TextEditingController positionController = TextEditingController();
  final TextEditingController joiningDateController = TextEditingController();
  final TextEditingController employmentStatusController =
      TextEditingController();
  final TextEditingController salaryController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  final DatabaseService _databaseService = DatabaseService();

  // List to hold selected classes
  List<String> selectedClasses = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Teacher'),
        backgroundColor: Colors.blue[100],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: _buildFormContent(),
      ),
    );
  }

  void _showSnackbar(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  void _submitData() async {
    if (selectedClasses.isEmpty) {
      _showSnackbar('Please select at least one class.');
      return;
    }
    if (_formKey.currentState?.validate() ?? false) {
      try {
        await _databaseService.addTeacher({
          'name': nameController.text,
          'dateOfBirth': dateOfBirthController.text,
          'gender': genderController.text,
          'contactInfo': {
            'phoneNumber': phoneNumberController.text,
            'email': emailController.text,
            'homeAddress': homeAddressController.text,
          },
          'employmentInfo': {
            'position': positionController.text,
            'joiningDate': joiningDateController.text,
            'employmentStatus': employmentStatusController.text,
            'salary': salaryController.text,
          },
          'assignedClasses': selectedClasses, // Include selected classes
          'password': passwordController.text,
          'isTeacher': true,
        });
        _showSuccessDialog();
      } catch (e) {
        _showSnackbar('Failed to add teacher: $e');
      }
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Teacher Added'),
          content: const Text('The teacher has been successfully added.'),
          actions: <Widget>[
            TextButton(
              child: const Text('OK'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          ViewTeacherPage()), // navigate to view page
                );
              },
            ),
          ],
        );
      },
    );
  }

  Widget _buildFormContent() {
    return Form(
      key: _formKey,
      child: ListView(
        children: <Widget>[
          const Text(
            'Add Teacher',
            style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: nameController,
            labelText: 'Name',
            hintText: 'Name',
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter the teacher\'s name'
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: dateOfBirthController,
            labelText: 'Date of Birth',
            hintText: 'YYYY-MM-DD',
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter the date of birth';
              }
              return null;
            },
          ),
          const SizedBox(height: 16.0),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Text('Gender', style: TextStyle(fontSize: 16.0)),
              Row(
                children: <Widget>[
                  Radio<String>(
                    value: 'Male',
                    groupValue: genderController.text,
                    onChanged: (value) {
                      setState(() {
                        genderController.text = value!;
                      });
                    },
                  ),
                  const Text('Male'),
                  Radio<String>(
                    value: 'Female',
                    groupValue: genderController.text,
                    onChanged: (value) {
                      setState(() {
                        genderController.text = value!;
                      });
                    },
                  ),
                  const Text('Female'),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: phoneNumberController,
            labelText: 'Phone Number',
            hintText: 'Phone Number',
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter the phone number'
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: emailController,
            labelText: 'Email',
            hintText: 'Email',
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter the email';
              }
              if (!value.contains('@')) {
                return 'Please enter a valid email';
              }
              return null;
            },
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: homeAddressController,
            labelText: 'Home Address',
            hintText: 'Home Address',
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter the home address'
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: positionController,
            labelText: 'Position',
            hintText: 'Position',
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter the position'
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: joiningDateController,
            labelText: 'Joining Date',
            hintText: 'YYYY-MM-DD',
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter the joining date';
              }
              return null;
            },
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: employmentStatusController,
            labelText: 'Employment Status',
            hintText: 'Employment Status',
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter the employment status'
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: salaryController,
            labelText: 'Salary',
            hintText: 'Salary',
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter the salary'
                : null,
          ),
          const SizedBox(height: 16.0),
          _buildTextFormField(
            controller: passwordController,
            labelText: 'Password',
            hintText: 'Password',
            obscureText: true,
            validator: (value) => value == null || value.isEmpty
                ? 'Please enter the password'
                : null,
          ),
          const SizedBox(height: 16.0),

          // Checkbox for Assign Classes
          const Padding(
            padding: EdgeInsets.only(top: 16.0),
            child: Text('Assign Classes', style: TextStyle(fontSize: 16.0)),
          ),
          _buildCheckboxListTile('Year 4'),
          _buildCheckboxListTile('Year 5'),
          _buildCheckboxListTile('Year 6'),
          _buildCheckboxListTile('No Data'),

          const SizedBox(height: 16.0),
          ElevatedButton(
            onPressed: _submitData,
            child: const Text('Add Teacher'),
          ),
        ],
      ),
    );
  }

  Widget _buildTextFormField({
    required TextEditingController controller,
    required String labelText,
    required String hintText,
    bool obscureText = false,
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: labelText,
        hintText: hintText,
        border: const OutlineInputBorder(),
      ),
      obscureText: obscureText,
      keyboardType: keyboardType,
      validator: validator,
    );
  }

  Widget _buildCheckboxListTile(String className) {
    return CheckboxListTile(
      title: Text(className),
      value: selectedClasses.contains(className),
      onChanged: (bool? value) {
        setState(() {
          if (value == true) {
            selectedClasses.add(className);
          } else {
            selectedClasses.remove(className);
          }
        });
      },
    );
  }
}
