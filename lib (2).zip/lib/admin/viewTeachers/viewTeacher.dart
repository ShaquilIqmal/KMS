import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:kms2/admin/viewTeachers/addTeacher.dart';
import 'package:kms2/service/cloudinary_service.dart'; // Ensure this import matches your project structure
import 'package:kms2/service/database_service.dart';
import 'package:kms2/service/zmodel/teachermodel.dart';
import 'package:provider/provider.dart';

class ViewTeacherPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('View Teachers'),
        backgroundColor: Colors.blue[100],
      ),
      body: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const Text(
                'Add Teachers',
                style: TextStyle(fontSize: 18, color: Colors.blue),
              ),
              IconButton(
                iconSize: 30,
                icon: const Icon(Icons.add, color: Colors.green),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const AddTeacherPage(),
                    ),
                  );
                },
              ),
            ],
          ),
          Expanded(
            child: StreamProvider<List<Teacher>>.value(
              value: DatabaseService().getTeachers(),
              initialData: const [],
              child: TeacherList(),
            ),
          ),
        ],
      ),
    );
  }
}

class TeacherList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var teachers = Provider.of<List<Teacher>>(context);

    return teachers.isEmpty
        ? const Center(
            child: Text('No teachers available'),
          )
        : ListView.builder(
            itemCount: teachers.length,
            itemBuilder: (context, index) {
              var teacher = teachers[index];
              return ListTile(
                leading: CircleAvatar(
                  radius: 25, // Adjust the radius as needed
                  backgroundImage: teacher.profileImage != null &&
                          teacher.profileImage!.isNotEmpty
                      ? NetworkImage(teacher.profileImage!)
                      : null,
                  child: teacher.profileImage == null ||
                          teacher.profileImage!.isEmpty
                      ? const Icon(Icons.person,
                          size: 30,
                          color: Colors.grey) // Default icon if no image
                      : null,
                ),
                title: Text(teacher.name),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('ID Number: ${teacher.idNumber}'),
                    Text('DOB: ${teacher.dateOfBirth}'),
                    Text('Gender: ${teacher.gender}'),
                    Text('Position: ${teacher.employmentInfo.position}'),
                    Text('Classes: ${teacher.assignedClasses.join(', ')}'),
                  ],
                ),
                trailing: _buildActionButtons(context, teacher),
              );
            },
          );
  }
}

Widget _buildActionButtons(BuildContext context, Teacher teacher) {
  return Row(
    mainAxisSize: MainAxisSize.min,
    children: <Widget>[
      IconButton(
        icon: const Icon(Icons.edit),
        onPressed: () {
          _showEditDialog(context, teacher);
        },
      ),
      IconButton(
        icon: const Icon(Icons.delete),
        onPressed: () {
          _showDeleteDialog(context, teacher);
        },
      ),
    ],
  );
}

void _showEditDialog(BuildContext context, Teacher teacher) {
  final TextEditingController nameController =
      TextEditingController(text: teacher.name);
  final TextEditingController dateOfBirthController =
      TextEditingController(text: teacher.dateOfBirth);
  final TextEditingController genderController =
      TextEditingController(text: teacher.gender);
  final TextEditingController idNumberController =
      TextEditingController(text: teacher.idNumber);
  final TextEditingController phoneNumberController =
      TextEditingController(text: teacher.contactInfo.phoneNumber);
  final TextEditingController emailController =
      TextEditingController(text: teacher.contactInfo.email);
  final TextEditingController homeAddressController =
      TextEditingController(text: teacher.contactInfo.homeAddress);
  final TextEditingController positionController =
      TextEditingController(text: teacher.employmentInfo.position);
  final TextEditingController joiningDateController =
      TextEditingController(text: teacher.employmentInfo.joiningDate);
  final TextEditingController employmentStatusController =
      TextEditingController(text: teacher.employmentInfo.employmentStatus);
  final TextEditingController salaryController =
      TextEditingController(text: teacher.employmentInfo.salary);

  List<String> selectedClasses = List.from(teacher.assignedClasses);
  String? newProfileImageUrl; // Variable to hold the new image URL

  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text('Edit Teacher'),
        content: StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  GestureDetector(
                    onTap: () async {
                      final imagePicker = ImagePicker();
                      final pickedFile = await imagePicker.pickImage(
                          source: ImageSource.gallery);
                      if (pickedFile != null) {
                        // Upload the image to Cloudinary
                        final cloudinaryService = CloudinaryService();
                        newProfileImageUrl = await cloudinaryService
                            .uploadImage(pickedFile.path);
                        setState(
                            () {}); // Refresh the dialog to show the new image
                      }
                    },
                    child: CircleAvatar(
                      radius: 50,
                      backgroundImage: newProfileImageUrl != null
                          ? NetworkImage(newProfileImageUrl!)
                          : teacher.profileImage != null &&
                                  teacher.profileImage!.isNotEmpty
                              ? NetworkImage(teacher.profileImage!)
                              : null,
                      child: newProfileImageUrl == null &&
                              (teacher.profileImage == null ||
                                  teacher.profileImage!.isEmpty)
                          ? const Icon(Icons.camera_alt,
                              size: 50,
                              color:
                                  Colors.grey) // Show camera icon if no image
                          : null,
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                      controller: nameController,
                      decoration: const InputDecoration(labelText: 'Name')),
                  TextField(
                      controller: dateOfBirthController,
                      decoration:
                          const InputDecoration(labelText: 'Date of Birth')),
                  TextField(
                      controller: genderController,
                      decoration: const InputDecoration(labelText: 'Gender')),
                  TextField(
                      controller: idNumberController,
                      decoration:
                          const InputDecoration(labelText: 'ID Number')),
                  TextField(
                      controller: phoneNumberController,
                      decoration:
                          const InputDecoration(labelText: 'Phone Number')),
                  TextField(
                      controller: emailController,
                      decoration: const InputDecoration(labelText: 'Email')),
                  TextField(
                      controller: homeAddressController,
                      decoration:
                          const InputDecoration(labelText: 'Home Address')),
                  TextField(
                      controller: positionController,
                      decoration: const InputDecoration(labelText: 'Position')),
                  TextField(
                      controller: joiningDateController,
                      decoration:
                          const InputDecoration(labelText: 'Joining Date')),
                  TextField(
                      controller: employmentStatusController,
                      decoration: const InputDecoration(
                          labelText: 'Employment Status')),
                  TextField(
                      controller: salaryController,
                      decoration: const InputDecoration(labelText: 'Salary')),
                  const Padding(
                    padding: EdgeInsets.only(top: 16.0),
                    child: Text('Assign Classes',
                        style: TextStyle(fontSize: 16.0)),
                  ),
                  _buildCheckboxListTile('Year 4', selectedClasses, setState),
                  _buildCheckboxListTile('Year 5', selectedClasses, setState),
                  _buildCheckboxListTile('Year 6', selectedClasses, setState),
                ],
              ),
            );
          },
        ),
        actions: <Widget>[
          TextButton(
            child: const Text('Cancel'),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          TextButton(
            child: const Text('Save'),
            onPressed: () async {
              try {
                await DatabaseService().editTeacher(
                  teacher.id,
                  {
                    'name': nameController.text,
                    'dateOfBirth': dateOfBirthController.text,
                    'gender': genderController.text,
                    'idNumber': idNumberController.text,
                    'contactInfo': {
                      'phoneNumber': phoneNumberController.text,
                      'email': emailController.text,
                      'homeAddress': homeAddressController.text,
                    },
                    'employmentInfo': {
                      'position': positionController.text,
                      'joiningDate': joiningDateController.text,
                      'employmentStatus': employmentStatusController.text,
                      'salary': salaryController.text,
                    },
                    'assignedClasses': selectedClasses,
                    'profileImage': newProfileImageUrl ??
                        teacher
                            .profileImage, // Save new image URL or keep old one
                  },
                );
                Navigator.of(context).pop(); // Close the dialog
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Teacher edited successfully')),
                );
              } catch (e) {
                print('Failed to edit teacher: $e');
              }
            },
          ),
        ],
      );
    },
  );
}

void _showDeleteDialog(BuildContext context, Teacher teacher) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text('Delete Teacher'),
        content: Text('Are you sure you want to delete ${teacher.name}?'),
        actions: <Widget>[
          TextButton(
            child: const Text('Cancel'),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          TextButton(
            child: const Text('Delete'),
            onPressed: () async {
              try {
                await DatabaseService().deleteTeacher(teacher
                    .id); // This will delete the teacher and associated entries
                Navigator.of(context).pop(); // Close the dialog
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Teacher deleted successfully')),
                );
              } catch (e) {
                print('Failed to delete teacher: $e');
              }
            },
          ),
        ],
      );
    },
  );
}

// Checkbox List Tile for Assigned Classes
Widget _buildCheckboxListTile(
    String className, List<String> selectedClasses, StateSetter setState) {
  return CheckboxListTile(
    title: Text(className),
    value: selectedClasses.contains(className),
    onChanged: (bool? value) {
      setState(() {
        if (value == true) {
          selectedClasses.add(className);
        } else {
          selectedClasses.remove(className);
        }
      });
    },
  );
}
