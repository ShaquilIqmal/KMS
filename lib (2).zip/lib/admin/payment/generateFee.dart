import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class GenerateFeesPage extends StatefulWidget {
  final String adminDocId;

  const GenerateFeesPage({Key? key, required this.adminDocId})
      : super(key: key);

  @override
  _GenerateFeesPageState createState() => _GenerateFeesPageState();
}

class _GenerateFeesPageState extends State<GenerateFeesPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<DocumentSnapshot> _feesList = [];
  List<String> _selectedFees = [];
  List<DocumentSnapshot> _childrenList = [];
  List<String> _selectedChildren = [];
  String? _selectedYear = 'Year 4'; // Set default year
  bool _selectAll = false;
  bool _isLoadingFees = true;
  bool _isLoadingChildren = false;

  @override
  void initState() {
    super.initState();
    _fetchFees();
    _fetchChildren(_selectedYear!); // Fetch children for Year 4
  }

  Future<void> _fetchFees() async {
    try {
      QuerySnapshot snapshot = await _firestore.collection('fees').get();
      setState(() {
        _feesList = snapshot.docs;
        _isLoadingFees = false;
      });
    } catch (e) {
      _showErrorSnackBar('Error fetching fees: $e');
    }
  }

  Future<void> _fetchChildren(String yearID) async {
    setState(() {
      _isLoadingChildren = true; // Start loading
    });

    try {
      QuerySnapshot snapshot = await _firestore
          .collection('child')
          .where('SectionA.yearID', isEqualTo: yearID)
          .get();

      setState(() {
        _childrenList = snapshot.docs;
        _selectedChildren.clear();
        _selectAll = false;
        _isLoadingChildren = false; // Stop loading
      });
    } catch (e) {
      _showErrorSnackBar('Error fetching children: $e');
      setState(() {
        _isLoadingChildren = false; // Stop loading
      });
    }
  }

  void _toggleSelectAll() {
    setState(() {
      _selectAll = !_selectAll;
      _selectedChildren.clear();
      if (_selectAll) {
        _selectedChildren.addAll(_childrenList.map((child) => child.id));
      }
    });
  }

  Future<void> _generateFeesForSelectedChildren() async {
    DateTime dueDate = DateTime.now().add(Duration(days: 10));
    String formattedDueDate = DateFormat('yyyy-MM-dd').format(dueDate);

    for (var child in _childrenList
        .where((child) => _selectedChildren.contains(child.id))) {
      for (var feeId in _selectedFees) {
        DocumentSnapshot paymentSnapshot = await _firestore
            .collection('child')
            .doc(child.id)
            .collection('payments')
            .doc(feeId)
            .get();

        if (paymentSnapshot.exists) {
          _showErrorSnackBar(
              'Fee ${feeId} already exists for ${child['SectionA']['nameC']}!');
        } else {
          var fee = _feesList.firstWhere((fee) => fee.id == feeId);
          await _firestore
              .collection('child')
              .doc(child.id)
              .collection('payments')
              .doc(feeId)
              .set({
            'feeType': fee['feeType'],
            'amount': fee['amount'],
            'category': fee['category'],
            'dueDate': formattedDueDate,
            'paid': false,
          });
        }
      }
    }

    _showSuccessSnackBar(
        'Fees generated for selected children in $_selectedYear!');
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Generate Fees'),
        backgroundColor: Colors.blue[100],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start, // Align children to the start
            children: [
              // Fees Section
              Text(
                '1. Select Fees:',
                style: Theme.of(context).textTheme.headline6!.copyWith(
                      fontWeight: FontWeight.bold,
                      fontSize: 16, // Smaller font size
                    ),
              ),
              SizedBox(height: 8.0),
              Container(
                padding: const EdgeInsets.all(8.0), // Added padding
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black),
                  borderRadius: BorderRadius.circular(4.0),
                ),
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.3,
                  color: Color.fromARGB(255, 223, 238, 240),
                  child: _isLoadingFees
                      ? Center(child: CircularProgressIndicator())
                      : ListView.builder(
                          itemCount: _feesList.length,
                          itemBuilder: (context, index) {
                            final fee = _feesList[index];
                            return Container(
                              margin: const EdgeInsets.symmetric(vertical: 4.0),
                              decoration: BoxDecoration(
                                border:
                                    Border.all(color: Colors.black, width: 1),
                                borderRadius: BorderRadius.circular(4.0),
                              ),
                              child: CheckboxListTile(
                                title: Text(fee['feeType']),
                                value: _selectedFees.contains(fee.id),
                                onChanged: (bool? selected) {
                                  setState(() {
                                    if (selected == true) {
                                      _selectedFees.add(fee.id);
                                    } else {
                                      _selectedFees.remove(fee.id);
                                    }
                                  });
                                },
                              ),
                            );
                          },
                        ),
                ),
              ),
              SizedBox(height: 20),

              // Year Selection Buttons
              Text(
                '2. Select Year:',
                style: Theme.of(context).textTheme.headline6!.copyWith(
                      fontWeight: FontWeight.bold,
                      fontSize: 16, // Smaller font size
                    ),
              ),
              SizedBox(height: 8.0),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  _buildYearButton('Year 4'),
                  SizedBox(width: 5), // Closer spacing
                  _buildYearButton('Year 5'),
                  SizedBox(width: 5), // Closer spacing
                  _buildYearButton('Year 6'),
                ],
              ),
              SizedBox(height: 20),

              // New Section Title for Children
              Text(
                '3. Select Children:',
                style: Theme.of(context).textTheme.headline6!.copyWith(
                      fontWeight: FontWeight.bold,
                      fontSize: 16, // Smaller font size
                    ),
              ),
              SizedBox(height: 10), // Spacing for visual clarity

              // Container for Children Section
              Center(
                // Center the title
                child: Text(
                  'Children in $_selectedYear:',
                  style: Theme.of(context).textTheme.headline6!.copyWith(
                        fontSize: 16, // Smaller font size
                      ),
                ),
              ),
              Container(
                padding: const EdgeInsets.all(8.0), // Added padding
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black),
                  borderRadius: BorderRadius.circular(4.0),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment:
                          MainAxisAlignment.spaceBetween, // Align to the sides
                      children: [
                        Text('Select All'),
                        Checkbox(
                          value: _selectAll,
                          onChanged: (bool? selected) {
                            _toggleSelectAll();
                          },
                        ),
                      ],
                    ),
                    SizedBox(height: 10),
                    if (_isLoadingChildren)
                      Center(child: CircularProgressIndicator())
                    else if (_childrenList.isEmpty)
                      Center(child: Text('No children found for this year.'))
                    else
                      SizedBox(
                        height: 200, // Set a specific height
                        child: ListView.builder(
                          itemCount: _childrenList.length,
                          itemBuilder: (context, index) {
                            final child = _childrenList[index];
                            return Container(
                              margin: const EdgeInsets.symmetric(vertical: 4.0),
                              decoration: BoxDecoration(
                                border:
                                    Border.all(color: Colors.black, width: 1),
                                borderRadius: BorderRadius.circular(4.0),
                              ),
                              child: CheckboxListTile(
                                secondary: CircleAvatar(
                                  backgroundImage:
                                      child['profileImage'] != null &&
                                              child['profileImage'].isNotEmpty
                                          ? NetworkImage(child['profileImage'])
                                          : AssetImage('assets/placeholder.png')
                                              as ImageProvider,
                                  radius: 20,
                                ),
                                title: Text(child['SectionA']['nameC']),
                                value: _selectedChildren.contains(child.id),
                                onChanged: (bool? selected) {
                                  setState(() {
                                    if (selected == true) {
                                      _selectedChildren.add(child.id);
                                    } else {
                                      _selectedChildren.remove(child.id);
                                    }
                                  });
                                },
                              ),
                            );
                          },
                        ),
                      ),
                  ],
                ),
              ),
              SizedBox(height: 20),

              // Generate Fees Button
              ElevatedButton(
                onPressed: _generateFeesForSelectedChildren,
                child: const Text('Add Fees to Selected Children'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildYearButton(String year) {
    bool isSelected = _selectedYear == year;
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.zero, // Pointy corners
          side: BorderSide(color: isSelected ? Colors.blue : Colors.grey),
        ),
        backgroundColor: isSelected
            ? Colors.blue.shade50
            : Colors.white, // Change background for selected
      ),
      onPressed: () {
        _fetchChildren(year);
        setState(() {
          _selectedYear = year;
        });
      },
      child: Text(year),
    );
  }
}
