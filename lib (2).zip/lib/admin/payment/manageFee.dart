// ignore_for_file: file_names, use_super_parameters, library_private_types_in_public_api

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ManageFeesPage extends StatefulWidget {
  final String adminDocId;

  const ManageFeesPage({Key? key, required this.adminDocId}) : super(key: key);

  @override
  _ManageFeesPageState createState() => _ManageFeesPageState();
}

class _ManageFeesPageState extends State<ManageFeesPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final TextEditingController _feeTypeController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();

  String? _selectedCategory;
  final List<String> _categories = [
    'Additional Items',
    'MonthlyFees',
    'New Registration',
  ];

  List<DocumentSnapshot> _feesList = [];
  List<DocumentSnapshot> _feeHistoryList = []; // To store deleted fees
  String? _editingFeeId; // To store the ID of the fee being edited

  @override
  void initState() {
    super.initState();
    _fetchFees();
    _fetchFeeHistory(); // Fetch fee history
  }

  Future<void> _fetchFees() async {
    QuerySnapshot snapshot = await _firestore.collection('fees').get();
    setState(() {
      _feesList = snapshot.docs;
    });
  }

  Future<void> _fetchFeeHistory() async {
    QuerySnapshot snapshot = await _firestore.collection('feeHistory').get();
    setState(() {
      _feeHistoryList = snapshot.docs; // Store deleted fees
    });
  }

  Future<void> _addOrUpdateFee() async {
    final feeType = _feeTypeController.text;
    final amount = double.tryParse(_amountController.text);

    if (feeType.isNotEmpty && amount != null && _selectedCategory != null) {
      // Generate initials from the feeType
      String initials =
          feeType.split(' ').map((word) => word[0].toUpperCase()).join('');

      if (_editingFeeId == null) {
        // Adding a new fee
        DocumentReference newDocRef = _firestore.collection('fees').doc();
        String feeId = '${initials}_${newDocRef.id}';

        await newDocRef.set({
          'feeId': feeId,
          'feeType': feeType,
          'amount': amount,
          'category': _selectedCategory,
          'dueDate': Timestamp.now(),
        });
      } else {
        // Updating an existing fee
        await _firestore.collection('fees').doc(_editingFeeId).update({
          'feeType': feeType,
          'amount': amount,
          'category': _selectedCategory,
        });
        _editingFeeId = null; // Reset the editing fee ID after update
      }

      _feeTypeController.clear();
      _amountController.clear();
      setState(() {
        _selectedCategory = null;
      });
      await _fetchFees();
      await _fetchFeeHistory(); // Refresh fee history
    }
  }

  Future<void> _deleteFee(String feeId) async {
    DocumentSnapshot feeDoc =
        await _firestore.collection('fees').doc(feeId).get();

    // Move the fee to feeHistory
    await _firestore
        .collection('feeHistory')
        .doc(feeId)
        .set(feeDoc.data() as Map<String, dynamic>);

    // Delete the fee from the fees collection
    await _firestore.collection('fees').doc(feeId).delete();

    await _fetchFees();
    await _fetchFeeHistory(); // Refresh fee history
  }

  void _editFee(DocumentSnapshot fee) {
    final data = fee.data() as Map<String, dynamic>;

    _feeTypeController.text = data['feeType'];
    _amountController.text = data['amount'].toString();
    _selectedCategory = data['category'];

    setState(() {
      _editingFeeId = fee.id; // Set the ID of the fee being edited
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Manage Fees'),
        backgroundColor: Colors.blue[100],
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              _fetchFees();
              _fetchFeeHistory(); // Refresh both lists
            },
            tooltip: 'Update Existing Fees',
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildFeeInputForm(),
              const SizedBox(height: 16.0),
              _buildFeesList(),
              const SizedBox(height: 16.0),
              _buildFeeHistoryList(), // Display fee history
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFeeInputForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: _feeTypeController,
          decoration: const InputDecoration(labelText: 'Fee Type'),
        ),
        TextField(
          controller: _amountController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Amount'),
        ),
        const SizedBox(height: 16.0),
        DropdownButtonFormField<String>(
          value: _selectedCategory,
          decoration: const InputDecoration(labelText: 'Select Category'),
          items: _categories.map((String category) {
            return DropdownMenuItem<String>(
              value: category,
              child: Text(category),
            );
          }).toList(),
          onChanged: (String? newValue) {
            setState(() {
              _selectedCategory = newValue;
            });
          },
          isExpanded: true,
        ),
        const SizedBox(height: 16.0),
        ElevatedButton(
          onPressed: _addOrUpdateFee,
          child: Text(_editingFeeId == null ? 'Add Fee' : 'Update Fee'),
        ),
      ],
    );
  }

  Widget _buildFeesList() {
    return Container(
      padding: const EdgeInsets.all(8.0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Fee List (Current)',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8.0), // Space between title and list
          ListView.builder(
            shrinkWrap: true, // Important to make it scrollable
            physics:
                const NeverScrollableScrollPhysics(), // Disable scrolling for this list
            itemCount: _feesList.length,
            itemBuilder: (context, index) {
              final fee = _feesList[index];
              final data = fee.data() as Map<String, dynamic>?;

              String category = (data != null && data.containsKey('category'))
                  ? data['category']
                  : 'N/A';

              return Card(
                margin: const EdgeInsets.symmetric(vertical: 8.0),
                child: ListTile(
                  title: Text(data?['feeType'] ?? 'N/A'),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Amount: \$${data?['amount'] ?? 0}'),
                      Text('Category: $category'),
                    ],
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.blue),
                        onPressed: () => _editFee(fee),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _deleteFee(fee.id),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildFeeHistoryList() {
    return Container(
      padding: const EdgeInsets.all(8.0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Fee List (Deleted)',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8.0), // Space between title and list
          ListView.builder(
            shrinkWrap: true, // Important to make it scrollable
            physics:
                const NeverScrollableScrollPhysics(), // Disable scrolling for this list
            itemCount: _feeHistoryList.length,
            itemBuilder: (context, index) {
              final fee = _feeHistoryList[index];
              final data = fee.data() as Map<String, dynamic>?;

              return Card(
                margin: const EdgeInsets.symmetric(vertical: 8.0),
                child: ListTile(
                  title: Text(data?['feeType'] ?? 'N/A'),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Fee ID: ${data?['feeId'] ?? 'N/A'}'),
                      Text('Amount: \$${data?['amount'] ?? 0}'),
                      Text('Category: ${data?['category'] ?? 'N/A'}'),
                      const SizedBox(
                          height: 4.0), // Space before "Deleted Fees"
                      const Text(
                        'Deleted Fees',
                        style: TextStyle(
                            color: Colors.red,
                            fontSize: 10), // Smaller font size
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
