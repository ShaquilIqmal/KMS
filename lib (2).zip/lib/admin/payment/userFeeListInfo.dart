import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class UserFeeListInfoPage extends StatefulWidget {
  final String userId; // User ID parameter

  const UserFeeListInfoPage({Key? key, required this.userId}) : super(key: key);

  @override
  State<UserFeeListInfoPage> createState() => _UserFeeListInfoPageState();
}

class _UserFeeListInfoPageState extends State<UserFeeListInfoPage> {
  late Future<List<Map<String, dynamic>>> _childDetailsFuture;

  @override
  void initState() {
    super.initState();
    _childDetailsFuture = _fetchChildDetails(widget.userId);
  }

  Future<List<Map<String, dynamic>>> _fetchChildDetails(String userId) async {
    List<Map<String, dynamic>> childDetails = [];

    DocumentSnapshot userDoc =
        await FirebaseFirestore.instance.collection('users').doc(userId).get();
    var data = userDoc.data() as Map<String, dynamic>;
    List<String> childIds = List<String>.from(data['childIds'] ?? []);

    for (String childId in childIds) {
      DocumentSnapshot childDoc = await FirebaseFirestore.instance
          .collection('child')
          .doc(childId)
          .get();
      var childData = childDoc.data() as Map<String, dynamic>;

      String nameC = 'Unknown';
      String yearId = 'Unknown';
      String? profileImage = childData['profileImage']; // Fetch profileImage
      List<Map<String, dynamic>> paymentDetails = [];
      double totalUnpaidAmount = 0.0; // Initialize total unpaid amount

      if (childData.containsKey('SectionA')) {
        var sectionA = childData['SectionA'] as Map<String, dynamic>;
        nameC = sectionA['nameC'] ?? 'Unknown';
        yearId = sectionA['yearID'] ?? 'Unknown';
      }

      QuerySnapshot paymentsSnapshot = await FirebaseFirestore.instance
          .collection('child')
          .doc(childId)
          .collection('payments')
          .get();

      for (var paymentDoc in paymentsSnapshot.docs) {
        var paymentData = paymentDoc.data() as Map<String, dynamic>;
        paymentDetails.add({
          'paymentId': paymentDoc.id,
          'childId': childId,
          'feeType': paymentData['feeType'] ?? 'Unknown',
          'paid': paymentData['paid'] ?? false,
          'amount': paymentData['amount'] ?? 0.0,
        });

        // Calculate total unpaid amount
        if (!paymentData['paid']) {
          totalUnpaidAmount += paymentData['amount'] ?? 0.0;
        }
      }

      paymentDetails.sort((a, b) {
        return (a['paid'] ? 1 : 0).compareTo(b['paid'] ? 1 : 0);
      });

      childDetails.add({
        'nameC': nameC,
        'yearID': yearId,
        'profileImage': profileImage, // Add profileImage to childDetails
        'payments': paymentDetails,
        'totalUnpaidAmount': totalUnpaidAmount, // Add total unpaid amount
      });
    }

    return childDetails;
  }

  void _editPayment(String childId, String paymentId,
      Map<String, dynamic> paymentData) async {
    TextEditingController feeTypeController =
        TextEditingController(text: paymentData['feeType']);
    TextEditingController amountController =
        TextEditingController(text: paymentData['amount'].toString());

    bool isPaid = paymentData['paid'];

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Edit Payment'),
          content: SingleChildScrollView(
            child: StatefulBuilder(
              builder: (context, setState) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: feeTypeController,
                      decoration: InputDecoration(labelText: 'Fee Type'),
                    ),
                    TextField(
                      controller: amountController,
                      decoration: InputDecoration(labelText: 'Amount'),
                      keyboardType: TextInputType.number,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Paid'),
                        Switch(
                          value: isPaid,
                          onChanged: (value) {
                            setState(() {
                              isPaid = value;
                            });
                          },
                        ),
                      ],
                    ),
                  ],
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                await FirebaseFirestore.instance
                    .collection('child')
                    .doc(childId)
                    .collection('payments')
                    .doc(paymentId)
                    .update({
                  'feeType': feeTypeController.text,
                  'amount': double.tryParse(amountController.text) ?? 0.0,
                  'paid': isPaid,
                });

                setState(() {
                  _childDetailsFuture = _fetchChildDetails(widget.userId);
                });

                Navigator.of(context).pop();
              },
              child: Text('Save'),
            ),
          ],
        );
      },
    );
  }

  void _deletePayment(String childId, String paymentId) async {
    bool confirmDelete = await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Delete Payment'),
          content: Text('Are you sure you want to delete this payment?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: Text('Delete'),
            ),
          ],
        );
      },
    );

    if (confirmDelete) {
      await FirebaseFirestore.instance
          .collection('child')
          .doc(childId)
          .collection('payments')
          .doc(paymentId)
          .delete();
      setState(() {
        _childDetailsFuture = _fetchChildDetails(widget.userId);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Fee Details'),
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _childDetailsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          final childDetails = snapshot.data ?? [];

          return ListView.builder(
            itemCount: childDetails.length,
            itemBuilder: (context, index) {
              final child = childDetails[index];
              return Card(
                margin: EdgeInsets.all(10),
                child: ExpansionTile(
                  title: Row(
                    children: [
                      child['profileImage'] != null &&
                              child['profileImage']!.isNotEmpty
                          ? CircleAvatar(
                              backgroundImage:
                                  NetworkImage(child['profileImage']),
                            )
                          : CircleAvatar(
                              child: Icon(Icons.person), // Default user icon
                            ),
                      SizedBox(width: 10), // Space between image and text
                      Text('Child Name: ${child['nameC']}'),
                    ],
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Year ID: ${child['yearID']}'),
                      Text(
                        'Total Unpaid Amount: \$${child['totalUnpaidAmount'].toStringAsFixed(2)}',
                        style: TextStyle(color: Colors.red), // Red text
                      ),
                    ],
                  ),
                  children: child['payments'].map<Widget>((payment) {
                    return ListTile(
                      title: Text('Fee: ${payment['feeType']}'),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('ID: ${payment['paymentId']}'),
                          Text('${payment['paid'] ? 'Paid' : 'Unpaid'}'),
                          Text(
                              'Amount: \$${payment['amount'].toStringAsFixed(2)}'),
                        ],
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(Icons.edit),
                            onPressed: () => _editPayment(payment['childId'],
                                payment['paymentId'], payment),
                          ),
                          IconButton(
                            icon: Icon(Icons.delete),
                            onPressed: () => _deletePayment(
                                payment['childId'], payment['paymentId']),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
