import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class BarChartSample2 extends StatelessWidget {
  final List<double> monthlyIncome;

  BarChartSample2({required this.monthlyIncome});

  @override
  Widget build(BuildContext context) {
    return BarChart(
      BarChartData(
        gridData: FlGridData(show: false),
        titlesData: FlTitlesData(
          show: true,
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 22,
              getTitlesWidget: (value, meta) {
                return Text(
                  _getMonthName(value.toInt()),
                  style: const TextStyle(fontSize: 12, color: Colors.black),
                );
              },
            ),
          ),
          leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        borderData: FlBorderData(show: false),
        barGroups: _buildBarGroups(),
      ),
    );
  }

  List<BarChartGroupData> _buildBarGroups() {
    return List.generate(12, (index) {
      return _buildBar(index + 1, monthlyIncome[index]);
    });
  }

  BarChartGroupData _buildBar(int monthIndex, double value) {
    return BarChartGroupData(
      x: monthIndex,
      barRods: [
        BarChartRodData(
          toY: value,
          color: Colors.blue,
          width: 16.0,
          borderRadius: BorderRadius.zero,
        ),
      ],
    );
  }

  String _getMonthName(int monthIndex) {
    const monthNames = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
    return monthNames[monthIndex - 1]; // Adjust for zero-based index
  }
}
