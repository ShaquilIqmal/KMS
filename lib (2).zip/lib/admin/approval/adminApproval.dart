import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'approvalDetail.dart';

class AdminApprovalPage extends StatelessWidget {
  const AdminApprovalPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pending Approvals'),
        backgroundColor: Colors.blue[100],
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('pending_approvals')
            .snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final pendingApprovals = snapshot.data!.docs;
          return ListView.builder(
            itemCount: pendingApprovals.length,
            itemBuilder: (context, index) {
              final approval = pendingApprovals[index];
              final approvalData = approval.data() as Map<String, dynamic>;
              return ListTile(
                title: Text(approvalData['SectionA']['nameC']),
                subtitle: Text(
                  'Status: ${approvalData['status']}',
                  style: const TextStyle(
                    color: Colors.orange,
                  ),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ApprovalDetailPage(
                        docId: approval.id,
                        data: approvalData,
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
