import 'package:cloud_firestore/cloud_firestore.dart'; // Import Firestore package
import 'package:flutter/material.dart';

class TimetableViewAdminPage extends StatefulWidget {
  final String selectedYear; // Field to hold the selected year

  const TimetableViewAdminPage({
    super.key,
    required this.selectedYear, // Require the selected year
  });

  @override
  _TimetableViewAdminPageState createState() => _TimetableViewAdminPageState();
}

class _TimetableViewAdminPageState extends State<TimetableViewAdminPage> {
  List<Map<String, String>> timetableData =
      []; // List to hold timetable data with IDs for the selected day
  String selectedDay = 'Monday'; // Default selected day
  bool isLoading = false; // Loading state variable
  Map<String, List<Map<String, String>>> timetableCache =
      {}; // Local cache for timetable data
  int? selectedIndex; // Track the index of the selected container

  @override
  void initState() {
    super.initState();
    _fetchTimetableForDay(
        selectedDay); // Fetch timetable for the default selected day
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: RichText(
          text: TextSpan(
            text: 'View Timetable - ',
            style: const TextStyle(
              color: Colors.black,
              fontSize: 20,
            ),
            children: <TextSpan>[
              TextSpan(
                text: widget.selectedYear,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: 20,
                ),
              ),
            ],
          ),
        ),
        backgroundColor: Colors.blue[100],
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildDayButton(context, 'Mon', 'Monday'),
              const SizedBox(width: 5),
              _buildDayButton(context, 'Tue', 'Tuesday'),
              const SizedBox(width: 5),
              _buildDayButton(context, 'Wed', 'Wednesday'),
              const SizedBox(width: 5),
              _buildDayButton(context, 'Thu', 'Thursday'),
              const SizedBox(width: 5),
              _buildDayButton(context, 'Fri', 'Friday'),
            ],
          ),
          const SizedBox(height: 20),
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : _buildTimetable(), // Call the timetable build method
          ),
          if (selectedIndex != null)
            _buildDustbinButton(), // Show dustbin button if an entry is selected
        ],
      ),
    );
  }

  // Build the timetable view
  Widget _buildTimetable() {
    return timetableData.isEmpty
        ? const Center(child: Text('No timetable available'))
        : ListView.builder(
            itemCount: timetableData.length,
            itemBuilder: (context, index) {
              return _deleteTimetableData(
                  index); // Use the separate method for each entry
            },
          );
  }

  // Create a timetable entry container
  Widget _deleteTimetableData(int index) {
    final entry = timetableData[index];

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedIndex =
              selectedIndex == index ? null : index; // Toggle selection
        });
      },
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          padding: const EdgeInsets.all(16.0),
          decoration: BoxDecoration(
            color: selectedIndex == index ? Colors.red : Colors.lightBlue[100],
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                flex: 2,
                child: Text(
                  entry['timeslot'] ?? '',
                  style: const TextStyle(fontSize: 16),
                  textAlign: TextAlign.left,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                flex: 3,
                child: Text(
                  entry['subject'] ?? '',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.left,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                flex: 2,
                child: Text(
                  entry['teacher'] ?? '',
                  style: const TextStyle(fontSize: 16),
                  textAlign: TextAlign.left,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Build the dustbin button
  Widget _buildDustbinButton() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ElevatedButton(
        onPressed: () {
          _deleteTimetableEntry(selectedIndex!); // Delete the selected entry
        },
        style: ElevatedButton.styleFrom(
          primary: Colors.red, // Set the button color to red
          padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
        ),
        child: const Text(
          '🗑️',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }

  // Delete the selected timetable entry
  Future<void> _deleteTimetableEntry(int index) async {
    final entry = timetableData[index];
    final docId = entry['id']; // Get the document ID

    // Logic to delete the timetable entry from Firestore
    await FirebaseFirestore.instance
        .collection('timetable')
        .doc(docId)
        .delete();

    // Remove it from the local timetableData list
    timetableData.removeAt(index);
    setState(() {
      selectedIndex = null; // Reset selected index
    });
  }

  // Build day button with short and full names
  Widget _buildDayButton(
      BuildContext context, String shortDay, String fullDay) {
    Color buttonColor = selectedDay == fullDay
        ? const Color.fromARGB(255, 173, 216, 230)
        : Colors.grey[300]!;

    return ElevatedButton(
      onPressed: () {
        if (selectedDay != fullDay) {
          setState(() {
            selectedDay = fullDay; // Update selected day
            timetableData
                .clear(); // Clear previous timetable data for the new selection
            selectedIndex = null; // Reset selected index
          });
          _fetchTimetableForDay(fullDay); // Fetch timetable for the new day
        }
      },
      child: Text(shortDay), // Display short day label (e.g., "Mon")
      style: ElevatedButton.styleFrom(
        minimumSize: const Size(40, 40), // Minimum size for height
        primary: buttonColor, // Use the determined button color
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  // Fetch timetable data for the selected year and day
  Future<void> _fetchTimetableForDay(String day) async {
    if (timetableCache.containsKey(day)) {
      timetableData = timetableCache[day]!;
      setState(() {});
      return;
    }

    setState(() {
      isLoading = true; // Start loading
    });

    try {
      await _getTimetableFromFirestore(day);
      _sortTimetableData();
      timetableCache[day] = List.from(timetableData);
      setState(() {});
    } catch (e) {
      print('Error fetching timetable for $day: $e');
    } finally {
      setState(() {
        isLoading = false; // Stop loading
      });
    }
  }

  // Fetch timetable data from Firestore
  Future<void> _getTimetableFromFirestore(String day) async {
    QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection('timetable')
        .where('year', isEqualTo: widget.selectedYear)
        .where('day', isEqualTo: day)
        .get();

    timetableData.clear();

    for (var doc in snapshot.docs) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      String timeslot = data['timeslot'] ?? 'No timeslot';
      String subject = data['subject'] ?? 'No subject';
      String teacher = data['teacher'] ?? 'No teacher';
      String docId = doc.id; // Get the document ID

      // Store data along with the document ID
      timetableData.add({
        'id': docId,
        'timeslot': timeslot,
        'subject': subject,
        'teacher': teacher,
      });
    }
  }

  // Sort timetable data based on the first numerical value of the timeslot
  void _sortTimetableData() {
    timetableData.sort((a, b) {
      String timeA = a['timeslot'] ?? '';
      String timeB = b['timeslot'] ?? '';
      return double.parse(timeA.split('-')[0])
          .compareTo(double.parse(timeB.split('-')[0]));
    });
  }
}
