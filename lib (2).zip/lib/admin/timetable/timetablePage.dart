import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'timetableViewAdmin.dart'; // Import the TimetableViewAdminPage

class AdminTimetablePage extends StatefulWidget {
  const AdminTimetablePage({super.key});

  @override
  _AdminTimetablePageState createState() => _AdminTimetablePageState();
}

class _AdminTimetablePageState extends State<AdminTimetablePage> {
  String? viewSelectedYear;
  String? createSelectedYear;
  String? selectedDay;
  String? selectedTimeslot;
  String? subject = '';
  String? teacher;
  List<Map<String, String>> teachers =
      []; // Updated to hold teacher ID and name
  bool isTimeslotAvailable = true; // To track timeslot availability

  @override
  void initState() {
    super.initState();
    _fetchTeachers();
  }

  Future<void> _fetchTeachers() async {
    try {
      QuerySnapshot snapshot =
          await FirebaseFirestore.instance.collection('teachers').get();
      setState(() {
        teachers = snapshot.docs.map((doc) {
          print(
              'Fetched teacher ID: ${doc.id}'); // Print the teacher's document ID
          return {
            'id': doc.id, // Store the document ID
            'name': doc['name'] as String,
          };
        }).toList();
      });
    } catch (e) {
      print('Error fetching teachers: $e');
    }
  }

  Future<void> _checkTimeslotAvailability() async {
    if (createSelectedYear != null &&
        selectedDay != null &&
        selectedTimeslot != null) {
      QuerySnapshot existingAssignments = await FirebaseFirestore.instance
          .collection('timetable')
          .where('day', isEqualTo: selectedDay)
          .where('timeslot', isEqualTo: selectedTimeslot)
          .get();

      setState(() {
        isTimeslotAvailable = existingAssignments.docs.isEmpty;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Timetable'),
        backgroundColor: Colors.blue[100],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 20),
            _buildTopContainer(),
            const SizedBox(height: 20),
            _buildBottomContainer(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildTopContainer() {
    return _buildContainer(
      title: 'View Timetable',
      children: [
        _buildDropdownRow(
            'Year:', viewSelectedYear, ['Year 4', 'Year 5', 'Year 6'],
            (newValue) {
          setState(() {
            viewSelectedYear = newValue;
          });
        }),
        _buildViewButton(),
      ],
    );
  }

  Widget _buildBottomContainer() {
    return _buildContainer(
      title: 'Create Timetable',
      children: [
        _buildDropdownRow(
            'Year:', createSelectedYear, ['Year 4', 'Year 5', 'Year 6'],
            (newValue) {
          setState(() {
            createSelectedYear = newValue;
          });
        }),
        const SizedBox(height: 20),
        _buildDropdownRow('Day:', selectedDay, [
          'Monday',
          'Tuesday',
          'Wednesday',
          'Thursday',
          'Friday'
        ], (newValue) {
          setState(() {
            selectedDay = newValue;
            selectedTimeslot = null; // Reset the timeslot when day changes
            isTimeslotAvailable = true; // Reset availability status
          });
        }),
        const SizedBox(height: 20),
        _buildDropdownRow('Timeslot:', selectedTimeslot, [
          '8.00-9.00',
          '10.00-11.00',
          '11.00-12.00',
          '12.00-13.00',
          '14.00-15.00',
          '16.00-17.00'
        ], (newValue) {
          setState(() {
            selectedTimeslot = newValue;
            _checkTimeslotAvailability(); // Check availability when the timeslot changes
          });
        }, isDisabled: !isTimeslotAvailable), // Disable if unavailable
        const SizedBox(height: 20),
        _buildSubjectInput(),
        const SizedBox(height: 20),
        _buildDropdownRow(
            'Teacher:',
            teacher,
            teachers.isNotEmpty
                ? teachers.map((t) => t['name']).toList()
                : [null], (newValue) {
          setState(() {
            teacher = newValue;
          });
        }),
        _buildCreateButton(),
      ],
    );
  }

  Widget _buildContainer(
      {required String title, required List<Widget> children}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.lightBlue[100],
        borderRadius: const BorderRadius.all(Radius.circular(20)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              title,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          ...children,
        ],
      ),
    );
  }

  Widget _buildDropdownRow(String label, String? value, List<String?> items,
      ValueChanged<String?> onChanged,
      {bool isDisabled = false}) {
    return Padding(
      padding: const EdgeInsets.only(left: 50.0),
      child: Row(
        children: [
          Text(label, style: const TextStyle(fontSize: 16)),
          const SizedBox(width: 10),
          _buildDropdownButton(
              hint: 'Select $label',
              value: value,
              items: items,
              onChanged: isDisabled
                  ? (_) {}
                  : onChanged), // Use an empty function if disabled
        ],
      ),
    );
  }

  Widget _buildSubjectInput() {
    return Padding(
      padding: const EdgeInsets.only(left: 50.0),
      child: Row(
        children: [
          const Text('Subject:', style: TextStyle(fontSize: 16)),
          const SizedBox(width: 10),
          Container(
            width: 200,
            child: TextField(
              onChanged: (value) {
                subject = value;
              },
              decoration: const InputDecoration(
                hintText: 'Enter subject',
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
                contentPadding:
                    EdgeInsets.symmetric(vertical: 8.0, horizontal: 10.0),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildViewButton() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ElevatedButton(
          onPressed: () {
            if (viewSelectedYear != null) {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      TimetableViewAdminPage(selectedYear: viewSelectedYear!),
                ),
              );
            } else {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content:
                      Text('Please select a year to view the timetable.')));
            }
          },
          child: const Text('View'),
          style: ElevatedButton.styleFrom(
            primary: const Color.fromARGB(255, 228, 228, 228),
            padding:
                const EdgeInsets.symmetric(vertical: 12.0, horizontal: 20.0),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        ),
      ),
    );
  }

  Widget _buildCreateButton() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ElevatedButton(
          onPressed: _createTimetableEntry,
          child: const Text('Create'),
          style: ElevatedButton.styleFrom(
            primary: const Color.fromARGB(255, 228, 228, 228),
            padding:
                const EdgeInsets.symmetric(vertical: 12.0, horizontal: 20.0),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        ),
      ),
    );
  }

  Future<void> _createTimetableEntry() async {
    if (createSelectedYear != null &&
        selectedDay != null &&
        selectedTimeslot != null &&
        subject != null &&
        teacher != null) {
      String year = createSelectedYear!;
      String documentId = '$year-$selectedDay-$selectedTimeslot';

// Find the selected teacher's ID
      String? teacherId = teachers.firstWhere((t) => t['name'] == teacher,
          orElse: () => {'id': ''} // Return an empty string instead of null
          )['id'];

      try {
        // Query to check if the year, day, and timeslot already exist
        QuerySnapshot existingTimetableEntry = await FirebaseFirestore.instance
            .collection('timetable')
            .where('year', isEqualTo: year)
            .where('day', isEqualTo: selectedDay)
            .where('timeslot', isEqualTo: selectedTimeslot)
            .get();

        if (existingTimetableEntry.docs.isNotEmpty) {
          // If the entry already exists
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('The timeslot is already taken.')));
        } else {
          // Query to check if the teacher is assigned to the same timeslot on the same day
          QuerySnapshot existingAssignments = await FirebaseFirestore.instance
              .collection('timetable')
              .where('teacherId', isEqualTo: teacherId)
              .where('day', isEqualTo: selectedDay)
              .where('timeslot', isEqualTo: selectedTimeslot)
              .get();

          if (existingAssignments.docs.isNotEmpty) {
            // If the teacher is already assigned for this timeslot and day in any year
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                content: Text(
                    'This teacher is already assigned to this timeslot on this day.')));
          } else {
            // Create the timetable entry in a single document
            await FirebaseFirestore.instance
                .collection('timetable')
                .doc(documentId)
                .set({
              'year': year,
              'day': selectedDay,
              'timeslot': selectedTimeslot,
              'subject': subject,
              'teacher': teacher,
              'teacherId': teacherId, // Include the teacher's ID
            });

            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                content: Text('Timetable entry created successfully!')));

            setState(() {
              createSelectedYear = null;
              selectedDay = null;
              selectedTimeslot = null;
              subject = '';
              teacher = null;
              isTimeslotAvailable = true; // Reset availability status
            });
          }
        }
      } catch (e) {
        print('Error creating timetable entry: $e');
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Error creating timetable entry.')));
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text(
              'Please fill in all fields before creating the timetable entry.')));
    }
  }

  Widget _buildDropdownButton(
      {required String hint,
      required String? value,
      required List<String?> items,
      required ValueChanged<String?> onChanged}) {
    return Container(
      width: 200,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: DropdownButton<String?>(
        hint: Text(hint),
        value: value,
        underline: const SizedBox(),
        isExpanded: true,
        items: items.map<DropdownMenuItem<String?>>((String? item) {
          return DropdownMenuItem<String?>(
            value: item,
            child: Text(item ?? 'None'),
          );
        }).toList(),
        onChanged: onChanged,
      ),
    );
  }
}
